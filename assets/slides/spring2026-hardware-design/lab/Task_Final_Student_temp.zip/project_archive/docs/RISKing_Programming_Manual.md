# RISKing CPU Programming Manual

## Overview

The RISKing processor is a 16-bit RISC CPU with a simple but powerful instruction set. This manual provides comprehensive guidance for writing assembly code for the RISKing CPU, including instruction syntax, programming conventions, memory layout, and special function registers.

## Architecture Summary

- **Word Size**: 16 bits
- **Address Space**: 16-bit addresses (0x0000 - 0xFFFF)
- **Main Memory**: 1024 words (0x0000 - 0x03FF)
- **Registers**: 8 general-purpose registers (R0-R7)
- **Special Function Registers (SFR)**: 3 registers at addresses 0x0400-0x0402

## Register Conventions

| Register | Convention | Purpose |
|----------|------------|---------|
| **R0** | General | Conventionally kept as zero (not hardware-enforced — software must initialize and preserve) |
| **R1-R5** | General | General-purpose registers |
| **R6** | **SP** | Stack Pointer (recommended usage) |
| **R7** | **LR** | Link Register (recommended usage) |

> **Note**: While all registers are general-purpose, following these conventions ensures compatibility with standard calling conventions and makes code more readable.

## Memory Layout

```
Address Range    | Description
-----------------|-------------------
0x0000 - 0x03FF | Main Memory (1024 words)
0x0400           | Input Register (Read-only)
0x0401           | Output Register (LED)
0x0402           | 7-segment Display Register
0x0403 - 0x07FF | Reserved SFR space
0x0800 - 0xFFFF | Unused (memory access disabled)
```

### Special Function Registers (SFR)

| Address | Name | Access | Description |
|---------|------|--------|-------------|
| **0x0400** | `INPUT_REG` | Read-only | Input from switches/external devices |
| **0x0401** | `OUTPUT_REG` | Read/Write | Output to LEDs |
| **0x0402** | `SEG7_REG` | Read/Write | Output to 7-segment display |

**Example Usage:**
```assembly
; Load SFR base address (0x04 << 8 = 0x0400) into R0
LUI R0, 0x04            ; R0 = 0x0400 (SFR base address)

; Read input from switches
LDR R1, [R0, 0]         ; R1 = INPUT_REG (offset 0 from base)

; Write to LEDs
STR R2, [R0, 1]         ; OUTPUT_REG = R2 (offset 1 from base)

; Write to 7-segment display
STR R3, [R0, 2]         ; SEG7_REG = R3 (offset 2 from base)
```

## Instruction Set

### R-type Instructions (Register Operations)

**Syntax**: `OP Rd, Ra, Rb` or `OP Rd, Ra, Rb, shift` or `OP Rd, Ra, SHIFT(Rb)`

The shift operation is applied to Rb **before** the ALU operation.

| Mnemonic | Operation | Flags | Description |
|----------|-----------|-------|-------------|
| `ADD` | `Rd = Ra + Shift(Rb)` | Z, N, C, V | Add |
| `SUB` | `Rd = Ra - Shift(Rb)` | Z, N, C, V | Subtract |
| `ADDC` | `Rd = Ra + Shift(Rb) + C` | Z, N, C, V | Add with carry |
| `SUBC` | `Rd = Ra - Shift(Rb) - C` | Z, N, C, V | Subtract with carry/borrow |
| `AND` | `Rd = Ra & Shift(Rb)` | Z, N | Bitwise AND |
| `ANDBB` | `Rd = Ra & ~Shift(Rb)` | Z, N | AND with Bar (bit-clear) |
| `OR` | `Rd = Ra \| Shift(Rb)` | Z, N | Bitwise OR |
| `ORBB` | `Rd = Ra \| ~Shift(Rb)` | Z, N | OR with Bar (bit-set complement) |

**Shift Operations** (applied to Rb, **1-bit shift only**):
- `NONE` (default, code `00`): No shift
- `LSL` (code `01`): Logical shift left by 1
- `LSR` (code `10`): Logical shift right by 1
- `ASR` (code `11`): Arithmetic shift right by 1 (preserves sign bit)

**Examples**:
```assembly
ADD R1, R2, R3          ; R1 = R2 + R3 (no shift)
SUB R4, R5, R6          ; R4 = R5 - R6
ADD R0, R1, LSL(R2)     ; R0 = R1 + (R2 << 1)
ADD R0, R1, R2, LSL     ; R0 = R1 + (R2 << 1)  (alternative syntax)
AND R3, R4, ASR(R5)     ; R3 = R4 & (R5 >>> 1)
```

### I-type Instructions (Immediate Operations)

**Syntax**: `OP Rd, Ra, imm5`

| Mnemonic | Operation | Flags | Description |
|----------|-----------|-------|-------------|
| `ADDI` | `Rd = Ra + SignExt(imm5)` | Z, N, C, V | Add immediate (5-bit signed: -16 to +15) |
| `SUBI` | `Rd = Ra - SignExt(imm5)` | Z, N, C, V | Subtract immediate (5-bit signed: -16 to +15) |

**Examples**:
```assembly
ADDI R1, R2, 10         ; R1 = R2 + 10
SUBI R3, R4, 5          ; R3 = R4 - 5
ADDI R5, R5, -1         ; R5 = R5 - 1 (decrement)
```

### Load Immediate Instructions

**Syntax**: `OP Rd, imm8`

| Mnemonic | Encoding | Operation | Description |
|----------|----------|-----------|-------------|
| `LDI` | `[10000][Rd:3][imm8:8]` | `Rd = SignExt(imm8)` | Load 8-bit immediate with sign extension |
| `LUI` | `[10001][Rd:3][imm8:8]` | `Rd = {imm8, 8'b0}` | Load upper immediate (imm8 placed in upper byte, lower byte zeroed) |

> **Note**: The assembler accepts immediate values in the range **0 to 255** (unsigned) for both `LDI` and `LUI`. For `LDI`, values 128–255 will be sign-extended to negative 16-bit values by the hardware (e.g., `LDI R1, 0xFF` → R1 = 0xFFFF = -1).

**Examples**:
```assembly
LDI R1, 100             ; R1 = 0x0064 (100, positive — bit 7 is 0)
LDI R2, 0xFF            ; R2 = 0xFFFF (-1, sign-extended — bit 7 is 1)
LUI R3, 0x04            ; R3 = 0x0400 (0x04 << 8)
LUI R4, 0x12            ; R4 = 0x1200 (0x12 << 8)
```

### Memory Access Instructions

**Syntax**: `OP Rd, [Ra, offset]` or `OP Rd, Ra, offset`

| Mnemonic | Encoding | Operation | Description |
|----------|----------|-----------|-------------|
| `LDR` | `[10010][Rd:3][Ra:3][imm5:5]` | `Rd = Mem[Ra + SignExt(imm5)]` | Load from memory |
| `STR` | `[10011][Rd:3][Ra:3][imm5:5]` | `Mem[Ra + SignExt(imm5)] = Rd` | Store to memory |

**Examples**:
```assembly
LDR R3, [R1, 0]         ; R3 = Mem[R1 + 0]
LDR R4, R1, 5           ; R4 = Mem[R1 + 5] (alternative syntax)
STR R5, [R1, -2]        ; Mem[R1 - 2] = R5
```

### Jump and Branch Instructions

**Syntax**: `OP label` (assembler computes relative offset automatically)

| Mnemonic | Encoding | Operation | Condition |
|----------|----------|-----------|----------|
| `JMP` | `[11000][000][imm8]` | `PC = PC + 1 + SignExt(imm8)` | Always |
| `JAL` | `[11001][111][imm8]` | `R7 = PC + 1; PC = PC + 1 + SignExt(imm8)` | Always |
| `JR` | `[11010][111][00000000]` | `PC = R7` | Always |
| `BEQ` | `[11011][000][imm8]` | `PC = PC + 1 + SignExt(imm8)` | Z = 1 |
| `BNE` | `[11100][000][imm8]` | `PC = PC + 1 + SignExt(imm8)` | Z = 0 |
| `BLT` | `[11101][000][imm8]` | `PC = PC + 1 + SignExt(imm8)` | N ≠ V |
| `BGE` | `[11110][000][imm8]` | `PC = PC + 1 + SignExt(imm8)` | N = V |

**Examples**:
```assembly
JMP loop_start          ; Unconditional jump
JAL subroutine          ; Call subroutine (return address in R7)
JR                      ; Return from subroutine (PC = R7)
BEQ skip                ; Branch if equal (Z flag set)
BNE continue            ; Branch if not equal (Z flag clear)
```

### Special Instructions

| Mnemonic | Encoding | Operation | Description |
|----------|----------|-----------|-------------|
| `HALT` | `0xFFFF` (`[11111][11111111111]`) | Stop execution | Asserts CPU halt signal |
| `NOP` | `0x4000` (`ADDI R0, R0, 0`) | No operation | Pseudo-op: `R0 = R0 + 0` |
| `MOV Rd, Ra` | `ADDI Rd, Ra, 0` | `Rd = Ra` | Pseudo-op: move register |

**Examples**:
```assembly
HALT                    ; Stop CPU execution
NOP                     ; No operation
MOV R1, R2              ; R1 = R2 (assembled as ADDI R1, R2, 0)
```

## Assembly Syntax

### Basic Structure
```assembly
[label:] instruction [operands]    ; comment
.DIRECTIVE [arguments]
```

### Labels
- End with colon (`:`)
- Used for jump targets and data references
- Case-sensitive

### Comments
- Single-line comments: `;` or `//`
- Comments are ignored by the assembler

### Assembler Directives
- `.ORG address`: Set the assembler's location counter to the specified address (decimal or hex)
- `.WORD value`: Place a 16-bit data word at the current address (can be a number or a label)

### Number Formats
- Decimal: `10`, `-5`
- Hexadecimal: `0x10`, `0xFF`
- Binary: Not directly supported (use hex)
- Labels can be used as operands and are resolved to their address (relative for jumps/branches, absolute for `.WORD`)

## Programming Examples

### Hello World (LED Output)
```assembly
START:
    LUI R0, 0x04        ; R0 = 0x0400 (SFR base address: 0x04 << 8)
    LDI R1, 0x55        ; R1 = 0x0055 (pattern)
    STR R1, [R0, 1]     ; OUTPUT_REG = R1 (offset 1 from base = 0x0401)
    HALT                ; Stop
```

### Simple Loop
```assembly
    LDI R1, 10          ; Counter = 10
    LDI R2, 0           ; Sum = 0
LOOP:
    ADD R2, R2, R1      ; Sum += Counter
    SUBI R1, R1, 1      ; Counter--
    BNE LOOP            ; Branch if Counter != 0
    LUI R0, 0x04        ; Load SFR base address (0x04 << 8 = 0x0400)
    STR R2, [R0, 1]     ; Output result to LEDs (0x0401)
    HALT
```

### Function Call
```assembly
MAIN:
    LDI R1, 5
    LDI R2, 3
    JAL ADD_FUNC        ; Call function, return address in R7
    LUI R0, 0x04        ; Load SFR base address (0x04 << 8 = 0x0400)
    STR R0, [R0, 1]     ; Output result to LEDs (0x0401)
    HALT

ADD_FUNC:
    ADD R0, R1, R2      ; R0 = R1 + R2
    JR                  ; Return (PC = R7)
```

### Stack Operations (using R6 as SP)
```assembly
; Initialize stack pointer
LUI R6, 0x02           ; SP = 0x0200 (0x02 << 8)

; Push R1 onto stack
SUBI R6, R6, 1         ; SP--
STR R1, [R6, 0]        ; Mem[SP] = R1

; Pop R1 from stack  
LDR R1, [R6, 0]        ; R1 = Mem[SP]
ADDI R6, R6, 1         ; SP++
```

## Assembler Usage

The RISKing assembler (`RISKing_assembler.py`) converts assembly code to binary format.

### Command Line
```bash
python RISKing_assembler.py input.asm [-o output_prefix] [-d memory_depth]
```

### Parameters
- `input.asm`: Input assembly file
- `-o output_prefix`: Output file prefix (default: input filename)
- `-d memory_depth`: Memory depth in words (default: 1024)

### Output Files
- `<prefix>.coe`: Vivado Block Memory initialization file (hex, COE format)
- `<prefix>.txt`: Binary format for simulation (`$readmemb`)
- `<prefix>.mem`: Memory initialization file (hex, one word per line)

When `-o` is not specified, the output prefix defaults to `<input_basename>_mem_init` (e.g., `program.asm` → `program_mem_init.coe`, `program_mem_init.txt`, `program_mem_init.mem`).

Unused memory locations are filled with `0xFFFF` (HALT) up to the specified memory depth.

### Example
```bash
python RISKing_assembler.py program.asm -o mem_init -d 1024
```

## Best Practices

1. **Use Register Conventions**: R6 for SP, R7 for LR
2. **Initialize Pointers**: Always initialize stack pointer and base registers
3. **Handle Memory Bounds**: Main memory is only 1024 words (0x0000-0x03FF)
4. **Use Labels**: Make code readable with meaningful labels
5. **Comment Code**: Document complex operations and algorithms
6. **Test Incrementally**: Build and test small sections before combining
7. **Handle SFRs Carefully**: Remember SFR addresses are absolute (0x0400+)

## Common Pitfalls

- **Memory Access**: Accessing addresses > 0x03FF will not work (memory disabled)
- **Immediate Range**: 
  - 5-bit signed immediates (ADDI/SUBI, LDR/STR offset): -16 to +15
  - 8-bit immediates (LDI/LUI): 0 to 255 (assembler accepts unsigned; LDI sign-extends in hardware, so 128–255 become negative)
- **Branch Range**: -128 to +127 instructions relative to PC+1
- **Stack Overflow**: Ensure stack doesn't collide with program/data
- **SFR Access**: Use absolute addresses (0x0400, 0x0401, 0x0402) for SFRs

## Status Flags

The ALU sets status flags that affect conditional branches:

| Flag | Name | Set When |
|------|------|----------|
| **Z** | Zero | Result is zero |
| **N** | Negative | Result MSB is 1 (negative in two's complement) |
| **V** | Overflow | Signed arithmetic overflow occurred |
| **C** | Carry | Unsigned arithmetic carry/borrow occurred |

**Flag update rules by instruction type:**
- **Arithmetic** (ADD, SUB, ADDC, SUBC, ADDI, SUBI): Updates **all 4 flags** (Z, N, V, C)
- **Logical** (AND, ANDBB, OR, ORBB): Updates **Z and N only** (V and C cleared to 0)
- **Memory/Jump/Branch** (LDI, LUI, LDR, STR, JMP, JAL, JR, BEQ, BNE, BLT, BGE): **No flag updates**

---

*This manual covers the complete RISKing CPU instruction set and programming model as of the current implementation. Refer to the source code and instruction set reference for the most up-to-date information.*