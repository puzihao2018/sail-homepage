// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2025.2 (win64) Build 6299465 Fri Nov 14 19:35:11 GMT 2025
// Date        : Tue Feb 24 12:11:53 2026
// Host        : TX14Air-ZIHAOPU running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode funcsim -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
//               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ blk_mem_gen_0_sim_netlist.v
// Design      : blk_mem_gen_0
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7a35tcpg236-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "blk_mem_gen_0,blk_mem_gen_v8_4_12,{}" *) (* downgradeipidentifiedwarnings = "yes" *) (* x_core_info = "blk_mem_gen_v8_4_12,Vivado 2025.2" *) 
(* NotValidForBitStream *)
module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix
   (clka,
    ena,
    wea,
    addra,
    dina,
    douta);
  (* x_interface_info = "xilinx.com:interface:bram:1.0 BRAM_PORTA CLK" *) (* x_interface_mode = "slave BRAM_PORTA" *) (* x_interface_parameter = "XIL_INTERFACENAME BRAM_PORTA, MEM_ADDRESS_MODE BYTE_ADDRESS, MEM_SIZE 8192, MEM_WIDTH 32, MEM_ECC NONE, MASTER_TYPE OTHER, READ_LATENCY 1" *) input clka;
  (* x_interface_info = "xilinx.com:interface:bram:1.0 BRAM_PORTA EN" *) input ena;
  (* x_interface_info = "xilinx.com:interface:bram:1.0 BRAM_PORTA WE" *) input [0:0]wea;
  (* x_interface_info = "xilinx.com:interface:bram:1.0 BRAM_PORTA ADDR" *) input [9:0]addra;
  (* x_interface_info = "xilinx.com:interface:bram:1.0 BRAM_PORTA DIN" *) input [15:0]dina;
  (* x_interface_info = "xilinx.com:interface:bram:1.0 BRAM_PORTA DOUT" *) output [15:0]douta;

  wire [9:0]addra;
  wire clka;
  wire [15:0]dina;
  wire [15:0]douta;
  wire ena;
  wire [0:0]wea;
  wire NLW_U0_dbiterr_UNCONNECTED;
  wire NLW_U0_rsta_busy_UNCONNECTED;
  wire NLW_U0_rstb_busy_UNCONNECTED;
  wire NLW_U0_s_axi_arready_UNCONNECTED;
  wire NLW_U0_s_axi_awready_UNCONNECTED;
  wire NLW_U0_s_axi_bvalid_UNCONNECTED;
  wire NLW_U0_s_axi_dbiterr_UNCONNECTED;
  wire NLW_U0_s_axi_rlast_UNCONNECTED;
  wire NLW_U0_s_axi_rvalid_UNCONNECTED;
  wire NLW_U0_s_axi_sbiterr_UNCONNECTED;
  wire NLW_U0_s_axi_wready_UNCONNECTED;
  wire NLW_U0_sbiterr_UNCONNECTED;
  wire [15:0]NLW_U0_doutb_UNCONNECTED;
  wire [9:0]NLW_U0_rdaddrecc_UNCONNECTED;
  wire [3:0]NLW_U0_s_axi_bid_UNCONNECTED;
  wire [1:0]NLW_U0_s_axi_bresp_UNCONNECTED;
  wire [9:0]NLW_U0_s_axi_rdaddrecc_UNCONNECTED;
  wire [15:0]NLW_U0_s_axi_rdata_UNCONNECTED;
  wire [3:0]NLW_U0_s_axi_rid_UNCONNECTED;
  wire [1:0]NLW_U0_s_axi_rresp_UNCONNECTED;

  (* C_ADDRA_WIDTH = "10" *) 
  (* C_ADDRB_WIDTH = "10" *) 
  (* C_ALGORITHM = "1" *) 
  (* C_AXI_ID_WIDTH = "4" *) 
  (* C_AXI_SLAVE_TYPE = "0" *) 
  (* C_AXI_TYPE = "1" *) 
  (* C_BYTE_SIZE = "9" *) 
  (* C_COMMON_CLK = "0" *) 
  (* C_COUNT_18K_BRAM = "1" *) 
  (* C_COUNT_36K_BRAM = "0" *) 
  (* C_CTRL_ECC_ALGO = "NONE" *) 
  (* C_DEFAULT_DATA = "FFFF" *) 
  (* C_DISABLE_WARN_BHV_COLL = "0" *) 
  (* C_DISABLE_WARN_BHV_RANGE = "0" *) 
  (* C_ELABORATION_DIR = "./" *) 
  (* C_ENABLE_32BIT_ADDRESS = "0" *) 
  (* C_EN_DEEPSLEEP_PIN = "0" *) 
  (* C_EN_ECC_PIPE = "0" *) 
  (* C_EN_RDADDRA_CHG = "0" *) 
  (* C_EN_RDADDRB_CHG = "0" *) 
  (* C_EN_SAFETY_CKT = "0" *) 
  (* C_EN_SHUTDOWN_PIN = "0" *) 
  (* C_EN_SLEEP_PIN = "0" *) 
  (* C_EST_POWER_SUMMARY = "Estimated Power for IP     :     1.51805 mW" *) 
  (* C_FAMILY = "artix7" *) 
  (* C_HAS_AXI_ID = "0" *) 
  (* C_HAS_ENA = "1" *) 
  (* C_HAS_ENB = "0" *) 
  (* C_HAS_INJECTERR = "0" *) 
  (* C_HAS_MEM_OUTPUT_REGS_A = "0" *) 
  (* C_HAS_MEM_OUTPUT_REGS_B = "0" *) 
  (* C_HAS_MUX_OUTPUT_REGS_A = "0" *) 
  (* C_HAS_MUX_OUTPUT_REGS_B = "0" *) 
  (* C_HAS_REGCEA = "0" *) 
  (* C_HAS_REGCEB = "0" *) 
  (* C_HAS_RSTA = "0" *) 
  (* C_HAS_RSTB = "0" *) 
  (* C_HAS_SOFTECC_INPUT_REGS_A = "0" *) 
  (* C_HAS_SOFTECC_OUTPUT_REGS_B = "0" *) 
  (* C_INITA_VAL = "0" *) 
  (* C_INITB_VAL = "0" *) 
  (* C_INIT_FILE = "blk_mem_gen_0.mem" *) 
  (* C_INIT_FILE_NAME = "blk_mem_gen_0.mif" *) 
  (* C_INTERFACE_TYPE = "0" *) 
  (* C_LOAD_INIT_FILE = "1" *) 
  (* C_MEM_TYPE = "0" *) 
  (* C_MUX_PIPELINE_STAGES = "0" *) 
  (* C_PRIM_TYPE = "1" *) 
  (* C_READ_DEPTH_A = "1024" *) 
  (* C_READ_DEPTH_B = "1024" *) 
  (* C_READ_LATENCY_A = "1" *) 
  (* C_READ_LATENCY_B = "1" *) 
  (* C_READ_WIDTH_A = "16" *) 
  (* C_READ_WIDTH_B = "16" *) 
  (* C_RSTRAM_A = "0" *) 
  (* C_RSTRAM_B = "0" *) 
  (* C_RST_PRIORITY_A = "CE" *) 
  (* C_RST_PRIORITY_B = "CE" *) 
  (* C_SIM_COLLISION_CHECK = "ALL" *) 
  (* C_USE_BRAM_BLOCK = "0" *) 
  (* C_USE_BYTE_WEA = "0" *) 
  (* C_USE_BYTE_WEB = "0" *) 
  (* C_USE_DEFAULT_DATA = "1" *) 
  (* C_USE_ECC = "0" *) 
  (* C_USE_SOFTECC = "0" *) 
  (* C_USE_URAM = "0" *) 
  (* C_WEA_WIDTH = "1" *) 
  (* C_WEB_WIDTH = "1" *) 
  (* C_WRITE_DEPTH_A = "1024" *) 
  (* C_WRITE_DEPTH_B = "1024" *) 
  (* C_WRITE_MODE_A = "WRITE_FIRST" *) 
  (* C_WRITE_MODE_B = "WRITE_FIRST" *) 
  (* C_WRITE_WIDTH_A = "16" *) 
  (* C_WRITE_WIDTH_B = "16" *) 
  (* C_XDEVICEFAMILY = "artix7" *) 
  (* downgradeipidentifiedwarnings = "yes" *) 
  (* is_du_within_envelope = "true" *) 
  decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_blk_mem_gen_v8_4_12 U0
       (.addra(addra),
        .addrb({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .clka(clka),
        .clkb(1'b0),
        .dbiterr(NLW_U0_dbiterr_UNCONNECTED),
        .deepsleep(1'b0),
        .dina(dina),
        .dinb({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .douta(douta),
        .doutb(NLW_U0_doutb_UNCONNECTED[15:0]),
        .eccpipece(1'b0),
        .ena(ena),
        .enb(1'b0),
        .injectdbiterr(1'b0),
        .injectsbiterr(1'b0),
        .rdaddrecc(NLW_U0_rdaddrecc_UNCONNECTED[9:0]),
        .regcea(1'b1),
        .regceb(1'b1),
        .rsta(1'b0),
        .rsta_busy(NLW_U0_rsta_busy_UNCONNECTED),
        .rstb(1'b0),
        .rstb_busy(NLW_U0_rstb_busy_UNCONNECTED),
        .s_aclk(1'b0),
        .s_aresetn(1'b0),
        .s_axi_araddr({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .s_axi_arburst({1'b0,1'b0}),
        .s_axi_arid({1'b0,1'b0,1'b0,1'b0}),
        .s_axi_arlen({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .s_axi_arready(NLW_U0_s_axi_arready_UNCONNECTED),
        .s_axi_arsize({1'b0,1'b0,1'b0}),
        .s_axi_arvalid(1'b0),
        .s_axi_awaddr({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .s_axi_awburst({1'b0,1'b0}),
        .s_axi_awid({1'b0,1'b0,1'b0,1'b0}),
        .s_axi_awlen({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .s_axi_awready(NLW_U0_s_axi_awready_UNCONNECTED),
        .s_axi_awsize({1'b0,1'b0,1'b0}),
        .s_axi_awvalid(1'b0),
        .s_axi_bid(NLW_U0_s_axi_bid_UNCONNECTED[3:0]),
        .s_axi_bready(1'b0),
        .s_axi_bresp(NLW_U0_s_axi_bresp_UNCONNECTED[1:0]),
        .s_axi_bvalid(NLW_U0_s_axi_bvalid_UNCONNECTED),
        .s_axi_dbiterr(NLW_U0_s_axi_dbiterr_UNCONNECTED),
        .s_axi_injectdbiterr(1'b0),
        .s_axi_injectsbiterr(1'b0),
        .s_axi_rdaddrecc(NLW_U0_s_axi_rdaddrecc_UNCONNECTED[9:0]),
        .s_axi_rdata(NLW_U0_s_axi_rdata_UNCONNECTED[15:0]),
        .s_axi_rid(NLW_U0_s_axi_rid_UNCONNECTED[3:0]),
        .s_axi_rlast(NLW_U0_s_axi_rlast_UNCONNECTED),
        .s_axi_rready(1'b0),
        .s_axi_rresp(NLW_U0_s_axi_rresp_UNCONNECTED[1:0]),
        .s_axi_rvalid(NLW_U0_s_axi_rvalid_UNCONNECTED),
        .s_axi_sbiterr(NLW_U0_s_axi_sbiterr_UNCONNECTED),
        .s_axi_wdata({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .s_axi_wlast(1'b0),
        .s_axi_wready(NLW_U0_s_axi_wready_UNCONNECTED),
        .s_axi_wstrb(1'b0),
        .s_axi_wvalid(1'b0),
        .sbiterr(NLW_U0_sbiterr_UNCONNECTED),
        .shutdown(1'b0),
        .sleep(1'b0),
        .wea(wea),
        .web(1'b0));
endmodule
`pragma protect begin_protected
`pragma protect version = 1
`pragma protect encrypt_agent = "XILINX"
`pragma protect encrypt_agent_info = "Xilinx Encryption Tool 2025.2"
`pragma protect key_keyowner="Synopsys", key_keyname="SNPS-VCS-RSA-2", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=128)
`pragma protect key_block
YqH9kwIC39+qbZg4PSfFsXuB9k9wnuxNryS/CfnEri6Ci9fSC6fsrQ/T/hnt3u/yolbJ8DJa1Qu6
Qnm24A9jLbA+fu3Nsmm6/rM6a4vU6OfVl/gTFd/CiWDutv6Dhn6Lim4uUNPahoOR/A2Yc4Zo2tdI
kMLO9gn9WlH2l3O2oXs=

`pragma protect key_keyowner="Aldec", key_keyname="ALDEC15_001", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
XJYO2VHd/cnMxQd3i7/2qRhl57dl+doEKuhAunQyv3vpGRG/jlNxj8PqrgLoF0HMdqE3qJUVE/oq
kBSapqjVjLDMOrNGQ+Tc6VGsKMZH8FE/TXHQJ/IM5Iuiu2eozEwwVUomF+7cfqn+9OsVsqCONQ1M
g0oRlangiqasJDhhMfnlGGqwAwmgWRGQA6dmhTuua1s8zdvIv540zY6p5au8cAKVhqyyKK7wbxEE
SGuFqX+NYoyRV+rfWCcWM+hJEmnWS8LNAKkd13YE2+17sPYzUdZ23DmTxXK6KlAxKFW27CBySUfg
qdNXp2DSs2KAQYih27pBNMuHfGbM/ATFPWFvxg==

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-VELOCE-RSA", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=128)
`pragma protect key_block
lYoEi/e8HsDTz6N11EDe/B/iitERmeYndlCklmCluwgb0N4W80JUGVlkd7NlRZHRNhxaNBJPkcjC
n61nO0tb17NwsMwjbY5TF8JWRYTNw1JXCFacvQYrdKv4/7QNQEtwVGiCLxFhOA8aHlWMZIrc2fri
VRMVWaEBcPwCGorlVIM=

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-VERIF-SIM-RSA-2", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
QEw9fEsWFbdX0OQLvYs/gl+zyEOW3ak9TdQVaq+0AXXOT3LIqF7wDxJ6ZBnlf9mNbdsUVH5tAz1o
H8u7ihJl1L3THEvugW+TS8hkvVbEA9rKO2vV15KAj4Lla7UdFT/xDfe79RFarlLI7yGrubjgdoRi
QWy//UKsffG7IWNwmoSuppWiWB4ZHJtkunNyIkm70JPGyZF62VxJg1MTT+5LUbZG5vZjjuHZud9w
xJaKv1tFP/x8RVqLU5gPOqGqTW7/nKO2S+450Vo4D9vAmBVVcXpaL1EbSmCvQ+qJmcQKtf9qYFRV
Zko08hbpHjPxstqvTDro01jRzB8592m4xU2TWA==

`pragma protect key_keyowner="Real Intent", key_keyname="RI-RSA-KEY-1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
TC7q853CWBPPJgbRfgDV1lmjUwSAtliljShAyNFg8sfRfwDzchthzoSPH1UCHV++E2JXacEKq1lB
UWsNP92U4Xh0/Gu+6esOI0pJb8I+TRTxyBN1I4cRQEfQHcwfhbSdeH3yX9OV3opLEqYmT37hWU+J
zCawYnxVESI0FtRzEXve9gdEWlrKKckrT/hp4mvxxOjvOkOSQBvy0elgUOqh6mEOZl+JnUbsR+Wm
CoZLE1eefMZy3FnVmyDNPv3JPXi88aLXMyimal0MYFkTiS4XJiGT3eAIMIbksehXY+eYi/KFpZWQ
GHpX+lG3UmiWWLwyPakFwKEHbrBc70AlJ2eV9g==

`pragma protect key_keyowner="Xilinx", key_keyname="xilinxt_2025.1-2029.x", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
j9nmCKgjPWNChPbpSW6EWLrMA6oCG2JGPoum8px09v0PEAh0DRXZi0J8HPzXUsZgOEMcKpA7X54u
YFcDDCLAQ+urha/eSPbQYHQh4yGCursxAQ1C6LEyNQ2wJ0eLlO2bJeAl/gof06zqsYVM2lLJVNv5
wao1k2bmgPdfpfY3c9vPD0fSMuZPS41EoRS0cQhO5GTZnKdjxm6tEUL3GnTjB8ynSCIbCJUsMtAX
4FRHNa52gudx5B5fagR+lXgFhE7e++rWTJELr7SYB+r5Es8qZLTpCH8TrQxEkV0rY/+e4sAjNE2D
gHw8GD7VcUtc15B8y1BbVmh29qc8Nd3V2i/miA==

`pragma protect key_keyowner="Metrics Technologies Inc.", key_keyname="DSim", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
UkCD6I/Vye4qNoNoa3hIexBXG3xyKUJPAHAjIo7UcNVCDXpMQiYEtPDqExZMfiPlJn2nswCYIfIJ
FYWqMCloKSQyyI/7yZ2EtbyWEklb/P5IyZyvGi6hhFUo/JFTb12b4bK0gZPr+bCDdlVQKTx5GVHz
wptdUJO2omSj8axVMPbLRRtVzlJIZ29dTJ2ATXVXAcBxPnFfHRAMnYYKLeeLExX61vQvpqrkLQHm
XG7hpVzJi56gYKAzxa2BLq072OCVpVS70bfWlhlSTVcSlCrUf+EcarEk4FD8+Ih2NCvrqremG6yn
TtcBn8Xr8M/6zhOYvLi6AD6eArDMKA8n+Ccv8A==

`pragma protect key_keyowner="Atrenta", key_keyname="ATR-SG-RSA-1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=384)
`pragma protect key_block
A5y5QVZU8yjPexRVPioSiAGohCHD5DX5FVobuMyhcgQRExLUhPvnnS8HOtxTj/2IapEcz68gFMGG
Hpi+m725u85/om/Vze9pGIW9Mn328Kz2FIg3W5EvGstfGwY+48LiAGAmTR269JS4lJGVYWYOz7Xk
S8cEsFd2m7j8iyKtARJzD90+UdXq/cIIh725jC9i8nbgxB364zddvm1Z/DF3JRw1qFp6GGcuRai1
KNcJ1j8c9wtIgktpsteU3e5+bxHEw8NT3gWXUFYjm00NDq97Jals8Jjktmum2nQxoF7ivPacfEey
gnSF6jRMkTsZObzc30hAhs0CEtc33hZLhPLHSn8pQ0WyvKJLHdd5s2yckgTZtqxC1Sbwe7WEgNXe
ZMX3pIkz+aoXsAL7GBLyVBMVQcyMoF0w8QGAaTe8sqatABwPqXidYRqNROTf62IYcMpV89XYgaTv
EwIn/oni9KOFd2BFVxRZbFGGC4IjvigsTBUijI+Dk6kVnDh240clGcc4

`pragma protect key_keyowner="Cadence Design Systems.", key_keyname="CDS_RSA_KEY_VER_1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
Omtp+lCaqUx7Z4qdFj2zrN8LpCkit2eX4hlMtig+ielGm/x4FSZkpjoFmiqdKFPi2eg0pg09MSai
XyGH68UzAR7Xrj8f1jlIoUmMKp4GcxfdqfTeuu7kWGOJEP6cvgTjSJFj2gawDv7f4yZcltnK2x0L
e4GW/rBTmGvZtKWb2ahjINLxPuh3dDaSaWdb+zVgbtyrI5FrjxBkq+aOxSjyNsqnCx1L0uWbxnkl
88NbXN3dTaECXHNm/fsleayM5hKis7kTv9BFajJMGy+BhQlmIYpE+F5zchnTTFUFJZCz1sX9Fc8e
HcY7irB8mR3ajdzjUZLBQEMktp096Nheq3U75A==

`pragma protect key_keyowner="Synplicity", key_keyname="SYNP15_1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
hpeBLwN9x2ZFDwroYLlUe5GjjDepHik2l0c2s3/6S7JPCRkzQSyt2V1Ad/JewAs/QNp5SXSbYYB4
rQl0My1LDMF3xw43r0g2IbcyHVpPhGp0W5msuQdF67afnsRv90iJYWLMI3QkYGCTWAzl4HrLxFSg
3z8XZRK670IcxznOrlvgHmIKsvubZrBkuc1EynrVb9Nw16QnIx2rc4WgcEXeFf+4i1RoYLDd3gXK
NFCNMdtaRYUThunFP6Z4ViZ5UnDmKq+IMhd31jTaqIlWOBDxPI1+v5RJYxIyTbn4rxlKR2fNbl5/
z4OUjBTd+1GH3I2OXlqmAOvIhpe2Z2HH7nZu/A==

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-PREC-RSA", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
Mt2RhTSUwEIEWeNARbyL+EdfS1UF6nPaL/fKl/7oO2gina93egwCWDLl1fbBtkfaPco0cu4MJ9K3
OraAsyHRlY+MNShmJ1LzAIA1LjZx4y55lu9dlQqSUXR7AW7wVbkg1864mK+hM/1XygU0jvebKNW9
B7xSER+asLO6pxi0mt7uC2PHxLPAYEszFhmnap82TtbDGdQ2qtyekY+ngs+N2fAdsblxVwJruiMl
e6XJ127M8N1mYwhWU2HtRpBOSnnKoHgD9fG51XK/rhk8DxT66QnX9uLPB+H25eDupBJGi1Y5o6x8
hOwZiSUVlBLh7brfzevh7+eRn+7es6wBas0+3w==

`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 76, bytes = 19008)
`pragma protect data_block
ZAB2F1x7ZRJPz65+cojJQ5Mu22sXYkzuRR4T/ntPvvPQnvYVMz1UE7NZ/sWTQABsmjgP6T9N131j
kvXZkogRdM4hvZpWjbvdb/c/101teddcu7KqnCCIP4Jv1xnHU9et+/4u/OptUiSKXMBala4dWWlC
27yBEM2/lTDUEwmVz5NQfJEoiyJ4CKPPNoE3cIC0B1hKG2jSowIolPpjMNcPnOHmSMASBsFg4HH1
o208+0t9Ob2fVSFBLysYsKyZEBViue7XMTLYASSeLl7Eyhyg2Uei5u4/loyMO1Ht+PgHgx4OsK++
Hdp6UY5PSMs2RMWbVbq4q/Ao+5YzPG5GPeV2T067vhjEgetglX4BGVem0bg2umY9yj4uCSuSbIu+
rIUSeSS+7AzGYQvpknUbrdKG2wPjSWdJd459TjyGpv4Ycjbp60VYOCJV+ZpE+/+jORRC6wW4PRuf
0eAShioYwag1hCP5EIYehGK1wMgjTkriWVuxgYhA/eDi2wJttrIo5KXekqfc0WYnbMcZK03wEiNi
xFHE8dIti0p02XDy9Igjqi4FYHzhMI1nobSI2I6f8Xwbh7CvO8L8zUF442ekVayawyQgpfPmQ0Yp
3cYHRBKx+9JUP52JKWYpfpVv4OFEu1R67hJZG67JIvxXi2m7yrp6rHnFHljxIyXvg8nh7eaWsjzQ
d7SBfa6gTQ9MGqwvWetXhDLE3qm36jF9ikwLNjLQ2fZTqm/hM+BOOAPl0AedwRfyY9ugdhzIekpF
FY55pUB2tbrqglg3ODRyvCXIgn3SfVhFmbISfgTmbNpPS1xR/Ij/z8jT1rVbiRyBJIhAtxZNq834
6ZxHP9n8WjzV79Px2MCTLyb2cAza18HbLgUJWqh5/HmpwIVtkuSv12zu7OVbqYKuSeini24PYmRJ
MNZvmdj39CJGSZdtQ+pl1mFeWk6d8xoAgM/eYar0RpHYaYRNO5aLiQntaM+44pwkyvkI6SlOq+ZY
wlwsmxEmra9jkQS3KNMSyakIchzc4lcxs13UUem70e6sZVAAD+xIpd1TxO7HbTYpW8dxmpC4kzGQ
bCa50IPPjU4HYPFsq60klqxKE3Dhn6MBP8S8DHNAamV2ErjrXYwv6UpWi524EzImpgo83My3S6Jl
wXcwitRYxnmbAsNlvmgfxIMmm2jef4xaMDN8tWvRUYvooKbaHvEHLeme7rYGEhpLfM8C8OiWfL0G
duH+ra7p23BnzW0sS5vLHcukXwfcT59kt0BdQfCVaeDV/3q5jHnuuogeEABVxJ6ABQ1XAChThodI
QTQ7POpJcEWDryXKFzmsvu4KFil0L0yhD4drvQjIugFwwcN029Jj1Gwz1bSgnzYEWSJZqJ+1aseW
7uXNgvMyDhRJCWkF0BdnoVHFAcZJaQ1Ohhs07VJpvRPmQFkS81S+DKurh51cyiNr3IX2BGErHP4g
99+HKXv3/frRsh+5QBBxpH3IVYjLqpRWzjgdyzzgKM7BvEqF1wgcbk9c22RQmAx4k8LshnjVf1fX
53SuoInf/dlaZ1cvkHFieN+3GTDROPP0nUh80f1FbzV9nhvOWoL+ott6n/HO04wQKO25zLNROi2P
yNqZbz1C5titQzpKuozU5d+9vkovzac3Fnx473aPY5AlHnRQI4AaR7n+J9QHRI3vdFXJUuMue2zV
qWzdQTALLyTsnRWIm2lITcFEJVNLcLZD+1VaqMKTZUIJ4uVBQjtJabw2Kwr3GsT1ge40Hr9xKMl3
GhLanQHd3i1g+cJ6WscumIhw8RtsiUEr/Li38YmeAv1tgJPMLE2xZaKX5WZDPJ8qlAfPVmkgd+Iw
Pikl/H369qu46g0JR2rH3Om1JCfzNmq7MQ5MyXB9nrgoAj8WKHybnqkmqoZn8wOeFBTHQH4m2vDd
qYpPY1x9MwVlcaHs82Fw+oDJE7pU93IvI54ilAuLULszuYK7bFS6Xi2/KLmnDkYFvRtIUC4ic+T7
o3C0quXpNkNxXguXHyTyNoILAb9tBQrIBnA4r/Hk1Hua8aL8WBZv2SRxMyt/Knt4K8V5kp6qFdXD
l/RjMP73Ye/HGJ3ureSbsLNgqxkFcek+JKuk7ONmx7+roJqOHBr4IxnH2nZ2I/zEyh5aTnR9rwHO
/zXqMWEdK0flj4n2X/KWEK8IrJndRLLKr4SLzbdEuLnNNh2GIXllBZMFAXDyv5AXWqhGJQx5pnHu
CF1Mjv2xZRFc4fBsHl150XOGtra8h6gecsxtk2JEBxfUICdF+QhMGmdGRERk7ouVfAPjoYYeS6Ge
NxqJblEPotyxrcPy6ghPDCOuJ9i6abfCUVgoKYAqpIvnKrwFtE4PC69rzMXvxQNajJTeYP60DAmP
xWXLqgSHI1yQlOY3TSetEtkaretx1MmRjlCJeEnviG7T3Taavw57pEYW2qKilSF62i8AGHDtoTZX
HYHy02dpIM2tC1sxyh2D52NohqJ4eVVQg4GJHxeEzDLXE1cKFd2ojMw8xa3SRShXmc074knPd7cK
MduivC6RvmOWrlVvAa9LPQXLSli+iH6RiuXa3YzM5Qa2tkm7berohr5S5Nr2RhpqWuLw58JgzHNu
xGpt8Tq9ACYwK+QmhCUz9v8I5njUKqXKlZeq6eb+IcKTVF8d9rvBlrtDN9VeJuzyCGqFXzlqNBTU
+ioFYFNMdUkWX5mZx6XSvDSaU11sxYuc/sCifDosQ5QmKZIFMMy1B/+KhL+wRPVsnrVQ6BONcOTH
HHD49QOl4FI3QIU5fN2HIcpI9yrWVreG5yyyW08rQaGhGK2VTsW+dS3PNnEWf2ya44TsOuHh0Tnb
7aONYrHMiAnIVZrDMafd/gbNIaizHrW29HpR9z6PhTT1dbKgSmGP45aM2WNO9/Vf8XYpQV/d5fmN
yStRj2CleKER0AvRa8sOf6uCSyhPjzDgQCKHYutAXce4o9WJPMpxx7dKpBZVK7P2RpUxsZoq4rCV
Yfb9q4prb+RrLqhCZGZUpelm10OKPHnb+o8Obk/uDPFXSjpddqzlJ3uGa4057qCFbglzw+LmfI7b
Zvz5/JFaNYccW3hfPmeuoHz1XVq7tP2qN6Xtl4VBZNWGdGe5M7CKoKllLJGhWK7wnqNBvf8MtWzj
16/GquenTXkXK0QDaVIoN+jOTUXlvcmyboqzGNHJN2MIcC7q06FjA3OBMendU08qrkVY/lTTSMJA
nmX2Pdk8etWna4nsb8R1c3unRL66sxZOxBn9gM2+H87ZN7wTBnRro2QcGNmk2wVokcPvKkQ1PvVd
+OPmSjyeS7c/Js7u3IPw1cAzThcUAlgDk6mpl3s7UTO1mvCVeu+hER7tPsrdHRSneAUrX5wmsOM1
p6SjmOzEEt+qo2BRL8QihAnfqgkgv0Vyhy5n+mXL3JXu6lT7L6HS+eKaa2+9Zdxsp+lGujkj7Kya
N2wV52HBMH7pcR2qEarR35wyfB+09thVQLSSi/2ZpnK+wtJKHs8I3bnqIIyKL6Si4HbNOUzpuQH/
jpDSxYMPeFpK2VpH9yG10L180/k/dOzgz7G5DBUJoqyMtNZSyxqc5CR1A+BYtrllLq54ZQ9aCVAF
8qQDPNUpjS3rD2vmkWclj+AZ2CgmgKrGZ2R4gdgun7VBefwBR/2qsgjuD72Fq5Q7+M0644ijH6sG
UP/bYbeaq+k3K4a7nRtAg05FYGWVO18f43vn0YzUZV7k90AWE1i/IjLSB5X2M9K5KjUvYgTDWp58
R7yAMJFfcw58UAVt1OYtB34yOdRI4PSNpyhp/NYxtzgDNDxI8nwLioYXWTFW5uCqu3nlFOfvo7Ke
QtpcCNcPoiYCYVIAsXKp+4lCNQ2rNQ5CHDQaf3ZtBH2u2wExpFzv3zPwZB7ZLEmLFHwgSPy2S+4w
bZmJBKZgQkZSOXMVo50EoL0Tuw1F3JSMXIj0OQSPO1xEHZaNGIt9GX4413EnA+BoGN9YX2qyJX5d
1aebcFvLvmycSJ6BDVuX+MYQUpAnRaEuLhvPDtJPdAeQQare0Zh5WdDAIkbyknJyA7vAAFjH2y3G
xP7pnP7HypKUpArbVhFHBGBecQH4PkuMQeho0WIlOBojF8MuHnC+aszzcNa50ppgocPgoZMlMch+
pDpXicfQ4kCPBL4osHSE7dgb5pWCsXgqPF3V/maVF9yXemJ0QinZCdM2yUWT7DB2H6hbnghddNMc
L0pn580AZHQKuyhZcLXdvAqKVX5/dekIzgprHTB+h8Of+8lIMJ+G0P9KoidRmlF3IHDwXHWySyWB
flplq9fQDQoMH+svFp1M5jEBaQyKHSG89aRavY9Y9lgJ+iNsJdIXpERI4T6Md2OWk/4/6e3NZksh
zY2gvJDvs8B4+dStRqUDco1fbc7SIkTmLUrK3tEi0bHGLPCuDG4lHufhDkQ/wymC6PSwnGAG5nRp
lCYGfGByDeN7EG6X9Pkqdr/up1APxbrssRye7zN5jYUvTJga9yomKHTipX82XF/YwWlwU1OnTQZE
k/UyCEPlmTvONK3dx1kopgNHO1lCaPpLjtabubXBGIE//XCKl+QcPp8UQUWRfCN6rKhXpZDGgdwo
D4bZzfqUfn/0zwIz7sDpJ4u6w8qv4O1H5ALR2ZL1h6grnWqNW+bo89XmsPRFm/Zwd3AJtYn+oXj6
jS9pB3SjZnTIxW5/vq+6KuB/lkiVdK/dgG+nwcUvTJcAlUYVAp8VZO96rlKD906H5dViZ42k9+3Q
o1sqQ/7CCCAv3Y2LvxF2Gszvu0YOrM+2i3p5tvMqO5r14Pn1+Jvx1rscfpatOmCOnxXc4IWKW89q
kGaZx4cTvXzbju08z6un/GGulfa/pxFUd2FBaRJb2JQpXgCOQSk4GlqMPpy9aPwNZwWQtwjC3k72
wWG8fvdNdhBpQq4Akcvn9Iwkx22X3dDGkRzr7QKzlYVHyAN1XvIxmlfVeasX25MwGPLmcrW+Ya+8
QZiRzDzQC/ZppF5++SfjSgVo+AeQtHrP85iB1YbRotTPN+wcF1XkMPTiKPnoInsWtzPmzOA5Ck+g
7zpt9QkN2ljZsTO4f3OgyAuJaOEPYVLpbpVMVN5zIOj+ViWo0alOSVZk+t2c/wRLa1A6H8g92B3W
pZv+T1nGhvaSaXLD+0W2hJB41PSYR9BjAcAAmZVRMmCzvdUGjKKxbo6Ka2Uc7nO3prCRzsTprvSh
wwkOZmy/yIkVNRvuZW0Bg7E9kV/dEs2gSaVChxrUga2DgeekYbxyyASD4NGvg/dBFs+fplgA9Jfj
mgBkggnBiWo8lJt3pmHwO9oxBYMNYuMsb6cBwuqUVhC2JWJUksJPkzmGt5ucwdx4eNaeyga1seM5
shrP09W1Jx15LdOG08ZjezJZLMpwCuHNy0PxfwvHTMbqMO2JGbzI9EClGGujYyzbk9ecL9er9+gh
F8w4aDR2n939CPX+vgdl0uPt3x53HvnVv7qgJUZrcWn8x34rxEJBsbkxQdHw92OTXKuzwozD46rk
qYbk3z+3+oJC8mXewGC+7Stq0ENmQcsIV9uBECUdhNvuV5gmUNlzDN4wyotD+ehxs+/XZdVU2z5y
alRSqUH5A+HpCPkX1SHeC6l4emIslSWV4017oVLUGuu/AYaF9QG2JjUKFXTcCmS24AQG9BRDKvln
Kk0Y6JRiCb65L9oWLCdYgEc58nIGG+dpsd/LPfk5sNlybp/z/y65/vhq59Lxf6IPkU8wJfKV7LBI
VqG3r/c6+rkFqKOdwfC0Jlql0c02yLxnhwN+zj6SZjL4zL8IzM6rZmAt/MDMguAzMEnSCM7fohM2
9ShDT6yVtam0YLAfwRRWFkoCWLswMWUBQe6WFtO3MHqI72m5DaBkHmRYFn2KfZnAMGmLn491S4vg
R8YlRjrBm8SjjS2hYJXhceitiVR5WGVMOIW0KRJGh8nUMvRPFTwP4iw0LCL0x2+XHarzmrw3yLai
/VjfzrinCLWY8uFWZP9zlgf7SSb8llY12hXJ9BolQ5hF/TsToGCBlbGwAdg1Ezcj7s0LKsq8qOl7
CuU2ho+cxousBS5ufpifSwrecvxxX+sK4P87VnQFVGLAunIC9TsVAAPZjFLfIVwwPQR6GkpbAHq9
GPkR+LQ2E/fYtNYV1/t1+lZpJZUhDJBMchpNecSlRWScMRFhS9FpL9+Axwg9tr9PZEedh/grRV3K
3thCe0Zu27BGUi9ayGlwKKLiyXRF/dUjiQh5VevIdRgwOQoNl9fhVSWoVWy9DmzUbcpwfvUAKPrV
KLf1UyMyYPoJF1I40h9d2nesNBnqtcE8BUMw9kRjgCAnOCMbJQxPKzmhQ297WMRFgz/Ujg+1WUdY
DHV3eDB1xfVJmcGJWwTpwPn5CPyKRFUyHo4PwajH7GbhbIOnncCJz7RGDp81tzW21Taf2FuA3h3/
MWQVPK7yffsvS65BcmDhKZVuKzTtiPnaVOmeWoVFSI6VjCIYj5Ycte6Oxsjr1siUhynithINmr3x
iSqYfxkmol8OgHOcWfnEYPNejuybTVuSdsPtqMduNw+aZg8fKU9lm1RHCVMUFxaTIPMKMNeaZEiV
D4RbaZM7x6KZKHoX6/v+qZHiVhwLxzFkJbrvWgbkPemcP0wdWjwVt0MbOWYPh3wTmv0gNqJZ0twe
J8vorVBQ6PXu2IhkimaBQdSd2eLEZ/4+LYiSqUB+r2kVJdqpqmqCX8kBsmUjfw+c91oP4C6dgKCf
OIWU82eNRqMeCAic5af9VaQP7ig96PmUyd8KI1oJVwGZFFB8skKd9bNsTGzF7OPCptjLyjVO1hMV
SkAz+D3AZBISGQI1NaBMsFKa3PuriAYxJAmdsanSqDqIyfIa1A4p3xBOmifj9emJ0WG7dIyk1lnJ
BWYJobgTy0X/N37wOg/NzoDhwowFSMhaUwUYQS+sA/lP48eE+y97+/x8/3+XtzNzx1xQxRI+qJEB
2819g5caNbDvRxdFkPk6aymFvA7yd99gC545LqLslPK9FlhFENCF3CAp4KNnSnKXUbq01Cq3+BZ/
gWbMuWAcvV5Ev2WsJXVNS1uxhRIX1A8QYbxnKNOd9mNtH0kavaZWAMvctmKjTtw2Cwd1M3aAN4tY
gnXubb7n6GWQSxcW8h5UrwYb87Ezxc7P6YAtuf/z3nmHn/Jp8nWPpganzVb0matIeoNlyHhrq5lw
ftutp7aeHO//a3+rDB5p8ngL9M9+5jFcR7oIm+QJNGwOmvDNU7eSIx3XpaOiUmySGEvgii2AYNa9
QT1XboBWiify+qat/OIbO3z1+U7NgiGJvaLPKEqsi2AFHKx30dE/OqipqYBmZef/MVVJahyya2DD
636RcyksHdF15ZXaXF9MfDNbJvXQsOxiaUs4OYHnoBN7wsx99uUbA/wW6J+ySaeYbpJAzrTeSDWG
j5XbQRaRMa4sNhvAIeDoGiNucSbJCxK+D04fUZLeMfD1Ht9ih4FXRShs3pYbaHjVCMQmU3nDTSFN
69Jp5k7vjYuBmmStgME5uUUxXqapIoiZZr7Ci8LrzKxd/tZ31k9865qqTukIVi2BFuZrFbvV4OHI
K2xBBlfWVokY3hyJcNIDgFnuxUyMvzRsvfXORS5tITeiT4ips7awVvqEOVJwRuiduhfA9KZPApUJ
POBYXteL0GMDHcNgDrLghgszcnYPGNTF8/RoD7MZyORIOUkj21POlXa7ZjyrWBpLeIHl3Fz+IVyX
6c8OHyGuLcIKrwga8qDtXIXlIsOtb0vHLJGRVZeT388I4odrC3s7bI1YwZAo+BHtNd9s1ldLZmqm
q+lcsoTLeqo1AAleLuxpSZG4PGTfYxIpuYTLM+GeoOIVZmVdJlBMpBhdCDeW10+qzSGzDjB0LxER
LqrrfTdeINhUFNjxgnN1YCmwLFpd5U2UaXaBYBIkHjeGOTz4xMPT/IduiothfOYkJDPewEjFovh1
5gpuUoExj6cu+HsmKXiZj4MqGLV0Xm2dahZc8uLcGFEtB+8Nurt9yTvsqEvdpH+qn21EpJYm8SLI
70DQb/BYAAy2Uu0zBpHnshbyIf7rWl/Tm+q/Yc3WUSL3bbd26PebRm1HcTVzDZTkHrN0PzqJiOZ3
D8dHKAEHVxsGXQxBPiBwXcs2xgpcmBRqEQsNQ+D28gl40HXoZDM+wJI3Ewgpsu6edQ5rTb4kETyv
2PuIVOxtp8iVkmHtuhTN8uVTJEQbLEzBwrLovXJPCiemPQUaiwA3x0vxN91gFQ9bxRMYAhq7kaa8
IjwWVPCqGywjcetb6bTUB9Uaat27aVy5LO4GN/ge4gC+fp1BjISLsIVd1WHv7grGtfyucf9q1T+x
j8gp+vBAXWDEpqP3Yp6g3z9yDHZzVP5pa3AkctUgP7qO1XkV2CI5lh35uhwTCcgN9P/ToWbp4qov
Ns+h49EzRBZV+yUS4DiLjcHE4+G9VMjGgvGoAbXEKkzl0KPFm+TveqmTStnmDoMVum0PEcGA3Y7k
QBYNn3ELVrcSqrjW+Grp26cDBI9t0d2xV8QE9gDs+mboykdi2mxRJszOMpXpkovSyt9EbhKDNOVN
ORmNborXfke0mCxc155Citn0A8x5txr1Zl0N9iQc7ngi2gDtCPVrXwBxHd4FsPeoozIdNImdAB1d
H1g/6U5GDfcWZNMuUxPMw5JWF8TCRaazfFsudkMOWpuKgKkyJ230rPGYUQFwpWNg8uqf6xVJGIal
jbIgJDHisVIU90d9J0lY3z5mGgz2qJG/STcAx69vFFzvcWCkifT6t3fj3A2Tp1JbTXGGwnFh4aWc
+aUpOJVOw06SlRXmc3aXmgx9qCvtBx6sMX+omM1DqyG5elozQf1uj8GOZfOpop7cu0lqyap59pIb
4ddi+R/2BFRdWYfPz+e9GvcGs/wy9RRuVpJ8ABIm5KkFAdT1lkxVW3+WrMKLWMKoP6DdJ8h5DI1i
j3PiYZ9BjAkonFzv7mk9benGW0mj28q5XIrl0AfvdSOycTVJHNR3ZqvBzyrrlTHHuAi/j91IXAIi
W+8lVYZu97SFIEUqtiBRbY/YvEEefBtaxoTtECF4Ln3f+tGFVl7ddVTLTojxtOcR5AT6STF5BsH9
ahaV6PN87efzBSoHKJc4ESr7kJ/lK7vzcHxVRBFT66BY5qCrfSzHWadJV8zJ49jlAwuyH0CdOLaX
tUhaC93NcxnyigPBcmMwWC5zxlOphyUDogmQyn+n2Mu4UhT8VGusbA3j3dEKpCX/SANxdJDEytMv
d5xepYWKsdJCB2iawVUh5ESf1DW/wo+2AuTcHBRw6HJPVKquVcrN+iBj9zp98bQ37YyQOzxIaCJ+
JAcLdDjB5NdLxpzqIOVrVQv9S0GNeAhHK5aXx3Q4LZBIWBOQ3YQEDvJIs0V5QPw7pnizrAciuaB9
ffuepmq/zjqd3ggUtyduxHg2mcdCo+zk8law1jfB/4YZRV/qrZ7g39zAtZSK5y4Ofq0OziOjYcOJ
28jlfAG3JAb9KvJGSwE90rMWo/x3ZC8TvCZJ7NVnCY4rtBNfWWH991h79suOQh5TyCQCYVtEZMk1
ANUHm2isB7svM0i7mHUPGlpvf4HX3BeP+gJmyH5XkZshWZZ0zGtbKH2sVsNRzXjQJ/dgWFNVenPV
halH1ddGAAsHsMcgGO0T3eFMJvvJoNQytydP/qhN5Nn+zvUKiR1Nw475sDIwaxuUXyyqYc98kDF2
mKBXn7+OXuxmVVBLz3N1oM8824us5Z7tsKW99zJSswIwTYYPhMykIkwdeWPzyWBLfJc5Sw+aa9Jb
smA4GcmNpjJWOMGn+DfWtx9PkvwDliMqQgO/VGmY6gIUHgZQj44nolJnsh+AVJhH9F194wb2d7ri
65kq/CgmDJvlsGZ5W/fJCzc5SABvNsJZr3Jt1TKEjWDtyrWXBPtmm08po2Q35U5dm4Fd3pSxoU0V
zAKh8wFP3gfLBeQfDaP5MtRguSu7Y782Ro+LwicPCZtObGx7uEahkrcjgDIFlUVcnXWUMZMsjgJj
/m2WVktNV989SgPg439TA8+vbJoUsj+3Yzlv5adwHxJuE4y8Cb8Ccxy1qtrrm/ltXRHgcVhOnicZ
enzqHdXxfVyF8SK01g339jAR5WVMniRFN1nlumnnv5sEd9YeBYsAJj7lkmQI1mvvahgFrOdXvCyc
o7sSu0shusN0HSWTREAssUBgaU+0HEyG09n01qlVhkuEA8XcU8/EnmFVN1M60iC2ajvKJ6AeIkrK
iJC/m3TQSavKBIAlpKHvkX3ds6z1m5R2oRJ1lMnRGM6oX1mnYuB3kI9t52kK7hynZ/LhOVLu75IX
S38M7xVzhd5CHOAO67e/Pij56fg5Q/QJza2jN42yLAexosv/2ycYe+aOEhszfE2ZQzs5z2To243u
F9G1yLHFeQDCG9tTw0cXPo40Uz2T3IJNMJldNZRRxut+CdHWHEz0vPP8GX59ljFUSYHoAfr6YDcJ
/FX9vAkai51omrU/bjKCBDSJZvLZa46d+4r6n/ZjPIWjiqGRz5tW/GZ/lpRLja1aX9k0MxfWQVtG
p30ZcVifXhrU5e3QlhfMyXMvxnVwSxW2tEDRnKa8Kbtsq96Jb7MexBUaBbISsE7rwV7mNYvjZbxT
ByqU0BqTwR4lX4lvYpOoOUHrA88Wek6ftXfahhezQGmrrxvbjGYoHPzub4Jm0AIKrTPXjRWCxojk
4mTeLWjIXiVPENA6XgMCSyhG2Ny7H7xA0DFS3LRjbLXjCT76uCnkzFYtt1xXPVa6fCXSaxA9m2Om
scOVsi9JjN3ast55MUvBg/NnvVy0voSd5gzXKhZzcLUywD+hWyqLeCDgmMBMmnTHbo46gFbasF43
pVKez3RXBRoBo50H3SJIinEyZo6+DZbio3siLXD1vvan/0KWig3vLfg4jH+cuj23vLJXfOd72ZvP
JNLB6f6bG35lECif4MSgadGeJln2H1y37rCh9DbK5kOJ152PZvHyFQZ56w1ygTTZusTC+leJ+xQI
A2Qd2zhq3rkOT/hfB/TaABe2T/VBU+nW3VOPuX48iv49A79lQFWgTSU0O2JHtJOVQcUJWwWQJ4jl
W/lic3Hq5HnHpbfgiR+2eOG8zPP8niW5nsu0gBLZn6+zsBtNTQUX8VD7Z1XE+ZiKDbljxmA+Z+Ba
AC1nhXuuKuJOMSQDRBwrRGPbZH0Ok27vMo438v9YjBkDgZLv0tyHVbPMhadXFLmwjTbA3Y3I5bGO
X2J5omAyiZjXyu+HdFkG1UTGJfArzzeGzdsSWPCWBczcMxCwtTVkTvLOCJWMf7K4re29yokosaQW
/XHZ3DtoaiTqDKg4WbBpN9ht5uiTc+FNQKElva3uptl7vVCSqOfTZSOkS1LC8xuZNw1YWHdLUDyC
lRgXBWWE5s6ozMvfO3xep9mYjCzla8X9T/wh6NqGyv/hjOu/8neU7RnFBzI4ixp/TYVXg4XFW2mp
MI0DAmuTLeCxUCh82jvYLu+JSqqSyHwcLascVKq10Dtv3xdJ6rN3gHao7CHdFO3tepch3s2tGEGD
IqwRuURDpBeiNNI/pzxas/kkXig1QtSEEFVhCE1owZ5Jg1eS/dBgBSApZlZGhUd245jT6VmekRv4
lD0h0HoRXJVocjtjVsRUDC7xRuZ0IdFQQkuH1l+lwnxTTAnDa38Jlrw3DmlCTpuvp6S38fjCFi0X
TaRzLrG5lcKu+a3cpmGX95DCDT80vrPxj25NOH+CCFqVvfc+c91PFnjkxeePci/6fOB4eP09VccS
6YmmtLkGcjsvmlrc6Dm6X8w+n1stfxdWtfKX0IeoYEr8GuN9tSG1xqTAHeHFCy3heltdS64/7i6k
XsoKvwMIyjVbpuJEQAwojYd3W31heSDCXZxYpEytbjzH9NKyhOonrlfVt9AagOuswZEUlsL19tgM
Q3rox1Mz/o24aF0588UK4gD6Pmjse6G8yTwfl4ycOvDUJBbbyNSfdjGLA5QMtuLjBQBAbt/tztgb
N2Llfny/707X18ZCzKf8v9MJL13VRQ+XLIoCdPDDIz0DFoY8wpY71NXO6tZYVj5x6xTfX4flj5Nz
WxwlK0/BF+Xytogyley/m+HgLg38/oaLH5z+ri/oHQEnVr0tAdYhzGa69cwWNPLSGhhIfxkZ1TMi
VGHmo+6epKrRcqGcOCmcK4eyhHxhw9bVn5BGWdtkuZnHQNKsRfmF2VMA+JZIs7rFPTi+qY6B7rcv
KgSnGftv7RsqKMKDCbHaJK4UKlna/PxYcW2ahl3wkbhwSnDDVlET2+YPNJMiLerBq93UbZ9LpMz2
Qrchm6bX+WhRsjHEEHnlaMIQJwYSUPMR+nrymCex6/rhLJshaTq6t3U/+JHxvV9HOHgJYHbLz85e
XnMTnd+BVvsDMXqUqYgXbMAPTSaWNa3pCuQB02pN0qjTSWZmv2JXaIoBRbN3C0rMj65vEadve54I
+MI5btXbV+/MnT9lqp2LhYV++ZxLolmAyo/L6DWPic1u+KGCsH5DZKzNbYwvBYtq+Lcv19VBnkHh
uIjUbh0JCDvZT2O+WOuF4VTXWnXUILvopXj6xEohzyIsPC73N/xl/mKcUl5IcjQSnecK0RZcmy2J
t4OHtlxmMsq1kPW53Fq6MCTOyN5TwsX+7qZjPadyVzU8XIC7EgvCmAu9ZrgO4ciNA2sBPVrMSot9
v87d20Zn2J6wpKrUdgncMULOs6i7xpy3YjDeB923oRAALGGENEOkewURNFu9yeBSN3SBmvZJUbPx
F8NRmP05OIsvUqEpExgtLM8wSE1xHoo4sT1PYzcqhFn4mMMo/LGPeAazoTjBMhfi5gNJrrkE/0JM
uMeuhjclHveH+MD4SyMskW5lNcgzbtSGIEwLRhM2NWIPe/7V2HqNzIDECx1EJyssoSZyu1MHga99
oefgTxobiDaKHrk+rrJ5jhYEbLOrgMX1F076QrSXb8uPfQ2B3Dz2xfWJS9Ob/3/pXTh7tatbWiF0
BuNJ2K6uBorzH+pDGtoUAQr0SlWyJeqIxJ8T05TB3JamseqgDwBoujHC1ctUFgEtMPPEwJTw2zqi
x4T+v0k7yrtA/Sn31FtL/+KibmfYzKJKZSLu+BvOdrv3epu6vIroOeEN+SkakxUQs76OFFdPPjIt
hKte/v02Kzq4+kRc25bzFuhP4jmdzQm9Vv3xiL8JQIuAlNSeQR3tWjuJyhkqgbfFmpBCBP+Fw9fJ
awjwLAGR3gyW2fdq6X4kGW/8dyN4uGaiLJpEeETLrCYCCjgzYIGrtzFBDz0SSC26DtJdphJCeKI7
dT3q7Qgn6i5zxU1Z+KngTGsOOeuQCT+X5jSIVeKhtKwrjFh+Z9X9wmms8OFFWsLKvSu+fFYkXL/k
NxjiYc0ifxd3lFsK2S2hMOhxOu26CqnYCRNJH3XE/pcJllYeOt6VPmUwkGzHXBfSwXmx0ARkaYkM
r9Yzs6ysMC8Y2KJl6FrPHpR45H9VmcuhRq+DiUDV2Qu6lcScgo/cm/wATyOpx6+C6tvfo4kdhXMn
uD5nRaOfFi7QGhuQnt9QE6WWfrXZ+U98JoJV+oVkAfZ4TL5QCX1QXKTzU00QnJF5t1e1bMnIPZKo
DTWZvVyridJ4owR2MrrJyp+9HX936ubAH3qf1uM+oVlhGw/QOjX1CWz8O0AqM5jfP9zBZsyVp1jP
RIqNiB8zXmDu89J13+ltNz2AoIAvGQTAxsHps9HGVdj2GiOsxF1xEpeb5FaNky1Eu1S31GMACbyO
gO1Kq9OHsuKgEW+HdTEkVp6zPQExQ1cZe4wvn8TyqECfTyWBWHyrGqIaFsNxjUceUUASLWr3NpXj
+IQbWBimqwe/iwqxpGJFGI9mkuDUDap5GhoLA61SkNNbG/cMkJYj9bbubSpr/ePfJCe1nIbZnBWD
juNHgMnAkx9D1wOxWKsYWYJEER3g92ythBEArREluVlw6+B/y65z1F5GI3XwLjxHrDKtswH4bSR+
iZ6Be84rMIDu6lS0f/4IPbDfmxZ0GeXjDSDWiwY6KyeL+doFuFZsIuEwzKg0zhYN9/kfg/YHpNnQ
jtr2/Y5BPjQ3YIwNbyKcZXBahWwcycTRL/WLgXPcNhn7w+kJ/2Co39vY42Ocu8Tcsm2yi+n3DS3o
z+NeS/wonsmlKwBu/CLGv40UWD9KVMxejVgHITS6ww4pEehzxLNn3wpGbdTmYPs3rinzI9EyhwqT
aENNLHU+Lkxksm7WDCbMCbB2svNfjBz+Ii82X/WYi+pIx0XLX36SXU0C9e3sDFuqL3ihX+q8Mq/C
BnuIgTO/idV0RKSk2ygVPbDLi/jCDOS2xwFJeaHIR9J5KTckXqVZWQPMHWd2L7Fhib6J/lSxEkgY
SG/40KeZTT7SB18M6igHuwUdepNWB0KjMYUnDytSkanE2z7ZT2d/QF/toPLCsX/Yds/y1V83OZC4
Sq1n2o8Q8+g/FTEukMJ1MaxvROqALR8dj5RvBtj5xtNdSy4ipJYn04foWjcZ3KQccDmnreJSNQ2k
MSzIBReDN0DlFD2FiY2yyL6sMXyBHXu4rfBjNUqoG6DfvupWTOF/6bVrHGCAQdpz8j5vKjXFtzIb
/8ZKR2KPjWgAUjRZmZD2ljGoDBxf2WNTMyMotCO9aCnkh7ZNOCUzuBz8DWwSaRaoJqjwoOZMAHl6
si15X6jLYA1s3Txd2hG9VUn838hJR2hXGXpPGohl76uzNmV7ks/FJbILCxK9nsRKDeaOvtQM1OjV
KvuAGXyn66qJ/SACXZ35YEj2Y2csIdNH/YqSq9WZRA4+4vKIgYJXCQRr/N/XJZoYTaR8FiggEnj9
HUrtBY3GXkYC0Bsvwb5P9Wt8xZIL5BFM13jP/SGxEjbeHZh9X5bY1YRImnYL8svG41nanQDBDUT2
qsXruXbxppgBF8ft4oZyTTgZtpQJuan8zelK7wKJ/j4MQ/5yboMuJtoDQ4fI+ZkpqADAGiF52vz5
pb17TJJ4AsgMjETuWKMaGLtMPpkoxTEZma8CEG8KaK2vtFRBy0wRjWI0NIYXRnd02gsKuao88E8k
LHJyO+BNPHfffdu+pxJseuXiL3CoI8q/e9yavM88Y3nBS6VGTfSU/SMGufbejaUwwg42ELbITCRc
eZkAVtqT4+9Mcpu3pKlJjD9g9CuTp3xUWrZIjZr2mRmZoiuAmyNtUNJ7wxKUuJtxie9qLM+OlsPc
fkpmrh5p2resX/EMraGllBDt8Mr8o9zxthClfClH7xyRjJQNjD5UAd6AQCJvIGiQzjTnDGHENYFj
1d0r+SKkVSm4z/wYFwQo3GyXCYo8OtWmnpW+rNH9t982DCbaUPfLjotZEW/6P89b2J/oy2i9fQhJ
KaTXCNSZTxRDv/Hm0FDKc5HsQ3mqGH6fKNfRID8QPSyBy8Zt/xB76OAhuIfBvzKkcRxHxaGLp4GV
knnXah3hdfk6HiSmjTsfaYRTBFPpragWW6z9k+cZw2klu0uWMFA/HdzodVq2ID3vgyv83Eg7Gqe3
s1biso/1gIRvNGdqopKKAB84jdVo9t/rXvxTrBr/g18SEOuzzg53EyEVe4EEofJNt6ny0z1KDu1F
4Poa4b3wuglr+08a4JmgRR//Keh+JboTWRZ4+g9GmX2bIvRFpcZC2Ej+VSvF4DiHHMUUf7NGdZYH
O7NlpQLE6GbLWzUHGlJDUQG+ofyf3FSf+Ztgb5dRDrwlEMfrp4qjksTVNc8kfWTGPmvVGjtmdPXK
czNYcGjaSIGBPebUth+ai1DtsfW1ye88kjoHFDwaQp1ZoCSbllvKzOT4DWnx1D8CuQ1FmUz3Ipb3
z3t4WAPCI6cL6xT3ehukSkEDGzJQpUlRHvVfLgQSu+xy2k0uH0LR5WAqDJweARH5T+d8b0LY4QRG
AKlkX7LO7s6yxjvDKsVSkZfuRm6106nK3Q16ESuPRp2Utb+JRdbdCtDJtbzztiRB4SpB1hJaHrqo
/tU0Ov7HZ+qzvyFSfK6w1FL+85u06O0OPypdeZTlaKvFBS9KdImKPhfdzkirdIY1/lbo68OplNqd
t7nwD83bMzo5wXY0ZzMWQPpDoww4m6FU+zz55ZFvNOKkRY9jixs4zyv85yX/QFUaUN+QNoYhU8KR
B/3pw99eCAzJRntKe2bFPeYNnn9jiPck+je2qJ1L755aPupiOlM+cBvMSfWlQSZnDbapgGRydU4S
cRkDEJrSQsDb1Zkia6WZxv7W7iSQDWqdR2saDGXUFwtlTcZIJwS+lUyZnUAlWHXV6O9xuYeMUxOH
igYswFVzIP3+2Mfj9JTRO1k7kXL04QwQstCm4H9BwHNAXKd+WK0hlsHW6bYZLfYMy6KsAnh4/gqA
cYJuDw6ueVRc+Za4SfO44N9CsDcM7n+dZK5XgtKJpaPj/jCe2MCeXLqmyduBcU3aAyO2MFiwnBrw
M3rEsX6k07SjoFDHGiNIW5vSmZGIBGFY9343fc8+NXpr0B7YXVyJnXWvy4KANiG1nL2wZZqW5RVF
467p/L7aaC+o/vm8/iQIZ5WW+VsdTwUARgNBaw0FZvO++tSaeD4LnAMFK670vZ78SOIFFzR3St3a
3ubJxAL9PezuHovmPaEjMRRcaPogiwWxo6RPjqOQZosahFqJgBaJl0HpX+iOZ1X/3ifvOAIOKjOt
in0jxW2GwOaZaJ37K5T7Vhr1edkh951jCOZPN+wsc8BMN5Vl3ZiwYdyDEHvYMBckKAi0TTaXx1dx
s6wr90GvSdyQrVfZ5ymv085H39sS1YdCNimTzZLOZdS/DWUYSZufAsojD1YR3XxlipFgAVWkCAF8
i2QAOVL3Rs7bJ16hBPjgQRz8f5KyuNqoVOxeoxG44t0ITDk0ZVVf4mvViJA2BRY9MvUuJtjKVSqi
NsOJJObEwU6cH6OEtYCjWsud8/Sn2PFp5J4hlDyeMTuja7HG1ck5Pn5our49ujJqvaJkHNMTgwbE
QLPbXYArs3add7TTG4mK4YSNSp4jrtG2QPOPkUVLJwbtxHtbqIzTn+xOy0FFSfoYU1Qz0SNFRIh/
yoYWfGpRKmbdFNhGNxd45z/576C/SjUYRsbuUU7hRIcsv0KgdgWzij4uKewPishc0/GD/LoGL2z0
7b2znGw1w22Ngsm8GWizF6c4Ngog/KBe6PSadECBK/xJwVzmQixWvDmSwJmDhxeoZYyxJgkcKxxH
cviJJrV7B0S2Sn96d9YjZcsET6K+91Ym7nURoEWUqjRXbSXtX4akNq3YnT/HaXpLYMUiYXUQd+xG
QSemcxK7PwLxQj0FQGIajdgKujWL2mNfJLlr0Igb/4sVXuDhsRRNv6TGVsU0SvaoJO+SUsNjjOCm
gIUrXjoo+yaaFijz65QGTKsIBXhRrYWEOkgCbvveVMgh05s6V14ILRQ1xZaoQTG1FkWn4l0/3T5l
fPRU1rPgNIkyF2P0terDeG+7gFzJs5hz43zm7LP9s36RMrrM8AZxO5Y/6VJnEwNhAmPn0d0lBoc4
xAHqh2m5FKJfSe66au6Eh4ywVM2x2sEUH/yPtMrF0D+Aizi+E9T/6xDXiqPn9V/VFjxQeVHaQhxl
4fV9wmxOGzU0IyOQcP5mFlCVho7GmzCdMyVgoV90Uz4WdicEg1fWkpaXnaso2Yfw0zOP/kY8dGFk
IaalAl52gYWnCdq6Rho2m3EuQ50l++Qz7mWy9XzJy7IBX6eB+HPh5lPkLcTAP9/fpPrV7oMQMw+0
nFq8caBEl4khJtNauhfGyLc+MMDju6+HjgRfDnZ+Y5LmzK//8ebwIpy2R85FuuOF8uQcw6KSfqNA
3GAPzMO8GmO4skDxDo3gI+h53oP4G+z+rdpkrO4xNbft+11A19MqpIKjYdNup6i+fvNNf3AWQ9wg
Q+KeBAYyDU9VqVXSO5bQMkTGmR5tBT/ND0PtcgSBo5E4VNJVNy71EbWW4hBvcJ2moqnJc8oa4gJH
Ve2DHrYGTHh+140N/Eh3kgfHYNZaocObfD28LDsDWpIhqalEcCgxHBLeJ3SOUIVhZ70EIbJoD2eR
e1HnuL+SjX1D/bu9zBSVkFkRDsXnkukbD83qRGE1RSc9bCZrxAu+QeZ+8TiClz9pEM2d3GSIctkH
lMPX1B5V/RHRpXqv4e1u9JTTPd/UPNhq3YoDKxJhzXjyIse64hVVK9eMevJSe8kMR1p8zhvehi//
OgTPmBTEqc7IXLyrUSc91klGmkqrPXu/ONmyiPzhedMP1RiXx3TwH0PXdQVJh4lwFiSZpM0VcJ0y
t2lZ7auVehjbRY7MEGymN3Xg9XO56mXH9E3GcAfp4gIsoV6ZgREk18J3E1VIXgoOoIIMtmOnjnFx
mbW3yJrQff+JIB7xm101WB1pf37Va+RVcOzIewwYzFx/vbjMVKS4y7viF01aoZ2zmfeIwXKHDMER
cAFPgaAryIvZoLK55JAoQwkRpo5zP8BwnSU4rMCa8D/Ha2nsQtRSw8Gm+T6Hfwzuz54GCLr1eVU6
eWcqoSeTN/7kCtP0lK5hsdYLHLvvP0uwZU4EGTElJsWacqAefz4pT4eknmlsIbXHwoL3YlYUwYy/
HyQ9mlTcmuaXTZ/U0MNAjh50F4ZiSsCAwQPwpmT6xioA5t/ARRLg9NfoGJJnNxOmJIlQdsONNI15
PbZw6zNS9GvKkQRcdCkimEw6o/mZaITxrk2QlgWFltICpdyLyqu9p3SzOpArR7r0iSTl3zi++hfO
AQ9+Zw+aHTTF0/8/GKmE+MsCh6WYkAaEsO/ACadJDV+/0m3s+2R6B8owz6LFsdxSASfiiGRCUwu3
BYZg0r0dHADyFY8yLkIJDpF7s7ckHp5DpvBNp8LNBYLIYbbhqCFkEo0DKwutFXFJAxXe9W9c2fwc
t10J1EGY+CygYWxWV65d38qQLx2V91bYXS+0HEUcr6WqU2m7LKFLYnrfYVOKNPx+VFytNyk+ENnw
g4d8Qn5RAbfEDqSdRBE8OzgiLi/HCuuLsacEAtQmnvhJYDDq6e7L/7O4YpDbniDKY/eJVvuQRIvZ
wwmpLK8yFX2mUxbCW4Ln8eI8Qj6Qo4e9AQKAuEDaHVALe29DjdSFfHvEMWGehazY0GhhKZ7FjWdT
f3vNsnKcXp9LX6But5uCorro/Fa+OcueIkX+hlHnbs9FO7VBRRb3Yaq5E+TnGnP1+Wr0fjYSxiTR
8npDZwU/F13jS8Mb+ku+Vtjjw+CAz4BJX/ZkMgAddcSDWgeO/lbLeVTLEEo0BQZZrYhJJRIlQyDy
n9s94+dE/4AD53/PjuW0f8LkGTVqdZE8nb2iAmSaGsaTUNtJL2urKwjFyIkBj944/IHbiwdNmouH
GS7fvBkcTDozfleUUtPPZU1ebAJxUqI6dDlNvZP58TagA8uUd7/3IWT0bMQmdHCW1GLKv+ZNDD1i
SJ8Bv91k9U4OQj0E/rJDYZI2S+oRZYav09JbqPLudTR5Xrod/rxxGhc4flcb3ecYQSbR78Xc5SMP
mkWZxMEd8QSfnIxCpbB3cqZvDPMUS76UF8lie3zeutJaDZ44ljAOUZaJ1Qb07J8uxy25SNYc2ycI
87vvXYvWGLBsCF8Nhu1JNPi9SxQ6M3tP6NbAqa5EtAlMQIKuT0+1Gy6PrcozhxJV5A7elwho0tOh
AplPbaF5SunBILEQJBqO4E254KadiWaVwHUWUsvOlmus8tPq6CP9ctNauzXsp08Bbk/5TBCHdVO1
fa++u+fWCrC2dklThqkqtJaDXD4A4Of2lHEFnAOG/qTmKMqnsx2u+2b22axeoozql3xo9QmGaCSN
q9zGW4Wwn5kolNpsDP8MBl38Raq8fwVZQSVyW+hGB5Ov31bDwnvmu7WUd6SI4mgolRPP+pkbxNCw
2s4MKdGTvapivSWSshVXPeqSMJeokp+ygBUYgs2POt/A/L86qXG14XDEiuO2KbaN9oyzMr1spSHW
Ki2AKG60KhZK+whUvDwLeIB9VMk5Ojs+7nX4uKk1rpUYboY2OUTJ07XEWBVucxpdlS6Eh5KDO88A
r/jdKykYfI1grE1vJz1fTkUu8Sg0h167SSss/sLPekuuLC9b0UGS2B5JN7iWbawgyYfNHz8gTzoC
DeOuXpuH8MSqrAMZOKjSGx+BdJVyLNjFWyxS/aupwjdn365s/Q2R8hu5tSyAnqSLbaQftllRKo0K
WeBW9QZ12g7HcxKXzkx3TM0UBJmiBdEvETYlvAIyaM2UdQ0Q65jjX8/0MqU8uuPnfc3RBKcsQf2L
PrXjpYYFTGRw+ZZXj83AsVcX7CIA4+qnjvkHti+eN9ThQJzhV6OiRw/p43JAmr9XtS1fg1QQkpuG
9/lwbpr7Wvvbae9qMMmnz2nXNczHDQZK+lPd5NVEVPn1eno8mqNcxu5fyAAqW9YAyrSxsR3cz1c8
zHInYGPupB3FI761XFKMSP73o+b45BDi5WBFWN5QX0reABgOvZZbtJVPrtfMRwK+ugy628X/WfcD
b4PmYbxY5hBnHzA/ZNfQ+CZh8htvbGNSgGQqi+5fC5XRg+5B7TVEXTXN8s1zo11In8V8mc4v/Dgh
XiDQLd/X3AqvwP0VozNhgjUdz+nAO5JMQivssn4OARqt3K2UB7s8mBOS/QVUdRtpuT1SxofmZOs7
IiuRjyPaw4EA78v+u2sa4wfc/bnkNYh9jNCp2/PiiePfjCdiNjCNc8ZKkEUOyMJgl4ceLFo82Yix
AvV457bMdAdl9tbgLpR/W3oMDyTekHQdkA89d9sgWYzHrhUdEvX4IAfg0VXsnPo4IxreacVQ2miQ
1BqGVLHKfWZuDsxYBXenKCa7l/tSOZ4kONpav8SbedpUyZa1ct8I6JQ5cpWAp7wW1trhrk7S3wo6
2bNNzKo8wXBErv6PX4E9Bw7A1yQ1Fn4yjijnYKWsvItGGYxvYhvK5nJEf20qElTqaMIIEJdSSWCb
rUSFvYuNIHwknXAolZRN0A/x2rCEIi/k5N135DN7idM0++T5IPAztHxOwTaL1rZIGloEsi44dL7O
0snBO36osIeM1ny7VUtD5n75wz/qIQq0LN1+3PUrYilqfiWhanuBsOPnDVQK6g1Ux4M1sFOyflqP
NZddmyLx3uDIdTlhVyZLbL8m2QSVfhygqLEIJVHeoB/fQ3EOdEg2AIvZIBcfeZxpE8X5Ol6rDrfs
OA50PGw+OsrwIdX1eJHcB1i5tX2GPgFrvghnBlLCp4JgcZwXLEBqxiIe482O4keYlGmgYRDVMY6U
5ci5TRkwz8wVg69OZCs92dUiYGJZiUgmSbnQwNZ/i+5IOz4pvhgU0s0WuptGo3U3pcPz46lE5+z1
q7gReEACdHTtVhj5tMA1QBnV0a4++ZNoo5+td73EVNNCd0t3X4CUYZwBhS3bwqXXwjGPeYil6Wwf
xtScHjfkzCcaVuLk0qShpELUjQYgJskiH9xV3XcSrZ/weYtY6iWaL051oo4+bV+dEZdpU4G79bGx
4eIvHDOkJyJP4GVubEJy8gNnBg7F/BW08if7xgkw+HfsULcPhEmyBlHnGMfRQB4LXeIxa1n5WIii
d5W/83y4vEzdZPx5fa3FIGLVrz6WLUGdrJBJkydC3cFIngXvUVUXcJStU3jkm/LDIjdtvIhlIPtt
pVcjIENlCAAFTAQDuXoml8bPYyQmHXghroW/UAjR5hoRDZyXs8oRk1Bb5DQ4ONQM/xm3WBfTLpwG
btcgWwlG4I5TlO8pAD23sumS1ASLPAbGjXwborDqtpvodv+ltN4AUVc2ZuBGApzdNbjrKYhuMbeo
5hQmcgeUibQEhUh4Az5PG/aRI+0PO2YiZ6/iLKIj/Bi8xurmpKNoM9K9cvxJSxxuH11o94PKQtaB
8WVGZfFMiHXtA7dZGNbZGudp9t8PSUS/z14EF2BUh6SnCjUM707i7HCzNRbG+S9/HImALavtuV61
fxgJfi/FqL2EZtBPdU/WKRlF/LRjAZbbnLuH2kXFSnNUDERfqoTjoY5ykObiBI8JBcQYmvMjbBA6
00XvDAL8XQOox2HIBvJsxDuqa3n1M4n4JPkwcN8kW/Ffcb2n7Y08GNiUexPXRow8Vq9i1yOQ+Qg8
JwUUcoeEHiz/BogcTPEvkYyj5JD1rgOCJbt42SvNu95EcF6q+XFQD534WOncJLl7+sLOFMEPQ901
2rPyNH44PSrDKwsQaY1CRVRI34EHNugT9+6sgAIcynkXo84HJkd13VqaBh0aviG4UiYX+oH/OsuH
jAi2BoqgXp83UDxILdIoKKXlAWzyhxi8hmaxVdv8qrAE6PC3fmw3Ab43c8b7Z7dQ1cVgJXxjaHLT
4Vcqg/ZFWTiJo+k0NvODsKcQgS0mUEY0p7koZF4POTw6xRWf4xlZIfOwq3hoZ9HFPBs1F2pgjK/t
lvF1gRAMTWyGT/gUqlf6wEfA4XdzltGanV/sLAE9JlWf3Rn0Q8T9ahgCNy6Z6+/dDeP2MUFlX0rA
onxkyaK4rnTa/5J3eGI7qzmVtPqTK5zi7pth+eqRTxeOfqFXGAV4P0b9DMIbR9flNMvJ8e0UyQuy
RwLN1nVaWNKaexfPHTyISa6fYQ3u163lsPEqQMM+xLHoFVmgXqBv82OsiqOhn+74jgVFQfsZ3Xvo
h0ZkgsrVnMfdwRcFuwOAhWGkH2FLt/3FHdv2NEMaAG4pW6eeBLEpRUskHFIF6UrkfZY37Ujti510
pb3f3aHaumgnX6jWvReStZ5/OLQtdWN6AVzyRFQ44TW7TytRl5MUOnFlF/fU1uGVTEf4rFWu2aAp
Kmlo9058Fjlb/OiQhUdcqmyzyqh7dUHo7u0UtGXAZVyleJKI5gUte5X2s+E5Rx2fDOD8O9jDmkiJ
WL8BtX/slkNtqoS39ZBGBvjfA1h7ZmVb4GQI9GjuGU7qTt1PYfWn2q2DkxrST5GZ4aToLu2+P00V
ecKFUIAqpBGrIuW06oRSs1iafNeaaawsCvGVkxHA+AOILoND+DmvwS7g9jxJOrFakCHV3YeF7CW7
deKmF/zMfgCFWeXDGa+7lwSoRrLkVxepUVZPnGFiXh0MIL120XfTEaHKlcCmDChoElA7lW0f+gfD
Z5CkPr54tb/UiM2YrGeOBgHoMokaWppRmsB/c5XJsswUpkAVOS8117RW4n1zokHzswuNeJRpPhkg
voQvcansmKuboYw+oUiuaCdnUnBPmWKfSEeHLbwr/wgKZqRiJemifHJeod7LGyCJ9gcKBwHq6dfO
uWYZLX+VXZB0jnexBQPjTGm9dF+fB7xzOdiVBVic8Na8AblnWujdMQw+9KcGv4P8jvpQcMvdMZ+C
tjB5I9ltzAT9qPz8zxp3khE2FknCAnWDBf8ki0m9vAh2d8rwF2fTbthj0eIEUWd8PwoU8JdlKAbo
YxI4Z0LLjcyE3FP0+gCv1KcKr3u4CdD6F8jPO8txv2Q5jmu6PL65cT8AWvGDxpAeAo+hB4CJyrQT
IkQvQooIxHsauvldCk3HVKbdY5B8EGmXYcrwMHbPvnknrX0fDQGzL+Ebdi81/8SqYR2vL2u+5fSt
tVwPXkmAokuhQYsnTLft2yKKXyI9e7qHZ8U7ULhonNQ1mbE501ImNbRw9uUB/9bplwg4Md+8l/Po
ht6MNU5K1Qs/judaQnKEvcqfQU5MVU+rnVTLPnJppXJ3ZRY2qCCPvfilThAUiLtDNh1Cy2cbdvUK
EQh+SAvhz2Dq/8TWoxHpkPYjmbbzYgVl//Uh3cxAxT4ZTO98L6+uEKEMzI+AGazZBt8HnsROmqvx
bn5EL7IxvBrUQAji8eO07rNrevz/SV+vL9HPTlAgNMkchVncG979sBWSBfxz53GNJbolOGKexxnE
p9t/52n7iLdbFxn0g2SJW6DONhzBCQdwIHFD0I3zTXcFwnG3Yj+GB82VEo18HiCgcvhpPrBOqY7x
MtMa7SDWPagVZcZg+cChwfZiWr59fOTtYQ6dKpDTH1Gi4hH83D1cEkOX8MGYh0xN19j0sIJ09FNo
NNzJcC2mCNTLuy83dRTr04Ig8lH14WIrDYQSgCufirVlpNMMrMadFLa6fe6PAOkIR6WlEL1583Xa
u9JYOJjUUr/ZeE6H6aOe8HGtPnBdcALP4psCqDQlhNbjTv/Y+92YLR1all4WmCfNvV2Fu8oEC+xF
s9A1UxMMxELeu1PXukxIzj5QeIl6etkIoubge8itvC/r9sNf9Aie5Cmo19bcGFCcURyN0mfBTzIe
7FXteilnsifdoW3d2JXr64uWQVnUBYlOaN5HnRhvHMCj07P5IqsoXNHMhDc4zs2XP0EjB8/srvFN
m4Vm7vyZ9eRPMP1vNk/0KxO3JZ/jlX01LZzlUP6rp8fSaE87WYKIxsx5QZkSe2mWC+2Red/CmPah
cSCOCAhZs+CoWL0ZPrdvQrB9z8yQNK0UyZlhDjA/I8vlXC2EQyzvs0Rf+jOw0kLJU3tyN8vQHHZp
BCd4GpkHWBFa6bKshtznwiShHRgs+L/FcYKjYITu/OZtlEdX/pGRQUNvI/GNg5mb1dl6rykdz7fh
fNZ2dfuIlPuI86wUPi/UosyEMHnWgHSLa8V19PeD88aZcNKN/Bn9hA6c2nodxRkUcuM8lN+JI2RL
4Jw/dz28AQ8TxlqxkadVMuCpS3I2U7xNVeMhmJtYgrASHDSmlUr+a3EMFdi4lNj8BZnSXBN5JAB8
KomRI1DXl2qUcnKwRJytdXQT4us2TQxSPkuPec98KJUjEnCrqPimujz0BuEeucBISx4YsypKuqk/
6G2gdTlMMtQAjPQtKTWmW/4sY/6zvkJOoEP5l0rAp9pOfgoAh5SjG0kVuGbwPBK0UnXNaQ56PBrV
StYQ+QDVSbUu4eLRJl5hRw3WVHd+PTLdHP83HRErgikJGZ1L1t8vU4X6bPaL9PvHZ/K99cEtx3Q+
yi+/PMosl5+w8AWPViBecgXB8vFyK5em21w8pHURQvXhjBk1G2pWaoKmYo63kmjfy76gJLGAHFkz
rzB7bZyp4Q0n1bPVqn+WCNoHF1tDe91INRzAdI9CPCAiLhnvD06nAGGdk3g3C8G5GG8gUrvX/mxE
5+KEFmPLD1ISSAGdM5JtfAKvZEK/lo5j04iY14Jdc00rCm5rZThpzgWiLJf3FVLR95RO7uYJPBVW
/bSsjDCR2NTTZAcfmW4r7UpVeMs7M+/dt9WuNgZVFZPcvPJZTJ3WcXRfPl+GbV4/5nZuAZoJ6GNh
6eDDEJUMJLLyxsJ3sB2p6k+r/VggbAtJQDE6YYdSwvPQQa6RLSdPARidBfEbzpyBzvJ8ip8NkS/K
lKk55+qrwcY9RTtBmA9pc5YyZ6jLJGLBuADlGMUjZm68ZluUXHCJ1GaZWgc/kT73Hh81GTH1dVIm
wpgYJVsi0zpIaYJ6JMAfx9efmornNnViMSpkgoqulE0eygxxrUR5s5IMwI9uO86pXV5N7dNoy6zq
FF+HgkGl0zNUO3DFE1AHikMWSMU80Nfko+TB
`pragma protect end_protected
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
