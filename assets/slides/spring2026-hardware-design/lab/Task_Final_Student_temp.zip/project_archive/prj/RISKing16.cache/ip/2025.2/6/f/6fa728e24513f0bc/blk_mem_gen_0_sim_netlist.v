// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2025.2 (win64) Build 6299465 Fri Nov 14 19:35:11 GMT 2025
// Date        : Wed Mar  4 16:31:53 2026
// Host        : TX14Air-ZIHAOPU running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode funcsim -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
//               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ blk_mem_gen_0_sim_netlist.v
// Design      : blk_mem_gen_0
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7a35tcpg236-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "blk_mem_gen_0,blk_mem_gen_v8_4_12,{}" *) (* downgradeipidentifiedwarnings = "yes" *) (* x_core_info = "blk_mem_gen_v8_4_12,Vivado 2025.2" *) 
(* NotValidForBitStream *)
module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix
   (clka,
    ena,
    wea,
    addra,
    dina,
    douta);
  (* x_interface_info = "xilinx.com:interface:bram:1.0 BRAM_PORTA CLK" *) (* x_interface_mode = "slave BRAM_PORTA" *) (* x_interface_parameter = "XIL_INTERFACENAME BRAM_PORTA, MEM_ADDRESS_MODE BYTE_ADDRESS, MEM_SIZE 8192, MEM_WIDTH 32, MEM_ECC NONE, MASTER_TYPE OTHER, READ_LATENCY 1" *) input clka;
  (* x_interface_info = "xilinx.com:interface:bram:1.0 BRAM_PORTA EN" *) input ena;
  (* x_interface_info = "xilinx.com:interface:bram:1.0 BRAM_PORTA WE" *) input [0:0]wea;
  (* x_interface_info = "xilinx.com:interface:bram:1.0 BRAM_PORTA ADDR" *) input [9:0]addra;
  (* x_interface_info = "xilinx.com:interface:bram:1.0 BRAM_PORTA DIN" *) input [15:0]dina;
  (* x_interface_info = "xilinx.com:interface:bram:1.0 BRAM_PORTA DOUT" *) output [15:0]douta;

  wire [9:0]addra;
  wire clka;
  wire [15:0]dina;
  wire [15:0]douta;
  wire ena;
  wire [0:0]wea;
  wire NLW_U0_dbiterr_UNCONNECTED;
  wire NLW_U0_rsta_busy_UNCONNECTED;
  wire NLW_U0_rstb_busy_UNCONNECTED;
  wire NLW_U0_s_axi_arready_UNCONNECTED;
  wire NLW_U0_s_axi_awready_UNCONNECTED;
  wire NLW_U0_s_axi_bvalid_UNCONNECTED;
  wire NLW_U0_s_axi_dbiterr_UNCONNECTED;
  wire NLW_U0_s_axi_rlast_UNCONNECTED;
  wire NLW_U0_s_axi_rvalid_UNCONNECTED;
  wire NLW_U0_s_axi_sbiterr_UNCONNECTED;
  wire NLW_U0_s_axi_wready_UNCONNECTED;
  wire NLW_U0_sbiterr_UNCONNECTED;
  wire [15:0]NLW_U0_doutb_UNCONNECTED;
  wire [9:0]NLW_U0_rdaddrecc_UNCONNECTED;
  wire [3:0]NLW_U0_s_axi_bid_UNCONNECTED;
  wire [1:0]NLW_U0_s_axi_bresp_UNCONNECTED;
  wire [9:0]NLW_U0_s_axi_rdaddrecc_UNCONNECTED;
  wire [15:0]NLW_U0_s_axi_rdata_UNCONNECTED;
  wire [3:0]NLW_U0_s_axi_rid_UNCONNECTED;
  wire [1:0]NLW_U0_s_axi_rresp_UNCONNECTED;

  (* C_ADDRA_WIDTH = "10" *) 
  (* C_ADDRB_WIDTH = "10" *) 
  (* C_ALGORITHM = "1" *) 
  (* C_AXI_ID_WIDTH = "4" *) 
  (* C_AXI_SLAVE_TYPE = "0" *) 
  (* C_AXI_TYPE = "1" *) 
  (* C_BYTE_SIZE = "9" *) 
  (* C_COMMON_CLK = "0" *) 
  (* C_COUNT_18K_BRAM = "1" *) 
  (* C_COUNT_36K_BRAM = "0" *) 
  (* C_CTRL_ECC_ALGO = "NONE" *) 
  (* C_DEFAULT_DATA = "FFFF" *) 
  (* C_DISABLE_WARN_BHV_COLL = "0" *) 
  (* C_DISABLE_WARN_BHV_RANGE = "0" *) 
  (* C_ELABORATION_DIR = "./" *) 
  (* C_ENABLE_32BIT_ADDRESS = "0" *) 
  (* C_EN_DEEPSLEEP_PIN = "0" *) 
  (* C_EN_ECC_PIPE = "0" *) 
  (* C_EN_RDADDRA_CHG = "0" *) 
  (* C_EN_RDADDRB_CHG = "0" *) 
  (* C_EN_SAFETY_CKT = "0" *) 
  (* C_EN_SHUTDOWN_PIN = "0" *) 
  (* C_EN_SLEEP_PIN = "0" *) 
  (* C_EST_POWER_SUMMARY = "Estimated Power for IP     :     1.51805 mW" *) 
  (* C_FAMILY = "artix7" *) 
  (* C_HAS_AXI_ID = "0" *) 
  (* C_HAS_ENA = "1" *) 
  (* C_HAS_ENB = "0" *) 
  (* C_HAS_INJECTERR = "0" *) 
  (* C_HAS_MEM_OUTPUT_REGS_A = "0" *) 
  (* C_HAS_MEM_OUTPUT_REGS_B = "0" *) 
  (* C_HAS_MUX_OUTPUT_REGS_A = "0" *) 
  (* C_HAS_MUX_OUTPUT_REGS_B = "0" *) 
  (* C_HAS_REGCEA = "0" *) 
  (* C_HAS_REGCEB = "0" *) 
  (* C_HAS_RSTA = "0" *) 
  (* C_HAS_RSTB = "0" *) 
  (* C_HAS_SOFTECC_INPUT_REGS_A = "0" *) 
  (* C_HAS_SOFTECC_OUTPUT_REGS_B = "0" *) 
  (* C_INITA_VAL = "0" *) 
  (* C_INITB_VAL = "0" *) 
  (* C_INIT_FILE = "blk_mem_gen_0.mem" *) 
  (* C_INIT_FILE_NAME = "blk_mem_gen_0.mif" *) 
  (* C_INTERFACE_TYPE = "0" *) 
  (* C_LOAD_INIT_FILE = "1" *) 
  (* C_MEM_TYPE = "0" *) 
  (* C_MUX_PIPELINE_STAGES = "0" *) 
  (* C_PRIM_TYPE = "1" *) 
  (* C_READ_DEPTH_A = "1024" *) 
  (* C_READ_DEPTH_B = "1024" *) 
  (* C_READ_LATENCY_A = "1" *) 
  (* C_READ_LATENCY_B = "1" *) 
  (* C_READ_WIDTH_A = "16" *) 
  (* C_READ_WIDTH_B = "16" *) 
  (* C_RSTRAM_A = "0" *) 
  (* C_RSTRAM_B = "0" *) 
  (* C_RST_PRIORITY_A = "CE" *) 
  (* C_RST_PRIORITY_B = "CE" *) 
  (* C_SIM_COLLISION_CHECK = "ALL" *) 
  (* C_USE_BRAM_BLOCK = "0" *) 
  (* C_USE_BYTE_WEA = "0" *) 
  (* C_USE_BYTE_WEB = "0" *) 
  (* C_USE_DEFAULT_DATA = "1" *) 
  (* C_USE_ECC = "0" *) 
  (* C_USE_SOFTECC = "0" *) 
  (* C_USE_URAM = "0" *) 
  (* C_WEA_WIDTH = "1" *) 
  (* C_WEB_WIDTH = "1" *) 
  (* C_WRITE_DEPTH_A = "1024" *) 
  (* C_WRITE_DEPTH_B = "1024" *) 
  (* C_WRITE_MODE_A = "WRITE_FIRST" *) 
  (* C_WRITE_MODE_B = "WRITE_FIRST" *) 
  (* C_WRITE_WIDTH_A = "16" *) 
  (* C_WRITE_WIDTH_B = "16" *) 
  (* C_XDEVICEFAMILY = "artix7" *) 
  (* downgradeipidentifiedwarnings = "yes" *) 
  (* is_du_within_envelope = "true" *) 
  decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_blk_mem_gen_v8_4_12 U0
       (.addra(addra),
        .addrb({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .clka(clka),
        .clkb(1'b0),
        .dbiterr(NLW_U0_dbiterr_UNCONNECTED),
        .deepsleep(1'b0),
        .dina(dina),
        .dinb({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .douta(douta),
        .doutb(NLW_U0_doutb_UNCONNECTED[15:0]),
        .eccpipece(1'b0),
        .ena(ena),
        .enb(1'b0),
        .injectdbiterr(1'b0),
        .injectsbiterr(1'b0),
        .rdaddrecc(NLW_U0_rdaddrecc_UNCONNECTED[9:0]),
        .regcea(1'b1),
        .regceb(1'b1),
        .rsta(1'b0),
        .rsta_busy(NLW_U0_rsta_busy_UNCONNECTED),
        .rstb(1'b0),
        .rstb_busy(NLW_U0_rstb_busy_UNCONNECTED),
        .s_aclk(1'b0),
        .s_aresetn(1'b0),
        .s_axi_araddr({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .s_axi_arburst({1'b0,1'b0}),
        .s_axi_arid({1'b0,1'b0,1'b0,1'b0}),
        .s_axi_arlen({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .s_axi_arready(NLW_U0_s_axi_arready_UNCONNECTED),
        .s_axi_arsize({1'b0,1'b0,1'b0}),
        .s_axi_arvalid(1'b0),
        .s_axi_awaddr({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .s_axi_awburst({1'b0,1'b0}),
        .s_axi_awid({1'b0,1'b0,1'b0,1'b0}),
        .s_axi_awlen({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .s_axi_awready(NLW_U0_s_axi_awready_UNCONNECTED),
        .s_axi_awsize({1'b0,1'b0,1'b0}),
        .s_axi_awvalid(1'b0),
        .s_axi_bid(NLW_U0_s_axi_bid_UNCONNECTED[3:0]),
        .s_axi_bready(1'b0),
        .s_axi_bresp(NLW_U0_s_axi_bresp_UNCONNECTED[1:0]),
        .s_axi_bvalid(NLW_U0_s_axi_bvalid_UNCONNECTED),
        .s_axi_dbiterr(NLW_U0_s_axi_dbiterr_UNCONNECTED),
        .s_axi_injectdbiterr(1'b0),
        .s_axi_injectsbiterr(1'b0),
        .s_axi_rdaddrecc(NLW_U0_s_axi_rdaddrecc_UNCONNECTED[9:0]),
        .s_axi_rdata(NLW_U0_s_axi_rdata_UNCONNECTED[15:0]),
        .s_axi_rid(NLW_U0_s_axi_rid_UNCONNECTED[3:0]),
        .s_axi_rlast(NLW_U0_s_axi_rlast_UNCONNECTED),
        .s_axi_rready(1'b0),
        .s_axi_rresp(NLW_U0_s_axi_rresp_UNCONNECTED[1:0]),
        .s_axi_rvalid(NLW_U0_s_axi_rvalid_UNCONNECTED),
        .s_axi_sbiterr(NLW_U0_s_axi_sbiterr_UNCONNECTED),
        .s_axi_wdata({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .s_axi_wlast(1'b0),
        .s_axi_wready(NLW_U0_s_axi_wready_UNCONNECTED),
        .s_axi_wstrb(1'b0),
        .s_axi_wvalid(1'b0),
        .sbiterr(NLW_U0_sbiterr_UNCONNECTED),
        .shutdown(1'b0),
        .sleep(1'b0),
        .wea(wea),
        .web(1'b0));
endmodule
`pragma protect begin_protected
`pragma protect version = 1
`pragma protect encrypt_agent = "XILINX"
`pragma protect encrypt_agent_info = "Xilinx Encryption Tool 2025.2"
`pragma protect key_keyowner="Synopsys", key_keyname="SNPS-VCS-RSA-2", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=128)
`pragma protect key_block
YqH9kwIC39+qbZg4PSfFsXuB9k9wnuxNryS/CfnEri6Ci9fSC6fsrQ/T/hnt3u/yolbJ8DJa1Qu6
Qnm24A9jLbA+fu3Nsmm6/rM6a4vU6OfVl/gTFd/CiWDutv6Dhn6Lim4uUNPahoOR/A2Yc4Zo2tdI
kMLO9gn9WlH2l3O2oXs=

`pragma protect key_keyowner="Aldec", key_keyname="ALDEC15_001", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
XJYO2VHd/cnMxQd3i7/2qRhl57dl+doEKuhAunQyv3vpGRG/jlNxj8PqrgLoF0HMdqE3qJUVE/oq
kBSapqjVjLDMOrNGQ+Tc6VGsKMZH8FE/TXHQJ/IM5Iuiu2eozEwwVUomF+7cfqn+9OsVsqCONQ1M
g0oRlangiqasJDhhMfnlGGqwAwmgWRGQA6dmhTuua1s8zdvIv540zY6p5au8cAKVhqyyKK7wbxEE
SGuFqX+NYoyRV+rfWCcWM+hJEmnWS8LNAKkd13YE2+17sPYzUdZ23DmTxXK6KlAxKFW27CBySUfg
qdNXp2DSs2KAQYih27pBNMuHfGbM/ATFPWFvxg==

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-VELOCE-RSA", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=128)
`pragma protect key_block
lYoEi/e8HsDTz6N11EDe/B/iitERmeYndlCklmCluwgb0N4W80JUGVlkd7NlRZHRNhxaNBJPkcjC
n61nO0tb17NwsMwjbY5TF8JWRYTNw1JXCFacvQYrdKv4/7QNQEtwVGiCLxFhOA8aHlWMZIrc2fri
VRMVWaEBcPwCGorlVIM=

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-VERIF-SIM-RSA-2", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
QEw9fEsWFbdX0OQLvYs/gl+zyEOW3ak9TdQVaq+0AXXOT3LIqF7wDxJ6ZBnlf9mNbdsUVH5tAz1o
H8u7ihJl1L3THEvugW+TS8hkvVbEA9rKO2vV15KAj4Lla7UdFT/xDfe79RFarlLI7yGrubjgdoRi
QWy//UKsffG7IWNwmoSuppWiWB4ZHJtkunNyIkm70JPGyZF62VxJg1MTT+5LUbZG5vZjjuHZud9w
xJaKv1tFP/x8RVqLU5gPOqGqTW7/nKO2S+450Vo4D9vAmBVVcXpaL1EbSmCvQ+qJmcQKtf9qYFRV
Zko08hbpHjPxstqvTDro01jRzB8592m4xU2TWA==

`pragma protect key_keyowner="Real Intent", key_keyname="RI-RSA-KEY-1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
TC7q853CWBPPJgbRfgDV1lmjUwSAtliljShAyNFg8sfRfwDzchthzoSPH1UCHV++E2JXacEKq1lB
UWsNP92U4Xh0/Gu+6esOI0pJb8I+TRTxyBN1I4cRQEfQHcwfhbSdeH3yX9OV3opLEqYmT37hWU+J
zCawYnxVESI0FtRzEXve9gdEWlrKKckrT/hp4mvxxOjvOkOSQBvy0elgUOqh6mEOZl+JnUbsR+Wm
CoZLE1eefMZy3FnVmyDNPv3JPXi88aLXMyimal0MYFkTiS4XJiGT3eAIMIbksehXY+eYi/KFpZWQ
GHpX+lG3UmiWWLwyPakFwKEHbrBc70AlJ2eV9g==

`pragma protect key_keyowner="Xilinx", key_keyname="xilinxt_2025.1-2029.x", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
j9nmCKgjPWNChPbpSW6EWLrMA6oCG2JGPoum8px09v0PEAh0DRXZi0J8HPzXUsZgOEMcKpA7X54u
YFcDDCLAQ+urha/eSPbQYHQh4yGCursxAQ1C6LEyNQ2wJ0eLlO2bJeAl/gof06zqsYVM2lLJVNv5
wao1k2bmgPdfpfY3c9vPD0fSMuZPS41EoRS0cQhO5GTZnKdjxm6tEUL3GnTjB8ynSCIbCJUsMtAX
4FRHNa52gudx5B5fagR+lXgFhE7e++rWTJELr7SYB+r5Es8qZLTpCH8TrQxEkV0rY/+e4sAjNE2D
gHw8GD7VcUtc15B8y1BbVmh29qc8Nd3V2i/miA==

`pragma protect key_keyowner="Metrics Technologies Inc.", key_keyname="DSim", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
UkCD6I/Vye4qNoNoa3hIexBXG3xyKUJPAHAjIo7UcNVCDXpMQiYEtPDqExZMfiPlJn2nswCYIfIJ
FYWqMCloKSQyyI/7yZ2EtbyWEklb/P5IyZyvGi6hhFUo/JFTb12b4bK0gZPr+bCDdlVQKTx5GVHz
wptdUJO2omSj8axVMPbLRRtVzlJIZ29dTJ2ATXVXAcBxPnFfHRAMnYYKLeeLExX61vQvpqrkLQHm
XG7hpVzJi56gYKAzxa2BLq072OCVpVS70bfWlhlSTVcSlCrUf+EcarEk4FD8+Ih2NCvrqremG6yn
TtcBn8Xr8M/6zhOYvLi6AD6eArDMKA8n+Ccv8A==

`pragma protect key_keyowner="Atrenta", key_keyname="ATR-SG-RSA-1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=384)
`pragma protect key_block
A5y5QVZU8yjPexRVPioSiAGohCHD5DX5FVobuMyhcgQRExLUhPvnnS8HOtxTj/2IapEcz68gFMGG
Hpi+m725u85/om/Vze9pGIW9Mn328Kz2FIg3W5EvGstfGwY+48LiAGAmTR269JS4lJGVYWYOz7Xk
S8cEsFd2m7j8iyKtARJzD90+UdXq/cIIh725jC9i8nbgxB364zddvm1Z/DF3JRw1qFp6GGcuRai1
KNcJ1j8c9wtIgktpsteU3e5+bxHEw8NT3gWXUFYjm00NDq97Jals8Jjktmum2nQxoF7ivPacfEey
gnSF6jRMkTsZObzc30hAhs0CEtc33hZLhPLHSn8pQ0WyvKJLHdd5s2yckgTZtqxC1Sbwe7WEgNXe
ZMX3pIkz+aoXsAL7GBLyVBMVQcyMoF0w8QGAaTe8sqatABwPqXidYRqNROTf62IYcMpV89XYgaTv
EwIn/oni9KOFd2BFVxRZbFGGC4IjvigsTBUijI+Dk6kVnDh240clGcc4

`pragma protect key_keyowner="Cadence Design Systems.", key_keyname="CDS_RSA_KEY_VER_1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
Omtp+lCaqUx7Z4qdFj2zrN8LpCkit2eX4hlMtig+ielGm/x4FSZkpjoFmiqdKFPi2eg0pg09MSai
XyGH68UzAR7Xrj8f1jlIoUmMKp4GcxfdqfTeuu7kWGOJEP6cvgTjSJFj2gawDv7f4yZcltnK2x0L
e4GW/rBTmGvZtKWb2ahjINLxPuh3dDaSaWdb+zVgbtyrI5FrjxBkq+aOxSjyNsqnCx1L0uWbxnkl
88NbXN3dTaECXHNm/fsleayM5hKis7kTv9BFajJMGy+BhQlmIYpE+F5zchnTTFUFJZCz1sX9Fc8e
HcY7irB8mR3ajdzjUZLBQEMktp096Nheq3U75A==

`pragma protect key_keyowner="Synplicity", key_keyname="SYNP15_1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
hpeBLwN9x2ZFDwroYLlUe5GjjDepHik2l0c2s3/6S7JPCRkzQSyt2V1Ad/JewAs/QNp5SXSbYYB4
rQl0My1LDMF3xw43r0g2IbcyHVpPhGp0W5msuQdF67afnsRv90iJYWLMI3QkYGCTWAzl4HrLxFSg
3z8XZRK670IcxznOrlvgHmIKsvubZrBkuc1EynrVb9Nw16QnIx2rc4WgcEXeFf+4i1RoYLDd3gXK
NFCNMdtaRYUThunFP6Z4ViZ5UnDmKq+IMhd31jTaqIlWOBDxPI1+v5RJYxIyTbn4rxlKR2fNbl5/
z4OUjBTd+1GH3I2OXlqmAOvIhpe2Z2HH7nZu/A==

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-PREC-RSA", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
Mt2RhTSUwEIEWeNARbyL+EdfS1UF6nPaL/fKl/7oO2gina93egwCWDLl1fbBtkfaPco0cu4MJ9K3
OraAsyHRlY+MNShmJ1LzAIA1LjZx4y55lu9dlQqSUXR7AW7wVbkg1864mK+hM/1XygU0jvebKNW9
B7xSER+asLO6pxi0mt7uC2PHxLPAYEszFhmnap82TtbDGdQ2qtyekY+ngs+N2fAdsblxVwJruiMl
e6XJ127M8N1mYwhWU2HtRpBOSnnKoHgD9fG51XK/rhk8DxT66QnX9uLPB+H25eDupBJGi1Y5o6x8
hOwZiSUVlBLh7brfzevh7+eRn+7es6wBas0+3w==

`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 76, bytes = 19008)
`pragma protect data_block
kbn/G37WX+Cd6KOfhe0DATztODjx99yFlHH1xpkSU7l2a9Hyr19RQwJSB5YIB81AH4JvqpQT+hjz
pKYrtRcin+rSz4lf6tQ9fNrQu4i/6crWhecp8sDMCrFzNYITGtD5gR3XNlWaXV2SipFr60+szQH7
DI7dS+zq9zxnVnizPBKVUQfjIgKxr3SJ+UMKPLqbgvWyS+0Rh8rZpRPbkfAxOFtPt7Tz/RtaU6y2
RLR/MtR/PXYEzyd2UMOAdQFSa4RQTwzUXPU+TxexJcLWkN2aq9wLwN7yCKyTrk6SHm/q5nxzu6hu
dO89XR6LJWFbV84tDuyAs/HqgXmQKA/5RDs5y5h85MuL2c7jHB7IHVThKhjWkSLA1pIrgdsf7Pxf
efxhi/534VBtXnKwUEa7spRQseKyNAK+/OYSlxSNqm7/cMBUkri/qLnWAAeirGdstUMw7wKT1raM
t54zHpojescRw7dXRkL2kdhHlXqt904rUweT0QmDfrVlMxqpYQMeSRbNJwjGzT7KPIg88nJB3ghG
uPvx2jV27SDsj1eDnG5SHw2DExEgMFW8IxVrFvqf12BeZ2q3xH8FFDkccBTonyNXOpD9llkNXQ/k
PibVyX5XX3cItMdu+FrW0l+EECVe663/zTrPZ2ULTGfUzgNRK+FR9JQY8WoUaUqh269U8t534TlH
2hQb+GAYGHrgboklF+AXF8DCDXynjQBh/Mca7+28XGVXguhBgenT6DghQTmQOfK9fg9kYCXIMqc5
PI9BsP2eURfUZARTZ9SoomcEE9e0w2HZjMqLmJYcbH5FidI1BRRQBLrienagga1XQ/3WAz/HLqj2
YeFMn/WwQ/ngMFl5yiK6mmZHK/IEpFqPEswkJMwPfknr532fYi7zAPkkTC/hhHQdwQauvngn9y6R
0Kae+qou7/+X5HxDKvrbWdo0nvfHAULHbW8OldmB2a0R1vJgFKtmpzIosMXjnecBlptAaadMZF9Z
bUcH5Zk7070H8AxMjLcdU166yajAN1qZp+BBbanzgaNxCZECXNULf2Yrb9wDMENO4/4cMVJ03mzv
p73RjGOLQNCXAOaNg+xyvCv5jjxrKhJHC6z+Ynp0txOPNzJ7ITARqeDNnYv507TAb5lbjtVD2Hs0
MrpnAFCQue1z065d7YZpm6sXdOmx96gtshsWbDccWYneuo9opxhm+VkytAAGLqM+BRW581vKstj4
s3RLgERtH2HTSACrRQJmDpASrTRA5kPWHbKNl1hEq8+cZdxGvSbZRPk9Nxc9mn2mSHfScTmn2Qhy
0Q5I5LUqigOectmo10nymSXi980YyhW5DcAMch0CHLqK/JM2xiWO3InHthoV1COzaumsjJrMwdIu
qirDECtv7yfS3z80sm+BowvrSE/U3XqIWOHPoXMl1n2UBhE0X235HxIEozybWy8H+k1FB7wDm7wM
2LsyDWHbZbbIGxib+G6vGOcT5aikJfYovS6PyRiRNb+A5kfboHrglXURApyETjcaB3U+s52Kz1rt
RYr4mhGeUq3YCQO1m/JBUtigC2XqCl1ep2DAKne72d4f7rWaJDnrNnlWQVxfXTH4LH55OstDA2hq
F7gJxC5PsgVa77qUXc3PBSFVlwLT5IHHzOVgQrYVlBhwr597hOU5rLiFrl8Sn7Yf/05i4NJes9At
x2/JQ3KCbTCwGMqKj7Looeg08zr0SqGud1zk/A5Sil+qQsl1FkzdIv75mwNVbzSXntEWb+vpRN2j
ZdQexCjCVAs8R3ZlIC1snP0I7zu+L2/xUnxvtQwPLtTp095UZS6929CMkD4fFvADFUqT8CUeKpU+
PXZB74785YGAoZ+ha9/TUkBUi7tG0BNvYxFrhV7fj7NQzDv0cyrPii4OcB80Cs1vsU93DsqiroUJ
/n9Q+Awx8QoHRLCBx37W+S+q8eJySE42yOn1mgkUZSaZoudmikwLfPVSziSzyu9sg4n2adkIvcqW
FWJpQ+e7fdlVccNyKTRykb1c4kn5p59KewRM50y2B6Cd6Z8xp+scJqQRiAVp+CqR7uZgD+J9yPoM
r8UzucuLsUINEjVu5btNQ5VGL4aSNOrvkRVfrxNwEz2Xxq5yyCGQ7vzi87lvE/yBSqVKja8TnHSW
U3k2giZxsA8usH8BCGscV3N/7FzchHDt+peG5n9XxZ5EZ9s+rEOiwSmtRv7UfY+XfCwyBcxcV4Ui
G5isvlPAtoRlvLFyseaZrQuob5JUjh6iBA8j8pp/ZOosRwpX2JFuefcgxmoHVt2wzD1EJmn/zb5y
D/GU1F1nKVFl+WMW4okj/wAWGcvG+cTlDonz+h/NpdxiuroL8/IGT9S+isYy3qrv3VEcrEROcX6j
Wc7WB58+s0dMb677l6Q+npWLcz/xqsIpk4hl3KtvC0sbfbjBksWweuSLZJF1sXJcbnp5PRBKcEaS
JO8DqVyCND4WBpBBi69oF6QGXkIuQ55kafwNdxf+wB9FxKMxQJS/Uw/PzG4PMScZYLfxcT1zVw1n
la/sG0oBirGgjA/+CEaNBp4ldUXSh72CuTHrw2czZi2Nuc5Iact+u0g7DpTT768N4TXuXm7M2VSJ
6zsiCPABO2bWnGpY0qrxWSApBywazRS0jJQhhMs92NeNmvE67uAcA475x71MgNvAWXN9tk1vhFq/
w+CRG9MIPcoYD9kGB7ZueFSbtUuAKK4OpP/N4chy3EEk3djl4Si0gOn57uvQnqoij/BY0jhZIwOS
OLzGuQo5YAWNb+dLkQvuOpZlsvhX1w3f8KkHN5gFy/vKs7LuuIt1Jfl+vRyzICevELkYbFfIzPPs
qShngGcLxvlqggTp1i+pdqpCvLVGm0MEXK/5NYDhnaNO49BIAcX6Dt1E8pZgaXe4qYvnpPXEwz/H
i7Si1prMxuShTnDNVGeTdaaQQ8doy3fryJ63OJGDv38tsGSkONFHt/Yy2tMaqjKTdf0pnwBggk+i
Y6ebWRq08YXlzgclsdcT13kkdUeeCNqQ9dIQV0qapsPlvtd05Z+RGPqDMrBUZiUWMaXPpuc99ooU
MqHdmMwREnWLu9upXHFWMwdzuk0QSqgfCuB24JWktofm4J9vIyA4vIHYKFlmTYmydnzI6YiCWH/W
LMqnSwlb6N5jvOsVaS2EkUgzOMF27ERkSHjvkrh2S5I3I2Ute107yZ/3c7XktEpcQPsLNu2BLM1e
OihO5WUGj9xArxKzInPnzOHKhPpKh7kF6HgsVa99XmiMC6bMTL5u08HnO2prtP/Xt9gbg66hUxVa
rZEFXrGXWgXD8k2nO6Lo/W3Zdu+Ep5pFPO/3UVj/m3FvCBOjRYht4Au7rnW3A7b8krrE1F5sH9li
sD2ZvwzS2Nm8li0CK2+SKDozKUlNlzBXifuqtot/PFXZwpZDm2R88gaXP4WzHKziyaXtieQPoB7C
+704PPf59j7XH3SWsd8v4MrKbzQljI7rRX73kZ8n/TGOJECWCRTaAVaPqPaSzxinaI+jDiulKGVd
u+uv8wUfOmFw/UKppbG+UDPx3F47Vx/lpMAs1OxVRbxAkq9bJ7wwY7MzSg+1st/m+yrd+t9oHfZR
Leji66FYghiMOZ2Cxqz4Iy1OQT7PhbpqQ61dGCJrsDYVBZkFt9GP2IbBqhw7udgJMzfHnJ5MgJj4
VeyENDDJlNVdajtzbkd72Os2ho1Nlb0QoYJsPuHrokGsA5eZ7PqlFAenBPRmNJQMYsCTV9A8XUdr
d04wAO6hnBgViUNkl3VVUEdsL3VXagIyH26vS4VRAqlUyxZ6SnMzjzznzEt5Tkxrg8zlP7Wt41Yp
XSRNQPDZWVP0JXM1bh+SamUybnV+bMnP2XSua27AFYelOPrvC07PpTixSoaxAmLVqrUuJvLvtidO
L1tu0XiO1O+ba7e58Ivo812lkS2+n10o9NeViZJYvDasyc366jT+IghvAcaCp/n8szjRKHxQ1zQT
Jo4JtJp8m/vT0lyLTvENlO8bEudBVAiZ9wPEgdKRLLnRwbIpvMbLzVpnw8Z9NWyWvO7OK/ezqsK4
Tucj8Nx2tuS7V4+T4WTeDoTbZxCh6U44diBi6u5znhbYoSE4adkLqug4EAaxatxFeXLEOozIMJ72
Tnn/KJ69laKyoU/IcHsTFjdJrj6iF4z7thBd1r6nEc0DBTgUxdz78wjBtQnwG54+8gEJVCLxR9OR
HT4rVynOaJS7TZ2jbJTGFKAVrEjtMNSxrtKKD9P2OyMnu8RVARLbizjEFborOZqfnZlyuI7Ti3ga
drgba8uBDpKc34qNEO0t1QlqfeWWf3pGqZ/3/P2bNiiOwmwSHpTr9w/S0VxLTZCs67CWE7FUi2EF
UO3JvM6uLN1eTQLg113AAQYzugB19wVCEsKX8IyrUfVLjsVs+6VzEWdWn9tmqmiY5Fn1APaUaSqp
t9VqZsoB+3qy7V8QYBsJ3AKT2H5ccPUO28/QEGzgxmrj6ll9EGFoEQ2Jv4u08YTZT94dOBsNANaO
NnrH8bEJsemGaBjX1ZINGlPEFl9GmK7PaEV9lPkp7hsnovC9IzGkCKWSjPSwwxaQsAVZkuwVr4yL
dQApl/8F4N0hL+SvdHwEyDIvUfykNJsjfFKHnJsXWVcRiUteWHNKkt4a1UhdYy8LHK6tqB5sathb
iCkHA75dINmc3jlvLJL7Cv4rBTidhkBvBoLNWJNJqXMUwXK7/8ffzgBawp3ZCCSV4VEtlZ8lIdvP
d8FJK9A3qUFkG83GV7BW+9zMaXzrY9M8kJacumZc64IZRONxn0jtW1s64PubgMN+EM9PXiDUccDd
Cul037h/gICjd+tTJOG2+eihfiaRKc/XGxSy5WILIdm8xILeahP/SV1FEYFmPnVzEVot6Hnf0hCv
mYAixNT0MDR3tHfOX49ifaAb5Exl5QxPRT3DiOaw+exrssb8BNXpUxaH7Q9669Bh6ZF/MJmUp2HA
JcqmTxs3V8TKzOkEfGZUKg54r+GKdSoJcoOeJG4jQQeyy4ZD1IcRbpg7AVQM2N3J6YMg3Kia6/0m
JMuewBNlGQrQSPPh2PhFFw4d46yWf/8rM7HzaZtUO+qJL4xtkhv4+39+tls2param+uyRU5tj1KH
yayf9gCeZcqjcxxk82C+pqx4CTY352y9e/vyGbrRIBlg7lmRXO+qMiHnfSCr2kNZ2K2qiEBHUinf
Hg/hkAsF55bbvYDP7H/fkumCtDTBhWOkb7yWpfJGcdqfIOCHXlgHAhmduzFi+Hbr782HpLkZRGhz
FBuACygHu5zM88wn3NQ2OJ5wWsnpIQpoE3bX/NWz35wxHXlfRugDwShM5uZGToxH7OAFd0BKdADM
04pfaHDACAbpK5QVMvWeV7EuDY/ugXlH9+SRYdNeGkArY0LoKqOACp/Mxc8biJFKh/B143uDULRq
Y54RKwvTf5OrYje1wy+3lhpL10QjdTGXSPyxUsirUOenrE1+5wbJAiitE83kR/oMxGbCZxRYOt0v
cygXDVKf8Ys7djBvxClynTUcWZeGWhg8Bq7hp0txN/6wWi7chSx0AlN9gudNazPs2fe6xDHouhrx
b4WqFoFqNqmUgHv1GKj0frb8GdzLLyTg5q5w4xZ3+rQEI1z6U/BbbUcm8t9yN8P4NYMtvwAqYZnR
2k9S20zwTp0HVgkyygo8Rbdlpl9RDw9P8JorWpbG+p04HBwy0fnjDBv1Ax078s+WHpBnWQ4tNO9p
ne9w0q4i/5HBFnw7Dk8m24DnzXVv0aPPg+efdKFTUBwyGdQCnvmdrelp8607Rf8z0EgASB0+Tb1O
b/0Bt8IzF7seK2CZ4cun6/WGKJjfUC7Ejfhn+kyJOu26EnjDSohcPuAXKpZH1F2pndHWO3KGWj1O
iBzCKBQWFvIRYfc+7PUXKOBoPsWNnCJpi4+yECN+a08OunI+S9lQroFbvMnKX2mRC80p2Mq+97MN
T+S3h1O5ObERWJmKzjnkL6nt5mCPx4OJwmELlsx43Ks1AKg/kDmMVLN4Jv9DyzwL3QfTbpPIM/dc
okkZpDZGLEJdoIJuH5qSD1KKaoPD7BDcBbvZ4o6sEhEMZgp+4g7MrjmM1KXsfEYYN06O4mGAE9uO
rPXuHLPG7DcgUtw7KrsGs7JYLU4E8h55ki5xWUk5HS5cd86Td5qV9JrKY/cWqdNSQILEe6r/veqA
Dhqmc7ohoXkv1r3rMcXxBuM6/pDPWzZ/u9ILKibytU/JbAktRaosmcoiEGGnaIWpjcW2s8myxJdM
EOcnX3KhRvK72HzC5PVgK2i6vUzIfEmCxbg/H3wnQnMjfK+rSXVnQExx1az/dnT5KRTFADKDBpyW
m4OprRXUBiHVvSDaP3Cx42/gQm9iFq6qfZX8OYda7/bVOBXqibmufNpikPWZKftwGAHsADt3ZIqq
HC5m6QLWiV48valQpBvCBmPDjd9xP1YutHVAu9RLZJ90HKJRkEAEVjyK/Y2vOKdwEEolZ1Si4wxh
j60T++bc9+X8CGMsMVy4JLGkLhApCUH9qJzlBHhpB7BuKa6phGhVy5U05+UQSSSYGb6L2U+PxCvz
0kSLJ6Hhqm7Ht8Z8Fx4AuRJ8qMEH+mbrJfCqOCfj3TiHiUSlYcN20gvDzUSgoZrnwTAUI+uXaOOM
yStqGCSd0nQc8mZGTPW8ADbP7dB28uf8tBymhzSD74W1NWtfmdMyRVhm5MC6OCLj8Wsewald3aa5
YiqzKMqBXpfF4u1Np/4H4ZpaZ7Yxrs2n5ALrEaHgtBvGxoOsUEbTIxng/aOav6+pqtFx84e0R3RZ
nULh13uxeOZ2WI+WzExNzhf2XDJN/xpidM+nT3GdOZQbgJtdUXOYattLIyqU/xizDW9CtGMVzklS
rWN1T5EzWUgsWqrbCr1HGIbGK60+q3CzHfBR3365d6b7n05IreiZQZ/BDdZ5jHjLeY+zFDpTSOgu
Mn+JDdDjuflJmn8iI7epBx2q3yNC7r+rZdbeJnOTWqN+Ua2Wd4mXpE48C8kVgxkBU9B0JSujr8yA
3IwdvOwRGjehf+hhOZ7i599eXJ+WK9UDhYTFsapTa4xCqPeUq8HR8L1QPOHPcGrBORdDJfh8h/Mw
a3+K/o3kGdJrvvfS5pGhWd6A+hClHfaKforNJ/9VOaB5n6vSacY/EK6Da2Q8hoRDVmV2RVx1wHBc
wy//ExO8xydGf1c0LSMhyL+xpaFMXV7uQy+DFbxDNoAhTG/SSOoX/o1PfDpz5FjVArYnj3Jkj6k9
01raeapcy/cZaj0K78t+ZnuCPt4CC7Vd7/BFx26lA6rpuO40hEL6vc1EOTQj7ArzEfvzR0hrYzpr
Pxd9fWubIV8guQGR+DxpHHXfOGTNqoyUhHoesBTMECOQ/nvuvSiqmqGkLxX/pqRLt+Kdiegpo0KY
kIsh3Gxe9cKc+BVEO0P/IYYDSNQxQY7VY8ieOI0L1deXxSXqSpoEVvtJem7knjDGNf/tMy5CcVK0
45/GhuIrW7rUdcviGXJvyRCyNS3r/TmnjgPdooMomlP7tiIC1XNi87cSOR8/ktCJF3ysEcjrgmCt
Vb1pGtyYDS9WtgEX75burBdeTZPinAqtPc6BWKHpPNKNumUZIm12NR/qp6ps/SDnff/ECXy2AAOV
FqCAyyqFsdl6kHaGc4mz/mR1n2gBT/CUIpkQL/imH7Q1G58VSaWTFdpZQuTaDcICQEzwtImEB+Dl
/SL7LVVV0OtD5UCDzcBByiD1u65QTy260MSuEXfmyt1uhsxqcF6Nb5Yzo5RK+aXBMHLZpZtA46XB
g281wHY3HCUB0js5BZUQIOde98vfaqdHbJp/lL8Mz3UicjHs/IzJ5WkWJsjTBG29zw/rnnd91+P/
skbRQw5GosWr0wuiSFmlUk9xbWqkpBXZEEwbBwLJ9PEkgNXz65ng4V2fTNVkZ6hZ6Imu8E2aBj/5
Cqhjphyy+wY6uuBz0O/i2dRvfliiXnLjcBMusvE1LE3HE9NIF3coARJCOZLiXEAM1rASxhzO0xqa
qOUjfJnK7/SsVmNAw9SsEHED+Bi5+Q1uI4Jw8Quk9fNixzsTFHb+yPY2N5oLDprIzJ6yBGxm+Jhf
kUD2Btt0QVN9Sk9WMmM/auql+odDks3eZmTFoB7yVXu82CwqfdbcvBGy7DzxoVgSFi7Lo04m1Gt4
GYV4Ddmph3xrvEsMeaNok8Vz+Vh9tDsLw0KhTAxBID/jmBxqll+0QoHsnr4FFX6SH1W8lmae5ABR
Voi1drM6JvuHixNix1GG8ZLqq0iiHHWc2MeyW2v6khPvDeGUU4nhWXaxjQJhd2Ut5kBfQrRN0CMX
O3Dhpin2bsroQtfFs3KHxbh9r3CR1KrCQc+u7mrBAg/Jc4NZfIUqlnALOUh3ec0qd4UrEuMWkYvQ
h21Wjsh1kEg/yGERXZRb5ThRN+7Iq7HJ61HjgUoJ9teDJ77uUuDKWBSgSHPEjeVzE95cNBOWlGx2
okdtiBlW6H7je6MiJE3WawBhiIy0gULHqb35iZ5Zjj5xplPaa2LaFtcyCX7ThDusZix52biQ+xu0
/YlToZqUpLsX9TJa/0t9j43k8HXziMtpb/6Iar2dfSDvy7/qF8oTxznvj5V7GF6f3jfYjduc8VRr
A+Fqf/TuhrlnllGN3erMowVeK8wr9pWPOwzG/sIukdlOYcNxGk++BYjS49qhDMNKYbw444up52PV
CzkrDR/XwRtZi7fc8N1Q9vtc1HgqJxJHMtc+Q99tb0mPQz5JPOxSi8QuF/xnOnqDCVirKeN8gFgv
lo0YIcV4j4bW4H5mhM1VaaikOgb3nBxFdlkLkt2d8ElvVC3a08c1wp5GOj/iic5S5laJyQvqBxY6
sc9ozl8ZvEzKibflnrI32rJ5YzvlKUF4bF7iEIqM9/9km8YaLNHimakbtO05mEPZeCTQD35QYieM
ljOAlGdmY7s8+f+APO0xBrVONFueA6fl+PpiIRe+/7DJHhG6tNjOpu7W2X1VDum3Vansb7TVMYmN
k2px/7JYKD+zMqYmV+TBgyVGovObNBbCd86S1/J+dqhBTexiftA/bmxko3LKyJyTFN/cCmvbJSS1
y1kafVQVVkYPW9Bux0zFAesFt5mR1UBClf25523sxpZ3ajURpH2Zktj29SYbKLf1A3BOsH52mHzO
EEdORwEOjdB+j86+7TRS8KAOg06erfzxVQ+Dca/vNvGW0fCFS7DpqnTTjAu8ZP0bnSx21lifpzDZ
ak8l0M4OMkjIPRbyXsGsLConktqm6IeERC3aneuZpQWbV0UU4M52p3Uzrgd82S+iFLot8sYDbaU/
aYF0NdOWxNlIjmpSlJoiKcHx57PNY/9sDEEKtxU+6NJBWqZhIDStGDx+qDhTcEYCOCZMYfK9fbIv
IA0D2fR8nyL1ShtLQwnoqXhE0GbnDqfPMdBR3kswRG0E8xDhYBlNFQZjJAixkUh04h4y35R2a1Lg
sdcD8NNwEw2oKytWgDCuxYNgpjMBpQeoD4EGbjHi6qV41Sp7pEyBP8SAALO9mfjibwhjiw2Cenj7
tEY7/UupV8ML4w6j7+nkVAbw1+ACmR7iqcYgN/0u6byVA2nF0hBoCUM9bhLifQLM+F0lE7I15edW
nPuCyC+V1bk8dG61vB+oWfpv81KrWTJkX9PeQnZr+1VKP+I8M3Y5vKMY6MJubmTG6b32I/+sLlC+
FSJ3wRN2SqGiE8g1cXSTOjFCD//JlQMfPvDgWGeVgOZuMn7m7vR2twAxVjjifhPCblgdgFQ3qe0S
n4D7eQqvAPKoREGpO2nlKSgPs4lrGFY69USCGbAMk2pxLcvYLpBOsHZiIJZ+eZ9OlF4AYg8d98on
mKK69xWQkpo1X566HUPgqLxHz/X7+P+b4hnoDeAruuCjOdsIrS9/5dkEssAhCpVgoCef8rhomyCE
6kTOm1Qv94aAUPUuyFbFGaJtZ6tDmFs3b7an+vB3D3cDCamf+K9lHIBYEM77SV55V2WL2LOVi5RC
4xAwiPxRyfPMbinDF4a/TQwWvYu1dsIPsSqUDoqoJphU1qYNHBP5rBGmPaAE4odd59Z77yRXB0Xd
Jaht83sWwQuN31zDnRjxpQt5nqL9p+fTxOxiAesVbsf7Q786f7oEI78iiFgIF+ZchGxcY7vubLzZ
fS8syCmRsurXizzgFJGvMnTJ2hRlaN0JmG+ZXVGmLotF9po6m3t21d4/H36kHDnA2GaK5/0ZEosn
iYoo++9Lo3eoK/hjPkm9ZzH+ct92T9kgmQYSl7qGK4cwpXE5kfaj98PLOd0IXEc4e8oWU52Ugy2I
XqBKFqDSHRtBdU8SecwpipuZ3iBMd3nKUt1dkwvTZXW69bFniPseKY9mgxo+JzXAnOCMSwj6TXQU
c3jN5ikhtvjx/+5FnwmnbgRKt1i4ESLZJYRVHnhAJ3/cJ5PJYTpRj32F7s2Wf3q7GApraF+SJd1J
X9bQWHNVzXuc0g0nbVonc6XyFI0ZdveA/2wb9M0PFw6/bwnhU9Ex3pPddkMxnsbHzBuCCFTF8gdj
zpq4Ex0SjiH0eo35rFul2DhJ7ij9fUEjhIVl1xaQF5kMWkdvQzApkX6yNG/xrRt4L5IyBoBhNi/8
K4A9uU6kkqBy0MJQ9jdd7WwH+hclyySfx/qelUKwUfsBUdemxJ1QFb/JCXUGKdi686CxJFrOgakA
OaBD8MPG8cKGxRVTJI06AxJCt9+8t5se6XTbP2uYgMhn9AR1XNfjrk1+9/fVItR9zLYqbXcJMps7
S+qLofM6dLYkQTT/N6VA3rGAJ88mHJ11s3E+GEWxm8SnapWjd/CPi567iRDrcn0c0y2wd5flqJlZ
nRolyXkMTOvom5KnoD2lNYI8B2owtLblm4SAzmKe+chN+jb5hBLVjScdUFabjaaW2fCXJWSgoGLD
6Sj9hH0PpvKcoezdwhxQsAr8HsdbmlQaWECpXNULI4KNYX4kYt8CpKbUh9kEQDR4joaPQlMRTW9B
oCzYiiyih0A54n5xXQtITgC1TPa6y7SKXwzeUGm+nJqQTz0nSkB19wKBozUOatQprM60h/H0ERG5
AnT4Uoo4RbatoRQ76/loc6fXvhkTuJHu5Op8I45PS4iqB5OCJ6Jte5wLBENa3ZG7ZcU4lVlazi6f
WTqNSJPKpGuC1xe4c5aqz0NJRvuiZNY97YHqxuYRmEWyyIEyIRFrpzmelmSmvFUaWESNqP3js8hX
zXEFuDKWxy+QoS+uo10v2x0Wv5mYx/3NgRJKPaap3J+xoPgUymCMvvNsijFrLeNO6SYUKpabJcep
aNcarJ8yrTHZ8xcZt3sCC2lRAgsmrCVxXxg7b/GlRuVY7qr6qcYwwuo83GchqoxvqPX4k3ijAmKC
2i7hwHMhYX0XKReCHebHpUJrJPL0A+nAN2U7nNMaFMQQ2fzUzJcC4SjhCZ0+V49Pi2K7Qt16KxDR
gOiqq5+O3LGyreJvW7TbLqu4TTrvJx5xySwhjLdMfSfs6aREaTrwDSdKZJjjl5Ad3EyWx5NZSrDw
YfcC3UWjAx7SVdOTPU1OFBSqOcqu1ScSfeaiknEyNf5D4lOEftA+LbccPNbkbXfSpIIls9v9nWd6
Oi6tPGKpvZQfW690eu5WCxreLbsulujw5gLGwvokxBNGwuMDV4A6rRoTdXaXeW2dYP4qUmp+D6BU
OfCL/I+ldTORpZhKg66oAP8TOfvnntwkpUbG/eV6FHuNA8KkwhXuTOv77xHIX68s7Wk5l00iUqQg
1UzZ0FLnLvGk93vYihfYqFM5HbOKkLiF3W73oMxYKC3vqIEai90Aqo9E2urBx7mLGhytHvilJUOQ
hwTAnOW4GtDD9fU9tL6+1VjzZ3mUWqtPAz7HIcG8RxVBU+PadbwjK4peawFrJNKDGxKHPwDny93P
bMZv5ogCL+bFWeHja9jltEkABkSHYNW+rRLM1IZe0zLd4UfIKysj9FpBmXrBBDd3vPjN0i/npMqo
NRXTFBnHPzcF3Pxx/PSvUMDwZoYTKMTN2PJqrhunRB+3a5M8QVV6Ddl3/GxiJ0U/F+HmhYHWTV6k
9K8uSgXHW8xM9XQQlYGyp+aMQUKlX1KV7HhWvLzrNUNesOfcT61DVpZdD6vB5aSNjBraUpUfyWAn
/4q3dGbXQRUXMEtEfAwlUerKKHWqHdNQ1vEHU81/2Arc5WRsD2Vb8FqQTePKU5vc/18ZrouodDA8
dgt93LCo1ZUUx6DhnLwdbjtG77PLdXmdiDO9HQeTg7nXDMLSbgopPektgZ0AcE9yE9A4rpaY0wKF
OhUSLLHF/bH/bUBh5uKU/IrrZAcL1oJh8YBccXGPtlfP1cu/SJSt0ulSmwxpk01132VBuyFsy32n
Q/Qvz0bSONAqRG2+u5kNpTBEoFhWWs5Uor3o6IHfjERQuKlEiEzBtu5bIQkqOlI3t9Dls95IAFhh
pEDk4kj4eCRaNgFLFp2/DTu+GOCTgISeu4S+nqSoMo9EBqjuHp2tp0ZuAeHG5PTaEWBSt+QoP1BX
UApo0YaJgv4k4dRDz70UYP7lYhR8mErCQ6QIUYZzn5tKt8Y4aRjs9MfM3E6WoTM3E9kmGBTjygsh
YS39YsENSYi/eZKDVC0uzSv0xyT6e/A/T0AY57brMX8F595UI4lxIUNjcVvTnWAPYBvroeUWU4eI
c+EHxAfWruYfnI26a2c4nh7sEDJIq1WF2Zll4BCR9Ct4toGHyZJtkxzfk34ayjmPgIPpU52A9BXW
ivcW/p0Dcuh908O9AUDm1QtTDXh3pKUzzIP1YJ2w84TPKxc3yLX4wbgOIf65MVvTC6PrngauavqL
JMK9MPqIxd5VjvL5qGODKaJLSr1o+bdSSUb74J7o/VzTmTaCFHMbV5jFcAhlOpCwHESZ21DXX3Uz
OnloKDZRpSYjjL68xWpBNMCgS+GQZVcmxnGgeODiiV917rrre4hDPqqMps54hbQYrm16oGaVhupb
29xSjW1pg3x9IxLfKv92v35BY5ScQ2+roESb/oNeb5r1UacfOVKp8pWVJqj/9dXdSUhZ45RCspbU
yfv5sCGvLvqOO4/DyQF0AgD84jTYWYq+xmNYMVrbLbXrZlZKZNIxBNv5otZwEPOLa+HwYJedW8U+
DA+wqb0TzZI5lQiNVHJwXeFVGWGKQ+4e8x2FcRlZtGmuxaC0toGnb4252Oq6hb8JPAzDsGRLybQO
bQBUmewkyirKrg7h5nxSoX8PtsWAGQlZdBofb69t1Ao5OZ4xeP4kCBYUhakM/xjOdBCgLFjcvG2q
1U26xF+8DpnIZUURLaSeV6uFW0ADxN8du89BkzID3FH8QUzCdS9Zy2RQiMxrJC4sPQ6qJRFLDpEh
wHholABCdl8U4cOV9daSpY/EYGTMQxSEuNedpaFmTcmMP9hwSSOO71LuoBHHptPID/qWOuYveTb0
XQjcROIX1+H4432wXG36c5QEAiT2mRPb8+TekfM4AZAKeEFAfmFyvMAKVAtCKgiTh9BQiBqaZj4A
VGUqtL3jDS1kOmrcwFo+9JBdldKPCTuRxwPG/Zw6gKL/jvIu8fff93KM3OhyVuvnvLf/4dAvAck/
F8fQ/ImraRTptU4REWTibMllkojRjWxRhhsKYmduyQ1KG99OfHgkqmwZ3DnkbtQ/xAcOSNdwxbPG
3D1twgnIq6212qES95h1Ngbk4ClRTybxs75PhHmRWKSvCiN3zXg/w9zIWOw52/l6/5Lq3K9V3P0j
pH+2XggaT+Odbx8C5JNRTChrNQdxs+0TP7vxzAEH6DoSBp927Dl/8+LI+5+KRua10GzQMIV6A3eh
59cSZGhlUWwp3FIdx9GI8gHyNOdBDsiX7/b8/DKwcoaRi06vBJAP74ylO2v2fqdKSdADZiEWHiRM
skvZoI4LLQ2/irg647ra2ktPZk9ADERWPPA7CTzOSTYsYjJ3H5hQt1gET8neJqKTfP7rTpM8dJD3
ERjef/8ZqZkm7ekxEVq49Jz+f1nHRSjAXrCuqRj0BZk13YdqUNOTvFvkW1dLtmxOmR/lBB7wFQDc
O0QdUrMt0asF+eCIZSwvxlHHIIDpYPMxfDTeZUN6kDhZqbh7ajtxFe7W4yFtRwZ5v3VSeMPX5ADX
JPcssrSmKZl/fv+rTYu4NIpIHf+YZfHCnTf4FkdOEylkvyTGuKmWF2L04+1skRRsBxLZyciMNMz4
vvNE78SyyfgNFSCSQlz1rKOOeA+fMsz5nxhnudC3g4U2ueTZ5NfkEa2Fo1FQ6jLUYSj/lfULgvR9
uX1qwz4Qm3NCip8WFkbZmlcEeTh80cWLyh8VUrATbLCfmmyn1oQH/0bQLvVSYxxppldLGka3UQyj
VkUZMFiVSJsLr7mXC77qfU2RB8rp9e2l+8apMYTjy7zzLA12yVy99Ioy17o+gUtMt/Ce3RblPJI1
VntN+Ahw+NoU3FBH1UYNzlG33F7NmLQ94fTZPUXBhvTL0w6ry4Rj5v56eaPMzBMl3KiWWw5bNKfT
ckNuNGlQgJXO7rOVkKHNVfDWB+YVkzFmvmpkh57vlV2JN8fRVdrCmM48K/1QzYqfuqXxJLjSRh/u
fENe67jT2Kiw9Z7I0eqURecTLY9+NUeGJaAdPW5a3GtcNUaP0F/5b0ySlnbjbWZh41ygWWeJsYji
547VG5a7nA6Vk6afJ+f7xsCtri9Ab5Asz3bWiZH7SbMKDRVG68hvFmp0uvMtkPH7dlFeIWcix49y
HIUbbflA6lIdqk6Og25qpvXGydMnq9bg0hI60epxd0H3ixBy+lufOEYXsY5JxWWIe0tPe11itVaY
5/Ij49wXhWD3TAS+84dfIspysXLLuuvGhNMPGFgaOeLAnv4hCq72Xkay0+RnFG0GcaOtBHq1T3La
UZHu17y4o4ebwdkx9JqL6xXUhtuHuC5KkXZlu97GWnQVsCjRNViKkKJ9r+iZH9N9KJzINzoVbI0+
NmR1Nxjz/B5HJ7XOG2gtVoZDUY5UblB1aUpIlequM8h2fYM7P7Pn1XbNpB9WtzXlaFHkm+AuDppP
VZhihZhrpyzrNkoOybqn/zGUo1X4EDDEK5HfJbgajB2NJhtjrKHlUmKAPDzgHLXY3k4oAemhh1xt
s87HryJ9Qj6pUPIkeAyzCcp408qJtLY0VAYc+O63R7p6SZlAFtx3G3W2N3ZxKqumIWGpjBTHmOve
ihn8YUu0aICaIUFHrYAnfa3QAsCP037T4txg/yVJPUnyn1qIEeqR+XTyBQqgFA5OcY623up9ZAu8
vTG5p6J49CMvmu1wJCF2j98Ak67D55PkCV4tdCLFJLhGnxrOJsU+DvaVRiI0UtzUBxbQiy3XJf/N
j2irDj9aBl9ME+1AuzCFvbDjnA+Boapa/nWq7XGWF6+Rs+Q1TutwikuMQUji1yC/OykJZ/nu5MCq
VYhXFL5JhFbDHod5d9jLKk4wbWH+hsNKwno1QzmwW/YqZ5I5cspl5AxnBabAmzAYQJNlQRS5FGXj
CQlmzafX6vGy9jklM5UnxEW01cfmV6J2P4pjvws0ASmcds5nfyePopTeOsgzT0BUaGFEgqCgN4he
gjnNrQbp1sxyVE5wKjXkfbPgRvKl+YWQY1TmtImpBfYKhZs3L4p5S76L4KwBI1zSDLIAwXTnwAuH
HUmLP6ktpiScxD+L735EqddiEbraILMGE0INguUKGByk09Xr+eIC1Uip0OnCu7qb7OkeaT+MSI6i
3dVNTUPU8i8XxA2+nqoOT6g1cwQgai74n6IkEQaw5EzGHT8wKITuukv78GkDm87zhQmfS90QuI6E
zEL2x+HThDIbqukAYb+2dd6ZwUcD2cwG+Uau3uBn7yzuLa1rYmLcQMlGYzDVC+7tsmT1EjNmiEvW
ariV0RYvO0szHumsmaadydmdzdUo6CHpgNyfkGk9+sz4o5pdBN+jbPd/844tA1fxR1SDX+g4QQi/
aEVkdTnuBe9WKVIkIaflmoYiYPRYhYORZRP9nIpVfWFaVY3fVqSfklBoKBnwre/wVdDfjIj+V3We
4ABENQDaydRxZKT0TbTdcdx5zDUOUIKcC1apfyX+jnplylf0NYjiIlxnLr527rXVgVIwVMoiIgb2
JNNGpJS5mwb1BiULh0zeoEOn0RIdwt07n7EHdZuR7WulAIPjZWKKKgFvYTUKI+vVqRFyOEcjkBUf
LZJUeiJzQT+LKEnwb2/shPQGTwWkapYi/eozWZyKeTlWB8KwjlkpojjuDLtcro5h89Irj1JfvJ9t
tTezDC2ofGJbg4djz7ev95GgihyqVzrONRsc8Ipl9nqPOkLGI4jC/6qsvKRdJpT/7+hwKfslApeL
UbKQQViEnEmNnwvVXFdm4qCEsdehX1+O4uQ7rQAQdpdvS3qziVLpy26YN5LZ3QDrLi/9PGyuuGFu
/42u7DmOS9VOI2duzrU2I3fsihejUSGedyg88+2KIS06mficnbBzcK8zuPOEKUrH1qP8ZA4BUabn
0fS2vuPu9Cj/fxiUpHWqqDXdFgD66ajYJl/Jntbf4CpuXj0ODS4gJIvzxOt77P4BanD/Yd6frjks
Vd1ugUfdByU1InYU89fxmbT4l2u9LIFbSIaHmIcVWg33xc4Y6+uJDIGBmyUxf4RLudui1PW1v0PS
VOkx08QghruHrO0BO9UvsB79w0RrBusEost2Aji0y0NhzfUKxYYxE/iLbWb+g9iw4vSve9TXecJr
jthOm6di5kfPye48KaDmQ0yn6HFv7+76qpIynrpP8P6YtM9bg6uQBnlLvJ3y3ZP9ryEkGb6R1JKa
cWVjVO6P+qyw4ue0WMIh2RCU5PjguA2RI0bfl/srnco0UDdBqYw3p1YIhuGCedOngoyI2sYLRdrj
omnsu8x4TToGjcW42KsqEcm4WU0mItnGFQY/O6RFQdpUMMR7CT4dYIn1QBIDZaBGvtacmLHjzzJr
oVBEAfAT97PRc3McQx36Qy+8NOAZNktB+g/vbF1yRbxX4CkurCXjE5uDlnwIqpj2Ib78GY3fiOVW
hwNM/tYpyGl++6kBTkdUtr7syXVsOULff56WnrOn9/jZb/NjSgoUsmrHbT1s/4XVVL4DGr7S33MG
j0Bd0F73HyMGEjAYvZlLDXcmTAnoTpsi52Y1vOkLhcca7eCEXYg0zIY4FFJDASlJiar4+ZIwJMNN
nSQlbLhsD4lcSTsK5QcHk/FxY0FVNSWwyijfsbzLdZUYI/xgmdVfyPzWrAKAA98LeAWYrE2arpI7
guEhAMax1faiu+hWHAsTvjKbFRysr2b56zlJHWUaDN4j5CiyAHj28tmb6DrLfyn37ARQLY1i2ZfA
PUmKg3ePGtNzhC+A+Eko5LFEyAUv/myHmNETc5S2mn6uizKX5v4zyN1BGdI0Q7RdgwOQvyEn9cYc
uZATdjPn1+mnpOyQ38knohmWBbTq9gpsW2PrVj5V+UR2Z0djpLS0hYiW2CMV94pG2d6JLOgSQIAa
jMQh46lwA+yYbhLKxvemCPInARibI/Qg+uBu/BDfv3ji6ALj7OPBTMuivEhw/rYP36SUmFPFZ6hr
8ewqOpuFL/PNsmxT6RACyCOrcWMMDdeMjz1grPknSyuwlm6hwzY93GcKNbMxcemOr2WbdEh9SfI+
vELcfcspSroXqlrdG7xlKxjQy8CQfaCC7/ub/RxadkkbdX0zhXQBavRLy+XyQiJbGjaOJvjrKv14
f98alGhstqIKJVWnibhFr+lPqjiKlFyuhBOl+iSRIvY4IR6bYI1GDrbqkAtBAAPcUDcuDPuxWKsF
YdzhmvdcKfwDrgicq6JDEXnlt4kSdYBwxKUhOuG8rhiGkjv2ffcBh2x63hqqHNaX96CndeJL8/C/
TLG+60GUP+AEdPp4E8yzI6c6+UJApJSgPQOIFTKsHfPdYLGTyV2/6NcW8fEVRCdeTwOOaPoynzUB
28BjUCxXqWAO/9gfvIswXG/yv6MVNk31dJRHutjWMvFSHKvpIUp6MaEXpmWN/VU5fLM6B1N3FlaX
qPmsiCD1fsYV+BVneNZfgzVvv6trj4ykmc4vVBAO26XOz5nH7vyfeCQjvBvjYcmQwfArTJvWwH+9
3GD2J60CHBQb75q+QNrKjaHa0xGrNrMGQJnqGEQbCsHvBOd6mtloUF4JAujQGw6dbu5ysoXgWrsL
OJHMGlysKEB3lAdrGECDqJLLqDeaxImpSsp8nNwxN7sH8/9kJakuG5tU+nfbBxSec9uul9mt2nBR
YV90lMGhpkvwfRRW0gAjGajuKGaUzOoABnRjQG9ElwmPeeMZpGcVhE+d4iPig7t0s0hbxCbRTvI5
nOAxyDJviOGxr2o2kQWltLAJIQnJWXUq6nMCdnK8aKs0tZw462pVichF35on1dvPfjfK399uRqlH
dGU6zKKUu+4WMMVgDsXNcYwX6CsJ28nnIribnIowujCE3yo4mkg7+D4Hi61UEDbRrICCpNrPynM2
UZ6mdtT6HlIfdpnWjQAMyayPwKjXdXsxUZw2JpF7V8w4GizWQTk+UTBQV6lEmHsTnubsoFyr/ydu
fGrX+jK/aFQ37OWiXWw0Gd4kkEYFBb+K96y5Fd1l8GulpfXwBOeEZA9040Vi1cqqF1y5EVHsbmse
eJ2ch9kfbotBW8q1y8V5OYOzC9T55gatWnAl76TRDHa4xdXot71PPlWMOjIW3dz8QGmerOiSNUjg
LWnZy2seWaG09PoaoNOp15CFyxE3vSeyz5kqZzu12YTkQN17RJ+5Z5bBpgNhKpP1K7DUDApwD8uB
ODUXJuPwCbYT1sW1VTs374YC6NOTkv13+f4K6eFCL8L6Ya3jgvL1pyyKK9YNMHadeDzZ6wdyuceJ
eCZMmXuOKbYVPPrB/+fZZcFsAFntEWMzMwAK63qiVY6vzZs2PopAeHVQTVuQ3Bv7NglRmgWFMVXN
+Nju1YxjLMn6Pc/ZIZnVyk1L1w2aWm9vebet3vkPYsE6kkOK75rI4FlB3MzXwMsAqQX+s7M52LxB
QxonGYt3BxW978k5/aLrrTpEMkg1afa64W8k3RXBX2HJBl0JiXYT+ieeKDQY7S5W/edhL3Tn0Sz5
j4tCKslqjIQEEWhYYcXokCtigCacEbREKdaEG28GwqfULOz0F3QcprbIoV66WeV7R0aIxNNxHSFq
Coosnu26IbE0VjH/J08ak7tb3K+NAhbtUfHGM4b4LphRapuisV4Zeqv/dxMMu69rpNviSEWqNYLG
ACGrvnhwrkLxLuWGAssqC6V5UW/JxHGNyDAAn+S6DzyNUpJcpKFPrbNxjaCN6ELc5n0jNtunS2jL
5KVkS8OpBtfW4b2aeyLjlohrB6mp5NEoEAj4Pt2tyUbt1TvGPcKlcpCuysiUsThc7hyrgnHfFimY
lZQsHYyRNS3ejyh8qT0N9y93Izh5zrhMabxXU03UTTkwXNKT2zWZHQ8WynpSamp0msycGRYXf5LP
ecXuhbycyr24TptescQRQSBoZV6YpYrTNLm5FdS6kVyRnmKqtnjencP+XbYGfwia4ic3BlHKLSzY
sxbZAsgDHEbAdWZW3VJ7knBDJZqLTvx5v+x6PJmI2qSAmeAJAdEKfuijjKR1ChQiJ9PPgN3JUWFZ
JTXEc3NxKVRGlGsgef4jlcGaS16h+rgvz8mdD7boOl6fVeV49jfUN9rRk6zmqTeHw0xQYgZW1vcF
o4sN1BFZBS8Dr5aR7xH4S+FeWXRtXZPzTn7kmDZk+v4LwN5ac3QqTxkkuQxQTgb1adL/h/vT57r+
hAOQNbcU9HPMr3ZkceOjiDlOlptxwAPwg/gurfgbTJvpeiWc40tm8ZM6rt7exlXBuUYuMJTjtSdC
MjFOQZUoCIVOJUFNV/ER1kJVmwOnPKKk5dOmX4wJBJ4sdrVbsSzvRhjDeqbJC5Q50POe9sSU1AwD
l53ITa5Cv3iljvYsgC239rZKs4jsfQ0VWWrU3LXBZWbERQAnDfFo5S3QcxRCLbXwhDpjLk5gs7fI
T9CmO5vOH/y9NanrK9yNSEnfcTpGGKvXHEIu2o5LeT80Z17p9M9ojSpGakLZSAwLcx2Lu42qhQz8
V6MAok7jSjCN55wZUAw6JhJdIGH9hLsVK+IozMuOqktHITm7NNvJLGYY8UQSAiftPBNiGGscwo34
US2BlUkOGNEHwgY5B/gcd/nS401IzwW0hDrRMkEVe249DGpWFvBKHGFKVW0V98lP+wbg4DYvjC0s
P+l7uaZpA5hKaId6n3Stb38JVZoExTxNW2mmauKJrIvZrCsHuirifAdjWNxpyvIYzazAo90tdlrs
yUFsVGJxOSgWPXzWBP1oOwNcOolF8tsdmccxdhISPs8GThhRbUKNIqebQ9afZsQ6ejqkYtD964+f
epRl1cOJbo7fBNTy0whVx9Y7ye4hxyy8vB0zMDWI886CTixHLIy4oATCgIfBDlI/GmVNOH/EPNDt
+xg6zTTcx1VwEV636nRac9eifyVlpbUGh/7gsjLVM1TMrPqxd+X36tH6A3QxSf4Xdyh2a4BT/vK7
s85VdphO3pSTftkmVlQamASqjnHFegN0Oir3c2SGoWlWZvTxApJ0fa11JqzCCmxxkC1dCnwrQln9
rqZdhpHvKZUe2f0b4DBNoVKBRI88aigI/Ed9l2pygThdeRBkq5MZcSKs584J+OGarTO4yKtnV8Na
Zmo4tPu4D5nz/fXxfKSmXxiBjQinsT0KIaO9Z7bYvTgKD9Z5TwGk+Ejn4sD8yZeQ4zyX63/7eFoV
vsUmZDDw1d31fPqG/4BpCoreUitw+uNlP2En+MK+xw2zRxe1fsllxZ++7XDB0cWI1Lw7iF4bDa/P
HXVhM2eJQNOEuvkuEbdZFsgXj5P5PzLpwCqKMjEbQi5z7g474MOmhbVvmMbADdX87qbnbQxb73QU
FV8hI7vK4Scp5zQjquLEOZH7nT/cw86ALnLAJaHiKmE3TCnrN2GaItmyhZgRlujW3BFci6zoGy2X
ZH2SDVsT3ogvYqEkWOau5fYcA19AaXMmua9u8JNQBPaGljSHT+YdJXDhuOoFl07obGQ34vKyjkk+
V/AKZlyprgTitxnka5spCrJfgY5ykR2Tw4xCjktwwMQINn5W9GdKDDZe9iuz2OU7/NeelFgGv41d
3lxPZX1ijK37QTIzYkurKvCqqwnEXkhWZB+zceEzvrDdinqY+2Ia8YDfPzRalJme24A+u8QpsUpa
7ael5AZO9SquT+LTFMNYfnjo3jdJxpmursgDdUL1mIgNhXEnkFIdqKgap2zf4LEykqV6TwSC6ybE
F7Nmj8imM6TEkkubzBQXU7OSXS3FSX4EQumqRTOoWahs0tKMaHE9pxHeRTRdwO1kBiDFMvye41LG
tb6P4943k+BnDSNvOnJGELULdi5p0l74LZqwgO5WjWSbUUQ5+AkC6Fq4ePKq6eW9LsMrgJfYN9Hf
oXSZrw2LYo84mJ3Q43q+/ea5Q37WrKDi1MkhSf0fw9M4YCIX6koHVfRkOQbdr4ZevE0rncajqX5V
zYZDhi4/8gqNvtk14fxv1KhXR5aD7tkH2lHSCundlmd2vAFSX9nKMP1B/7Q5+mgpy/UA+QXP5BK/
J0MAPaQT/6cb5zBtrzvFQ6i5Z6jEVhy67RseZ//IqVzmP1qAHAIgZOcdG+ow1Yxc/4NFkNaz9Rsu
f+y2r9mlH1WKwWKKuugP6a6V9uPmsASgYra7IGql1DUizqnMmRjpgG4Sqv/MOo6rVCNjvhqiftEi
pkIcB22h/Ex6DOnoCzlygvZayl2O3dnXFJUBC89/+6i5rOWlZWogpfkr9I/WTgUxE2ZMpjbygvE4
BDaj56o/ZrSMx+CdwueSlh8sda9DgDoY4UoW2RvsCdC+Er3kS6jY7bxWzk7UmcNvDP9DWuGnlCVB
/xX/AdziyXeZ2mRZqD/cBr/MeVzpbepkUcSJ2wh9FH8X6lXL+u7TMhF2/UohMSbF6mMV/64krrEE
NN29kMPNcOL0QDlwivWY+AUFLCB2cxecoIg4y5j8U66qalUiM0il+rAszP2mtkvjx4e8ZjiYgtQo
Na52Gux9slGqnOgNYi3+xH/Z0JCk0/Nm29zOHfe+/BS8AUceOTeYRy0aOOwcm874568EChdjY6mR
teF+kwJ7LA3kZ9odznyT327kiKdq9X+hQAqNcqKSbR8PARRmsqWCG3Myh8up77uXW7pTF2j8L2dD
oUuio6yVlA9NePlqbLfaqgAfPrmFN0woq/jThIVqMoPAoMCMpRTxpMnUyAwcJA2SahK6cGRCKMoI
ToFvlJS6tYOX2t54x74aBaPao5LIeIFTA3B1p6jtHFdM5n3U9BWAJIo+HMhl+I3kPxyiT2bN3tWX
tk9fI5KuyhJK+2rtZLXAlg6XfsGVIN/BzsVvPA7a0tWYuGmw5qUhnfEuGn4aS1DJsH3Im2anJPFs
jAX7UMJL3ZyNanFda9EZe4QSOMcVG5AE4CIhATOw/3U4pLneImzG3EErGkX1CHAUOvn8uG0SH+L+
LP8TtPasaHBR3FtIgazBv+8XJ/tZ/XixFRSUd2b3pyhU2JRdA7hDHA9njJebPRe741np2DlgFJg9
X1EZOUytBCw+eTVSI8afKAgb7Kwvx+jsbtKwyZSooMkgpBx6+istlxfvV7bfuR5hG4XnmIY6ClUi
jXKKdswzqqVM7kTpSMGD9pEc+AgZHBShByjvcBO0jgjK/uBH1DivrTwCu2fVm3F0XUWOML0rfIiQ
vfYjr0b3sGSgNofuYSrLnl/9HG4sU3EOz/GywfeEDT9vQ8ctFZQlhCIYcehrnjJnx9U/jGLHlXYw
V/k2IPYrCmuBKskoUvrYw6CEE2q6DES2iU7/N9yFpCMw1/8K3Kn9nZBqVwOVrR2+t6fEd2DBkYSx
UlE+vRvn+TKhsDrWWgfzVz5+VKNPU5OeDVuzQgv4zMpzWRFJXZYRvuOvxtfj37D1cGyl+YZ9P0f9
rLFvAOdefDhnD98B+xKPQtW646qSwxh1BXCC0Ixc8993hagb7itcg7Rd9t+Mfw1Fa8rbwuS+mnET
WixZ9xhcOLDkv3tRDSWHkl1D9bqLFZIzH1oLWAS9NF1Y2/IXqmUBaHAfBgToEju2o1lr2fGijk2E
bjo0q1P1OetRKw+8bNJeYOdbv08a4AP+l03mQY53sshqMzClaVtwgTcGUKoarj4UWWEv0aPUAdp9
bbqyDF7pDnh0T1P2w/TxCVVP3vksggVSkImBb9Nf5Wz7K/fi/94bKYiQh2jeGnv4jSuNieIpnrn+
O3+sPYoJBysmI0MfUwIew8YET+7p891vvA/gmtC+/y0gbOtsAzYTRcS+xA6OPVNDA9LbDL17QGUA
rxHU1N8R2WY9qWkgiw9vohzAmtXQXoBs6L4ZKQKSCSqgx7XSkkk+d6K9Z0E2ziUigCoTy4nPyVw+
EFa4YhX7bJbh0jLB6V7MaE3EWUNElsKwis25A/lF617dtQTtN1ugqFikLHbIdUMKvGm1mg0W+EVf
qi3QPymIPZliNRNad43B5rMOfOTCc5xubsdEAn/MFba7OGVL2koCgG85iiDOFl2rXRHQp3sk6Y3f
YHhGqXYldhFhDw90v/zYqNxMViraLBbAJmFWblZ/uBxIycu3LyyGHLQo/DFz5KL2fUpnlwwaNIhX
v8wqIR71BRo4nLrimKTDWW38xZ5pMomm65H3WCXLKoNJzwCZvxl9qn7vcY3Ywfje9ASknTZ3gllT
eG4DdV8JgZGW6s1yAht+XW7Ga52m4gCRVdZ38Sl8VUSG33CISE54MJipg+3T/C8NxwI7D3rVZ4uI
WXUG5ICuNids8Moqtr7mtO8nlmGaXJR/BthxoE0n0fg+L1eeDQWxWpFwNlu4DqBaFq0VNSUUZ3vZ
e8YR/+7orhDW8qEVmLFJ3J+HObd/q7tcV5t68gKEq+LkrMo1aPwWEAa4ePb4/As0g8RkW/DoaQaj
cOt10OzsbJ5S394WlDWKXGcbUZhEeBuckrUIvag2a9oMQ2cFSBjPmL05Acqx3OA5q1+0yV8QwBWP
Bk6AdmpRJ2jRLWjlVmkhFRc8RFk+LaJeBRtXUzL3xs/B2axk8DbOy3i0WKgjhgOvOCbiwHSYaSPI
5yzwzAIUxkDQPs7QlYw3r7Z7enVz/TM0fUt0eYlwM8F8aWo7Fzu7lDo054hm49rRdyHdPIFleCe7
GQMuMiN6o02PiH6KigU4xpsrZ8JcW0tTyXE/InUFI2SZ+4EsVLCUh5rPLuIZhD3KK9+ETPrFa+gv
TtceSox0C4k3SiZhl0bl01HbXwn2DHQDu/em1KZPTi9YkW9Iryi3hdO+GIMV3GeeZIMUSR/bQQAy
ZM9P2XaQekLxrDk+3Njl3lAdV7TcedCjp+ieMVIHrz779ZgYt64JcxoxHvDphLaCqh5t+SRLQwWj
KSzFiTEE/ZLoI1fJjPnHEX8j8RK0HkbRoHvvKnTd+vtqcOqUdKmgEuU2Ax5/PriyhHGd22J4Qcyt
I6P0o/BfrrQ2okCoLNqPmhrx57QekSISeApEcpXhSBey1KIhaILkG4LDzYiHntU+OyiH59OsFEnr
JK/K9ARQi1ltVqV754GobbPgJTofpmDwS7fSecFPjkNBaiyDTl2H4jqZ/pmRcLpwNw2Lg8zEMBTj
w8nPS+IbppbS9nxi/ymbZSsC1paqaAfzt41m3quoVpg2nMfj3RwwAr4QBzT4JZu+MUoOBnp1IMmq
yAH+N343d1GBxPsWp+ltVSnwanMwNsaeu1w1n+hQ9HW6ME4pgiM8rU2LeHYORVaIh4fsXHv2PsdB
UvAGeRNzD1FhcfXxtuys6PtyrvwNyFhyTcAEeaMRZHB9rCp3VP8WxX9UNkf5JPXkXT+d5nZi80sP
1HFF/o9oGKvebo69GMrEDKjd/J9f5bjmHZPaHxrsNzwGUS8Pl7+jouhQgQ9/BoAd8O+re5vYyq+R
THJjywTMysv/SI0pA5+xOJSpUiPLFIGrirwWImIRIvBgGhAoc4RTZpad/RPD0/d7PMuY3c8pj3ED
xjSIiFktGBcQbh23bmetKwC4G3hsOr1Nr55yErXtpKZfHQE8j3QcCfRAJbGfGAo2C6tx2YlUC886
ZbYdh31a/jtqv7kmIz7GpJAyGjDyDwNaG0ygz5Z9jwhv8quFrITtGXlo+/wt0fvVYItN15u7y5Pn
dfoO8IsdBQr+dt4TrGJMkLTuQl6uUpl0Lf5qumFmNYM5Um1oFePGGLChM9LWUeGR40cqN4U8dx31
p/VAMDIPtoVShtchrreiLT5lEd9/xUErqLjS88W1n8J58NWfGelpT6axdoVqCRt/PsV+RUyl56xX
Fx5J1CRLlps+Oqk3z9wIBTAvNNmnqEDYOVJmtRkBcj2sV+5TeS8Y4FDGOn6kMawuyDzZxkfXP+uH
WktjRd6ZvVwWb43XqnvjVSoP8lRa2Ga7RV9T
`pragma protect end_protected
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
