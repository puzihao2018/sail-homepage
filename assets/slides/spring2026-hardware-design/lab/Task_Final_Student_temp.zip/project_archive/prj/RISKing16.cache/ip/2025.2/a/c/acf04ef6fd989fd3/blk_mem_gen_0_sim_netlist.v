// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2025.2 (win64) Build 6299465 Fri Nov 14 19:35:11 GMT 2025
// Date        : Tue Mar  3 23:27:03 2026
// Host        : TX14Air-ZIHAOPU running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode funcsim -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
//               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ blk_mem_gen_0_sim_netlist.v
// Design      : blk_mem_gen_0
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7a35tcpg236-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "blk_mem_gen_0,blk_mem_gen_v8_4_12,{}" *) (* downgradeipidentifiedwarnings = "yes" *) (* x_core_info = "blk_mem_gen_v8_4_12,Vivado 2025.2" *) 
(* NotValidForBitStream *)
module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix
   (clka,
    ena,
    wea,
    addra,
    dina,
    douta);
  (* x_interface_info = "xilinx.com:interface:bram:1.0 BRAM_PORTA CLK" *) (* x_interface_mode = "slave BRAM_PORTA" *) (* x_interface_parameter = "XIL_INTERFACENAME BRAM_PORTA, MEM_ADDRESS_MODE BYTE_ADDRESS, MEM_SIZE 8192, MEM_WIDTH 32, MEM_ECC NONE, MASTER_TYPE OTHER, READ_LATENCY 1" *) input clka;
  (* x_interface_info = "xilinx.com:interface:bram:1.0 BRAM_PORTA EN" *) input ena;
  (* x_interface_info = "xilinx.com:interface:bram:1.0 BRAM_PORTA WE" *) input [0:0]wea;
  (* x_interface_info = "xilinx.com:interface:bram:1.0 BRAM_PORTA ADDR" *) input [9:0]addra;
  (* x_interface_info = "xilinx.com:interface:bram:1.0 BRAM_PORTA DIN" *) input [15:0]dina;
  (* x_interface_info = "xilinx.com:interface:bram:1.0 BRAM_PORTA DOUT" *) output [15:0]douta;

  wire [9:0]addra;
  wire clka;
  wire [15:0]dina;
  wire [15:0]douta;
  wire ena;
  wire [0:0]wea;
  wire NLW_U0_dbiterr_UNCONNECTED;
  wire NLW_U0_rsta_busy_UNCONNECTED;
  wire NLW_U0_rstb_busy_UNCONNECTED;
  wire NLW_U0_s_axi_arready_UNCONNECTED;
  wire NLW_U0_s_axi_awready_UNCONNECTED;
  wire NLW_U0_s_axi_bvalid_UNCONNECTED;
  wire NLW_U0_s_axi_dbiterr_UNCONNECTED;
  wire NLW_U0_s_axi_rlast_UNCONNECTED;
  wire NLW_U0_s_axi_rvalid_UNCONNECTED;
  wire NLW_U0_s_axi_sbiterr_UNCONNECTED;
  wire NLW_U0_s_axi_wready_UNCONNECTED;
  wire NLW_U0_sbiterr_UNCONNECTED;
  wire [15:0]NLW_U0_doutb_UNCONNECTED;
  wire [9:0]NLW_U0_rdaddrecc_UNCONNECTED;
  wire [3:0]NLW_U0_s_axi_bid_UNCONNECTED;
  wire [1:0]NLW_U0_s_axi_bresp_UNCONNECTED;
  wire [9:0]NLW_U0_s_axi_rdaddrecc_UNCONNECTED;
  wire [15:0]NLW_U0_s_axi_rdata_UNCONNECTED;
  wire [3:0]NLW_U0_s_axi_rid_UNCONNECTED;
  wire [1:0]NLW_U0_s_axi_rresp_UNCONNECTED;

  (* C_ADDRA_WIDTH = "10" *) 
  (* C_ADDRB_WIDTH = "10" *) 
  (* C_ALGORITHM = "1" *) 
  (* C_AXI_ID_WIDTH = "4" *) 
  (* C_AXI_SLAVE_TYPE = "0" *) 
  (* C_AXI_TYPE = "1" *) 
  (* C_BYTE_SIZE = "9" *) 
  (* C_COMMON_CLK = "0" *) 
  (* C_COUNT_18K_BRAM = "1" *) 
  (* C_COUNT_36K_BRAM = "0" *) 
  (* C_CTRL_ECC_ALGO = "NONE" *) 
  (* C_DEFAULT_DATA = "FFFF" *) 
  (* C_DISABLE_WARN_BHV_COLL = "0" *) 
  (* C_DISABLE_WARN_BHV_RANGE = "0" *) 
  (* C_ELABORATION_DIR = "./" *) 
  (* C_ENABLE_32BIT_ADDRESS = "0" *) 
  (* C_EN_DEEPSLEEP_PIN = "0" *) 
  (* C_EN_ECC_PIPE = "0" *) 
  (* C_EN_RDADDRA_CHG = "0" *) 
  (* C_EN_RDADDRB_CHG = "0" *) 
  (* C_EN_SAFETY_CKT = "0" *) 
  (* C_EN_SHUTDOWN_PIN = "0" *) 
  (* C_EN_SLEEP_PIN = "0" *) 
  (* C_EST_POWER_SUMMARY = "Estimated Power for IP     :     1.51805 mW" *) 
  (* C_FAMILY = "artix7" *) 
  (* C_HAS_AXI_ID = "0" *) 
  (* C_HAS_ENA = "1" *) 
  (* C_HAS_ENB = "0" *) 
  (* C_HAS_INJECTERR = "0" *) 
  (* C_HAS_MEM_OUTPUT_REGS_A = "0" *) 
  (* C_HAS_MEM_OUTPUT_REGS_B = "0" *) 
  (* C_HAS_MUX_OUTPUT_REGS_A = "0" *) 
  (* C_HAS_MUX_OUTPUT_REGS_B = "0" *) 
  (* C_HAS_REGCEA = "0" *) 
  (* C_HAS_REGCEB = "0" *) 
  (* C_HAS_RSTA = "0" *) 
  (* C_HAS_RSTB = "0" *) 
  (* C_HAS_SOFTECC_INPUT_REGS_A = "0" *) 
  (* C_HAS_SOFTECC_OUTPUT_REGS_B = "0" *) 
  (* C_INITA_VAL = "0" *) 
  (* C_INITB_VAL = "0" *) 
  (* C_INIT_FILE = "blk_mem_gen_0.mem" *) 
  (* C_INIT_FILE_NAME = "blk_mem_gen_0.mif" *) 
  (* C_INTERFACE_TYPE = "0" *) 
  (* C_LOAD_INIT_FILE = "1" *) 
  (* C_MEM_TYPE = "0" *) 
  (* C_MUX_PIPELINE_STAGES = "0" *) 
  (* C_PRIM_TYPE = "1" *) 
  (* C_READ_DEPTH_A = "1024" *) 
  (* C_READ_DEPTH_B = "1024" *) 
  (* C_READ_LATENCY_A = "1" *) 
  (* C_READ_LATENCY_B = "1" *) 
  (* C_READ_WIDTH_A = "16" *) 
  (* C_READ_WIDTH_B = "16" *) 
  (* C_RSTRAM_A = "0" *) 
  (* C_RSTRAM_B = "0" *) 
  (* C_RST_PRIORITY_A = "CE" *) 
  (* C_RST_PRIORITY_B = "CE" *) 
  (* C_SIM_COLLISION_CHECK = "ALL" *) 
  (* C_USE_BRAM_BLOCK = "0" *) 
  (* C_USE_BYTE_WEA = "0" *) 
  (* C_USE_BYTE_WEB = "0" *) 
  (* C_USE_DEFAULT_DATA = "1" *) 
  (* C_USE_ECC = "0" *) 
  (* C_USE_SOFTECC = "0" *) 
  (* C_USE_URAM = "0" *) 
  (* C_WEA_WIDTH = "1" *) 
  (* C_WEB_WIDTH = "1" *) 
  (* C_WRITE_DEPTH_A = "1024" *) 
  (* C_WRITE_DEPTH_B = "1024" *) 
  (* C_WRITE_MODE_A = "WRITE_FIRST" *) 
  (* C_WRITE_MODE_B = "WRITE_FIRST" *) 
  (* C_WRITE_WIDTH_A = "16" *) 
  (* C_WRITE_WIDTH_B = "16" *) 
  (* C_XDEVICEFAMILY = "artix7" *) 
  (* downgradeipidentifiedwarnings = "yes" *) 
  (* is_du_within_envelope = "true" *) 
  decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_blk_mem_gen_v8_4_12 U0
       (.addra(addra),
        .addrb({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .clka(clka),
        .clkb(1'b0),
        .dbiterr(NLW_U0_dbiterr_UNCONNECTED),
        .deepsleep(1'b0),
        .dina(dina),
        .dinb({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .douta(douta),
        .doutb(NLW_U0_doutb_UNCONNECTED[15:0]),
        .eccpipece(1'b0),
        .ena(ena),
        .enb(1'b0),
        .injectdbiterr(1'b0),
        .injectsbiterr(1'b0),
        .rdaddrecc(NLW_U0_rdaddrecc_UNCONNECTED[9:0]),
        .regcea(1'b1),
        .regceb(1'b1),
        .rsta(1'b0),
        .rsta_busy(NLW_U0_rsta_busy_UNCONNECTED),
        .rstb(1'b0),
        .rstb_busy(NLW_U0_rstb_busy_UNCONNECTED),
        .s_aclk(1'b0),
        .s_aresetn(1'b0),
        .s_axi_araddr({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .s_axi_arburst({1'b0,1'b0}),
        .s_axi_arid({1'b0,1'b0,1'b0,1'b0}),
        .s_axi_arlen({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .s_axi_arready(NLW_U0_s_axi_arready_UNCONNECTED),
        .s_axi_arsize({1'b0,1'b0,1'b0}),
        .s_axi_arvalid(1'b0),
        .s_axi_awaddr({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .s_axi_awburst({1'b0,1'b0}),
        .s_axi_awid({1'b0,1'b0,1'b0,1'b0}),
        .s_axi_awlen({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .s_axi_awready(NLW_U0_s_axi_awready_UNCONNECTED),
        .s_axi_awsize({1'b0,1'b0,1'b0}),
        .s_axi_awvalid(1'b0),
        .s_axi_bid(NLW_U0_s_axi_bid_UNCONNECTED[3:0]),
        .s_axi_bready(1'b0),
        .s_axi_bresp(NLW_U0_s_axi_bresp_UNCONNECTED[1:0]),
        .s_axi_bvalid(NLW_U0_s_axi_bvalid_UNCONNECTED),
        .s_axi_dbiterr(NLW_U0_s_axi_dbiterr_UNCONNECTED),
        .s_axi_injectdbiterr(1'b0),
        .s_axi_injectsbiterr(1'b0),
        .s_axi_rdaddrecc(NLW_U0_s_axi_rdaddrecc_UNCONNECTED[9:0]),
        .s_axi_rdata(NLW_U0_s_axi_rdata_UNCONNECTED[15:0]),
        .s_axi_rid(NLW_U0_s_axi_rid_UNCONNECTED[3:0]),
        .s_axi_rlast(NLW_U0_s_axi_rlast_UNCONNECTED),
        .s_axi_rready(1'b0),
        .s_axi_rresp(NLW_U0_s_axi_rresp_UNCONNECTED[1:0]),
        .s_axi_rvalid(NLW_U0_s_axi_rvalid_UNCONNECTED),
        .s_axi_sbiterr(NLW_U0_s_axi_sbiterr_UNCONNECTED),
        .s_axi_wdata({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .s_axi_wlast(1'b0),
        .s_axi_wready(NLW_U0_s_axi_wready_UNCONNECTED),
        .s_axi_wstrb(1'b0),
        .s_axi_wvalid(1'b0),
        .sbiterr(NLW_U0_sbiterr_UNCONNECTED),
        .shutdown(1'b0),
        .sleep(1'b0),
        .wea(wea),
        .web(1'b0));
endmodule
`pragma protect begin_protected
`pragma protect version = 1
`pragma protect encrypt_agent = "XILINX"
`pragma protect encrypt_agent_info = "Xilinx Encryption Tool 2025.2"
`pragma protect key_keyowner="Synopsys", key_keyname="SNPS-VCS-RSA-2", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=128)
`pragma protect key_block
YqH9kwIC39+qbZg4PSfFsXuB9k9wnuxNryS/CfnEri6Ci9fSC6fsrQ/T/hnt3u/yolbJ8DJa1Qu6
Qnm24A9jLbA+fu3Nsmm6/rM6a4vU6OfVl/gTFd/CiWDutv6Dhn6Lim4uUNPahoOR/A2Yc4Zo2tdI
kMLO9gn9WlH2l3O2oXs=

`pragma protect key_keyowner="Aldec", key_keyname="ALDEC15_001", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
XJYO2VHd/cnMxQd3i7/2qRhl57dl+doEKuhAunQyv3vpGRG/jlNxj8PqrgLoF0HMdqE3qJUVE/oq
kBSapqjVjLDMOrNGQ+Tc6VGsKMZH8FE/TXHQJ/IM5Iuiu2eozEwwVUomF+7cfqn+9OsVsqCONQ1M
g0oRlangiqasJDhhMfnlGGqwAwmgWRGQA6dmhTuua1s8zdvIv540zY6p5au8cAKVhqyyKK7wbxEE
SGuFqX+NYoyRV+rfWCcWM+hJEmnWS8LNAKkd13YE2+17sPYzUdZ23DmTxXK6KlAxKFW27CBySUfg
qdNXp2DSs2KAQYih27pBNMuHfGbM/ATFPWFvxg==

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-VELOCE-RSA", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=128)
`pragma protect key_block
lYoEi/e8HsDTz6N11EDe/B/iitERmeYndlCklmCluwgb0N4W80JUGVlkd7NlRZHRNhxaNBJPkcjC
n61nO0tb17NwsMwjbY5TF8JWRYTNw1JXCFacvQYrdKv4/7QNQEtwVGiCLxFhOA8aHlWMZIrc2fri
VRMVWaEBcPwCGorlVIM=

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-VERIF-SIM-RSA-2", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
QEw9fEsWFbdX0OQLvYs/gl+zyEOW3ak9TdQVaq+0AXXOT3LIqF7wDxJ6ZBnlf9mNbdsUVH5tAz1o
H8u7ihJl1L3THEvugW+TS8hkvVbEA9rKO2vV15KAj4Lla7UdFT/xDfe79RFarlLI7yGrubjgdoRi
QWy//UKsffG7IWNwmoSuppWiWB4ZHJtkunNyIkm70JPGyZF62VxJg1MTT+5LUbZG5vZjjuHZud9w
xJaKv1tFP/x8RVqLU5gPOqGqTW7/nKO2S+450Vo4D9vAmBVVcXpaL1EbSmCvQ+qJmcQKtf9qYFRV
Zko08hbpHjPxstqvTDro01jRzB8592m4xU2TWA==

`pragma protect key_keyowner="Real Intent", key_keyname="RI-RSA-KEY-1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
TC7q853CWBPPJgbRfgDV1lmjUwSAtliljShAyNFg8sfRfwDzchthzoSPH1UCHV++E2JXacEKq1lB
UWsNP92U4Xh0/Gu+6esOI0pJb8I+TRTxyBN1I4cRQEfQHcwfhbSdeH3yX9OV3opLEqYmT37hWU+J
zCawYnxVESI0FtRzEXve9gdEWlrKKckrT/hp4mvxxOjvOkOSQBvy0elgUOqh6mEOZl+JnUbsR+Wm
CoZLE1eefMZy3FnVmyDNPv3JPXi88aLXMyimal0MYFkTiS4XJiGT3eAIMIbksehXY+eYi/KFpZWQ
GHpX+lG3UmiWWLwyPakFwKEHbrBc70AlJ2eV9g==

`pragma protect key_keyowner="Xilinx", key_keyname="xilinxt_2025.1-2029.x", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
j9nmCKgjPWNChPbpSW6EWLrMA6oCG2JGPoum8px09v0PEAh0DRXZi0J8HPzXUsZgOEMcKpA7X54u
YFcDDCLAQ+urha/eSPbQYHQh4yGCursxAQ1C6LEyNQ2wJ0eLlO2bJeAl/gof06zqsYVM2lLJVNv5
wao1k2bmgPdfpfY3c9vPD0fSMuZPS41EoRS0cQhO5GTZnKdjxm6tEUL3GnTjB8ynSCIbCJUsMtAX
4FRHNa52gudx5B5fagR+lXgFhE7e++rWTJELr7SYB+r5Es8qZLTpCH8TrQxEkV0rY/+e4sAjNE2D
gHw8GD7VcUtc15B8y1BbVmh29qc8Nd3V2i/miA==

`pragma protect key_keyowner="Metrics Technologies Inc.", key_keyname="DSim", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
UkCD6I/Vye4qNoNoa3hIexBXG3xyKUJPAHAjIo7UcNVCDXpMQiYEtPDqExZMfiPlJn2nswCYIfIJ
FYWqMCloKSQyyI/7yZ2EtbyWEklb/P5IyZyvGi6hhFUo/JFTb12b4bK0gZPr+bCDdlVQKTx5GVHz
wptdUJO2omSj8axVMPbLRRtVzlJIZ29dTJ2ATXVXAcBxPnFfHRAMnYYKLeeLExX61vQvpqrkLQHm
XG7hpVzJi56gYKAzxa2BLq072OCVpVS70bfWlhlSTVcSlCrUf+EcarEk4FD8+Ih2NCvrqremG6yn
TtcBn8Xr8M/6zhOYvLi6AD6eArDMKA8n+Ccv8A==

`pragma protect key_keyowner="Atrenta", key_keyname="ATR-SG-RSA-1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=384)
`pragma protect key_block
A5y5QVZU8yjPexRVPioSiAGohCHD5DX5FVobuMyhcgQRExLUhPvnnS8HOtxTj/2IapEcz68gFMGG
Hpi+m725u85/om/Vze9pGIW9Mn328Kz2FIg3W5EvGstfGwY+48LiAGAmTR269JS4lJGVYWYOz7Xk
S8cEsFd2m7j8iyKtARJzD90+UdXq/cIIh725jC9i8nbgxB364zddvm1Z/DF3JRw1qFp6GGcuRai1
KNcJ1j8c9wtIgktpsteU3e5+bxHEw8NT3gWXUFYjm00NDq97Jals8Jjktmum2nQxoF7ivPacfEey
gnSF6jRMkTsZObzc30hAhs0CEtc33hZLhPLHSn8pQ0WyvKJLHdd5s2yckgTZtqxC1Sbwe7WEgNXe
ZMX3pIkz+aoXsAL7GBLyVBMVQcyMoF0w8QGAaTe8sqatABwPqXidYRqNROTf62IYcMpV89XYgaTv
EwIn/oni9KOFd2BFVxRZbFGGC4IjvigsTBUijI+Dk6kVnDh240clGcc4

`pragma protect key_keyowner="Cadence Design Systems.", key_keyname="CDS_RSA_KEY_VER_1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
Omtp+lCaqUx7Z4qdFj2zrN8LpCkit2eX4hlMtig+ielGm/x4FSZkpjoFmiqdKFPi2eg0pg09MSai
XyGH68UzAR7Xrj8f1jlIoUmMKp4GcxfdqfTeuu7kWGOJEP6cvgTjSJFj2gawDv7f4yZcltnK2x0L
e4GW/rBTmGvZtKWb2ahjINLxPuh3dDaSaWdb+zVgbtyrI5FrjxBkq+aOxSjyNsqnCx1L0uWbxnkl
88NbXN3dTaECXHNm/fsleayM5hKis7kTv9BFajJMGy+BhQlmIYpE+F5zchnTTFUFJZCz1sX9Fc8e
HcY7irB8mR3ajdzjUZLBQEMktp096Nheq3U75A==

`pragma protect key_keyowner="Synplicity", key_keyname="SYNP15_1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
hpeBLwN9x2ZFDwroYLlUe5GjjDepHik2l0c2s3/6S7JPCRkzQSyt2V1Ad/JewAs/QNp5SXSbYYB4
rQl0My1LDMF3xw43r0g2IbcyHVpPhGp0W5msuQdF67afnsRv90iJYWLMI3QkYGCTWAzl4HrLxFSg
3z8XZRK670IcxznOrlvgHmIKsvubZrBkuc1EynrVb9Nw16QnIx2rc4WgcEXeFf+4i1RoYLDd3gXK
NFCNMdtaRYUThunFP6Z4ViZ5UnDmKq+IMhd31jTaqIlWOBDxPI1+v5RJYxIyTbn4rxlKR2fNbl5/
z4OUjBTd+1GH3I2OXlqmAOvIhpe2Z2HH7nZu/A==

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-PREC-RSA", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
Mt2RhTSUwEIEWeNARbyL+EdfS1UF6nPaL/fKl/7oO2gina93egwCWDLl1fbBtkfaPco0cu4MJ9K3
OraAsyHRlY+MNShmJ1LzAIA1LjZx4y55lu9dlQqSUXR7AW7wVbkg1864mK+hM/1XygU0jvebKNW9
B7xSER+asLO6pxi0mt7uC2PHxLPAYEszFhmnap82TtbDGdQ2qtyekY+ngs+N2fAdsblxVwJruiMl
e6XJ127M8N1mYwhWU2HtRpBOSnnKoHgD9fG51XK/rhk8DxT66QnX9uLPB+H25eDupBJGi1Y5o6x8
hOwZiSUVlBLh7brfzevh7+eRn+7es6wBas0+3w==

`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 76, bytes = 19008)
`pragma protect data_block
pSXDQPdidITPsKdgVW2/3cS/3B7xnckBgUJVLisV48pzNecxJal4sIMDDsq3t1cdo6tdHxOsnmzr
AEF5Zlle3U6yR/hDv/abkW7ybgGSTNE7pucxGxnxurLouDTtsJEMAsFwrB7X45ZF6p1+g0Zt8PcE
OvJ0biLWuVGh+EHAs0BRk8jc6nMjcLE1obSA89CYmadIlS3V34r8NRQM4K0nxrfFmrWIGRUwUiR0
5ZYGwSLtc9VxrJ2JCYI+ld+KTyPczVYq4lb8vudN053b1jbBRHAL1IAk14oGozuSZHcJGY44raHR
pDjv7KKi0Rmu5wkt7bCmXzhWPfA0RoJhHUZqDoN8x84ZL8qStrUH4DzybiohbGgC8ojhepNVs544
/3NhYZY0/QEEN2P3le9LlTKoBsYimP2lHCahzvb/to5pZj1hBfxjLi6vF/z0QUSSGKZgROoh4oGY
+KvvYg0zWojzLRBLhNYKdWRhQdBYffrJprAd5AQS+E5jnlChfSgaeK1uX1PiUX7tDkOGk+AR3xIo
S4zIjql7wq8LDriIIKei9VFzSCk5N4sZUbXOVfM6VSSvH3+d2f5JWQxN4hAeHJEOXYFlamoUIk/4
/nM2u9zzLANSC4gm13oq2+pEDPNzBn6oATUWk0VHcVO5M1YDT2QlQdd/QlpJjJI4cUGts0pMi6pA
kNg/3TrH0F1wnWIjDn1xO3PdaEht1KxdhrZE0hqQEK7oAJw23GxZZhwxTIRKgY79dPCR4Bo6rWd4
npkUqRgjBnq8HKAbg0xfIKr0c4XipC60pdcPci9yIHpBsz/R06ky7sMK8nVtqBpCC3Z8iSqYF+BM
VoIBlxhqXGqCLy+3KN8g9GmUNkYNHY5QiscNdGngXVi1OAPUt8vMyoSVJffbeTDZVk8+W1J46nFb
uTs/rI/ZYCR35hl2rTrmDITpHqqZzxXuSyMjiTJleIiV6Sr5QFbBEQaWUgloXlXbANCx32DJ5RW3
9/lyBaDyKTHze9zo++y9Qdki0TMXekz3c6d8G8+XaispSIcriJERFV9jiefdw+FElrX8T6LcDSfm
G0Z1QrKloogSzpZNxgOSwRYXw0rjix7Na2e21loHfccJpPxmQLIbdyChBqaIevkrUalfP3meBAWf
rOqn0ipb/F5YuG7w3Q+ak/3g2gcc+VU907KOuFHVUZdMCJoUF4yx6YjKVYi5Jt4LL0J5tHykjhD7
CrcE2Kzr98wNT9F1t4Um5qqweVw/9vKFAb5dVaBCh14qE8E/NJSGrvQcZnBJvsQWsit5EFCYRj83
+5ecL7aLj18NL80EneoaEIw59YRKHZj0DuyNHhNU0u/TLQAeCydphANne8ZfOjxR/a0yKCHlj/5m
ed+XeiLSgllo9QXf0rYmk+7wngKGnR1Bg7S3jAeWQJmGKSc6ARu4bZgncUZKsG7BvdGMzmDxZaEF
hg/00czzmGwo15gfxgQWoCi36/WJEuzJK0cz674ugjKK5miZM4am3nv/y/2LRFKnWPjcmfivH++d
A3BhG95k/Ia/giKH/hcXHzp+2IZbBvKuejwIvcgZiuX3Dl2/WPgoEercEkW8b5c9cWBgavYaYfu8
WDP8q/LPFQa6AXBqDozkspCEOP/b13uQrnzxV7QflQJtEt39bstowgpcuWkAY7i43b6bPtzo09AM
TrUd0UCrxjjw7M/6V2T+xGSeKvoBAjRAcnKWg+8GMS8E8DFEvVobnvrVhPxUxR+ipht88zHraO08
X5g3W3aGs8N/ofqY1KTyEPOvRoIsGfIkadkHHJFMCa6uFdycHNjMli5QYvQ9n/1Ckp5HmbxwzNpf
nelO9zAa68A0pEnCYlRp1mifvHSdXbW6WPCwVVYQfu8qSPZIslfdnxQMe0HswaQhe9h7AZBv5gVO
/rEZiQpb5JguE1UxpdTju7NwyJTnsSdAzpzn7zn/dYhAWUyVfel90qQWYrOoyAKz6AS3S2t7PE+M
MmKwqOpmOZpVa7hNFN1WksxV5avo00ZBmhHvrPeyRZ/4tofCBIdyPCCqcPVYGz/Rb0ssXAnAyUHQ
EB6jhNQkI9hWMN48ZP0xz2lMWnSJrZjkK1RGx5XkceBHHe9dman1MBzQKAnA8zSBM+QIfTQ6tUIv
F9zIcrvLUFP/7wuYwMPhjfAnaJZMEo6m+anboDfAEePCSkhYObaifVgtjuSxytRLlum0hykVZQ2z
p5UMxuuqDOmEOk32gWV2LOwPtGXmJODSyWQZDiztuL/A8Uu3Zsb1N0WryGodautP/+cKFMWC7EM3
fbrIdc/tKjx/ADtVih7Jq5PtELzLqsf/HfWaf857be61uKb1llD1IFL/C6FtYBAQXydHQjHwXsPZ
Wx0aax2gz7llAT8rcidEcUU2b14BofLbBqPKhk51nV4+iusCVU3aukzNjgMtQLQEBIFz7Vf8Qhhn
5cjM+iv9juyE8YptT+GG3upD1SLLfHNC4ya9/qD5fvquHTK/GEKrf8dwX7EEmKPTe3Q429KhcBkU
lwvSQuFigRnczd65y5guKPdoJ5swhVqZ3d/fBbu1J0FBaViDHDVLkPh0Olir7DCstaIpGGrs2a9Z
fPatWnxkAwT2h3oXGgaYlu15BAtcFXvtTUlZQZZwvrZKjgnDuC2rIdc/s30+RiWYY6VDEHECvFE2
tuhkh9cYHGtdQDOWSpAut+n9QT039pP67JM5EUfKX3zrkjmSfvIfdiFCQl//hmUL6AL58m9WeYs7
mtwyvqVG8YUgz0+pBLiCmszj6lwE8glsL+tw65TlEhBHb9ziFiHjruejLVmEXXG2Eo4cOb2S+11i
V5wueAFi4u25IO3gZdzfBXAqwm7qH89t+t198mDuunG9C7a1zcTkc9O3nUOti1pbwSXp9qfuDxdU
XGT4hOkn7jp4RjVRE5vPyl5vihD1W2QcqhJ8R6FUZgiEq6vSbN5hlQmztFEa38uYnXTip3tZ3iAq
yuajqILdPOVUvq8v1q5sRLVyRMhVrGJYERstmSWhw84Msd2+u2OdM9+N9rQhyQ/oRm4tZ8p6LxY+
LZwnKNsaxzbLzq9EWm3Vh3PWUEl1puTfltU+gfSnZoY/vcj2Fj+hf+HrF3czAzZ7kywj9C2tP9Wo
kVlF1gn3PytDN4h3B5IzedtOKpTfd4fYzk4o3XgPwOhO8+IlGOJvQxt9oyZNkRaxVcS489oW8L+g
B4nxjgcXJK+RogDzBZQb1GKZGrzX6cQjp95o3CuQXrKfYo+GyoSVu/PUV47NWbD87Syi+/Mseecn
oFA12/MPhodZJ4eF8t5yGOqw6lSC1fx0mPt+2KgYTbQV3w+bUw8AaniWB5E3D+WV7rZ+sulJv8g0
PvdRqwYK7fFIkSq8+s/MOi4GuaVeUTmuhvcZwoG+iNHW7ONQDKiurFYi7L2NT+3w6GPCjg2WrZBW
+Lwl1om+CJGQ/i6z6cXYBhbyqWV3bHbtekG4TKjJcNh3Ksag2dDdIZGzLmwbBKAEr0gyvSt61TUh
zlMJ9IeTLkF0PfdTNDmYTFS1uwsRwhKX9AmPupHP4mGVcTGmtxwzAmBscybsMTtsmV0CquWCdzEl
/NNzZfrzRIbqNG6aQB/hkHr3M70PnnRVKAZbMfiR4Kva4zU+eEey8W6w60gizHWnd2aAA5AvcZSE
riPqmyqugqVny5jiN3/7cF7I6BTntmUmzNAyO3tsKHHS7Nx7yjPJ4NOPim+k/DsK8AB7OQAzSe3/
yp2mgaHwPZtBBcG3zJv7wDgEfBircGDEIyFMaZ9VbFCv3mJm8H5wwzAtupma0cq6g79IEaHBsg0R
qn2VWCC+JxRFYw6mK4TcmreqSYMuh9F9QkzKddd06kTQG3yWfLqcxqqqV29bJuQxxSKpxC1iqAM7
qFnhUrz3aKbjYpLeSIKEhU/3f8DOrCzxYs5+L9FyjMJI9DX05heHFbs6QQataAiqFLt3QkKhr/7W
QhBAGUQPovbbS5GCjpFqSKWp2btouYkU4MDLpmbo1iUEDp2F7z4sW3q6ULe4OTZb6cYv5xCRfQNA
+6WBBtd9NxMU0bbGRAtdbbA8J3QBP/7hziZ+zvg4oafridrV/DiGOnJDFHE75n4BKW5WS6bWvtgw
qmLtnxQkXdaxCN+cXMfVZA0vZcNWXH2YbzADFdJmHkp99PaqMmvtyoPyjqn+lNEamQIHwgjeiUUB
O8g6CziUxNEHg6aYF6Im1uPJmlFgWCl4EUFniuy9ZbUkjoX8vEpt1dH5oiVdatD2CgrT9usDd5Wu
JS7aBR/N1ilqMk+BVn1GzzyQjb4SiKbaE9lh0dVN6q+pXgXpHcje2Lltq1OmgDuWZ+s+RiQjyn+y
i3WBCt6k6nuWu7YDlptLeDYoNO0ffRWAYgVsR/8CghxcVYeYjbo9Z4d4DQqquFTH8MGKIMSj2c/p
cJ78K/wSmYSQB0JgQAmyiVYzG/TxE1+9LyZ2EuaT7BmZKIoV0ZCepYfB+9Qz9XzI6Ff73inmXIQs
msBrqRj1ORutCGzcqkkNh7kRphr9NDNrZYrltIckhhhW/YWPzurlwAiXIhL4FSyr8sUyw1MuEmQo
PmqqXpCxX3xydYMd6lm6nM5K3sXox0NMMLwkMvCvz78nCGE1/RigZIXQM/dNmKZyWiHYNKWD9g89
/tYAWyms5KzGMQhGbISOccE2Grv1eBtKvqj1m80S1ITWnOLNB9vJZt7ikBy3p5uQ21J4L/ooZKBn
+s1WE1GNWIl/y/w+Rcfl2/uVl8Rn1Ls0wbsuAtW/VoM7/NNpelBNi3f0ke30u84+QB+b7VIQXBwT
7m4ZhUG3kjbpDhcqO72ZiVPsmVKl8tKkIiaukAqCL6qvooj6jOtsx6HjNKzsgeZYGNDUW0M6Yjve
edxH3E/Q1PEzBtOgbRrsKGT+q1HXwB2BayRshsNYYfVeUI8pEe4CCytAW9dKgnI+mWcfcRbSYimT
MHKyKMZNi9dapbf+Gfk+xvOBqiPUYuqy7dJzjXlvFkZZxAKzJB7Gql8cALJtSIFgu4zQHW6et/Xz
SEOXp2uaAMeGODQ22baEq7N7oKuzIlgyO/DEK/cSJ2DkSkxxftm0XnCBDuBb94j30IS+9wFt9bmi
TOpW/kQxGiRlBSrKDFFyBWzEA5FeLe7vL0RytIruB0oVWCtXggqOLYKavgBKSN3slyRaX+oSF0LJ
DGF57bVJEq8Rxv48JteGs30C0VzSB20vAL4c659lHcuyZh+LBmEujCfkVjqQocEp3CDINkCKBK1F
qHpF9aRg/+aw3Gx95wJmqrc5IpbU14aDpdNKpyTcs8hCa2nHaH49hanwBKTiIYnjxQqrtcfRpTh+
qF3JJFqKKyhqZuGuhnoXpwy4+FUuDoQssokL7aCEf8eubWzhBtbvK6Sv/EtBg1GwVCUWp13c+OjL
IDIBJyBr4VVuM7saH5Yr4PUcfhz9noW1HuhOk5jZxt9Uske/UO3nZUgII/XM0Lh3dJaKNX4mC/Uu
eG65NR504JWol0xM3A+vLxarqCOG5694pbq+A9J2kXHAlTOXebKGVJcfMIpVSF9mOpqxwMHleyIR
Mr416uY5+kNyJfY7Y16FFiJ9HRn5va0Jhy7dXBBeVAyXcgVOIVU710QzUK1zA4iyZXAF372MEB5/
MctpauNKf3QXDxQ3g7V9vLZlREVubJdXdsd+PyIfu7LCSmV+xyXd+T6a11yeVffRH0sm/wrnKbna
xV4AmP1VHWF2X0M1eg94lbe6NneYSuFHv/LzpRnHeOIBq4i3d71S32gKf0eHUbzlMl6syOnE4IlR
CJa6UDa4Oo8WLXIxVzjjs3/VH/iM9yLktvlUCjiKxqNpMWyor3H6tqqIk2DHsEPFVSI11s1qOleC
lwz/0HnEUYeCXIodmRbVNKBUfgCtsPI0c5DH/RZ8Pk+wy4lqC4VonEJWvi9ZC9hRPvodRnOpmS2+
gAT43u3nqovcBwzdJCqNlqCQ5pF3/iZNtRDiBEFlP97XhH0oNOYwVS9KPv3D9yyqvkbPramN9J7C
pp3QLqnCdGD7CESkg/jf/8AGlCSaSmqUrB4ZIzxD5aMJ8mUJ4cXdav07mLimxMF2UkI5KIUDt9kE
2UvsIJatPyBe/Y0FgrOjadTdZZH3CqNJGouvQ0PkpT1QSi7zuHMVJNCtt0ZqSn4wmJkdUa+7cLF4
iMiNgdqBMO/E4NmMzvoZeNPaRAoUdOhC8Pjw/gwiB2ydijeybjF2/Mjk5xP9f5uIeL5aXV/ehg4Y
MVXnp6EmmTUwxNb0/2rmGjhXpjzlm3Ro2GAJGmw089bRhfTgeAW4B+2OjhHIoFiAx4mumgKvdKyP
jgGSEPwpfr/AEGU8SD44NJfpatDH2gTOFp1mw/5WazXRnF75cCiasrbxiBFlaGCKhmKRA5pb/XTC
V6Zo8P+N9nRv859ADDNYoVlWK9t34RhPsIJvYi7ZMYAiTUdFpXy6ZlF3DMSO97NxPZj5ET7dr+bO
Vjukkoc9Xsx3R1SVEMnw+SEw3Cv21pOjL+hrbEtXfbybepWVK/HG7ByfY6pjaVf7SE65IhEK0MiS
9bPQUAlcAquAtvtOS+6HRUE77WeMt6+vW3yQ9PVYnG9gtGdWvSFNyyRlp0NUb3/nfDqIcATfmZUj
qAnlaeIZBK4vAlahsVkxdXJDuXjRXkT4PuUvu+TQq7UCTHG/9/x7gHiSypScJ4zC0k6ntUR6l7F9
M2zy7kR9TABhVqNDD1qUd2LQToFwNJ39bpI/AljxvecOe2MWhxJte/ecjfNlTBpRZj+QrBdv0lEc
kFiIUzuaz6MB5+Y0dvCuq5iJnoz3lykXr8Byp3VmyCsRcufaDYw6ZM19Zuy6kPXJShHEkzhxWtbS
oGkXn613KxJZa9NlMd2DbI7AB2DhzskHLvPxm6q2DoaBWXZe5BqkY00yBslcJ5M80gg7JJE8KH+8
YqE04/M6b63gEhpexMkwxCcYz3451JyhjcH+3uLuegsjjasoontRmJ4B/dfyPZP3TWIgmp21uJlz
FahoMsNn8hqsi0KtobmfIRu9HZ0X8LiJkhXkzWRpDo9UJ+uh8rFDniyfrFyuy94c+9MxK0HFIHED
bZKnFIckxrpx9LeKKqe/UcvavrlnrMheJvvyd7h2Yl0dYFr+ZajUOV6yk/vHaMPOdwiJuIM/jFVH
Ws+XETk/Jexno2gptdSKA4xVVDz7ltiexmgfg4boZWZHgpNDfAUBkQWLICJEbQqKxPDzE6m4tufr
QrLbLzZZL5zoaqcv1SfDQD5TUAbnxVzxt5dpOLJDZ2ybM9ClRSe/KTgUQ27O+NdswYVRhmHZSdmH
KFtPNzqS7J/+ieaciW4oC3Vr+TvLtH6I0NH2r7oLM9VFwXcxWZ6ErbjWlf1DZ4yNVDgyx89XbQX8
hq7CaMI95lKa0qhEBXJCDhCsMX35u/v7fAbLvmq+XQ31NQqvtAYfSLCRc2CCwroBN1JkDiQ3oQqs
dcYhpUcUDzxz/nVnN8fwUDczfmglevD7ug95R1TupNq6yYhjtGiW3RTtsPkBWSdwzFrhqB+mjc1u
gumucbQc3FzUbcXGsVb3xNQJbisYwepObv/8ScKgjT8chCUpiXT+OiqRYs6Gp/5lGZoBjqMuMpN4
1Z+WmdfK0hv7IVj4SG1nJlMsMQwR5oIxdKbWj4VDIgqE6EepDmgLlzc35VsXy4wGu7fc37iMHzox
mD1zQYrZf/fWzy6u2tMsxVUI0Uq/poPAblSCSIof1uXXUrl8IwAj00P4EB4/cJlQrNBwUDJBvZH0
XFW4dnQ59fZI8qqPM/fZaZx1PE5TWiSLIqP+jJdFbaMtyDsiybuGRpeYO0pug81oRDahfiOoKV4+
YF7AuKZcz/xryUiYTaSAGQyT2H0iMG223AV7q6TfB0rp+I5Hq2OHxUM1Ee+AcJRzTwKPsM/5ojwV
z48+GfeKTXciHrktuvxekvjXnzhgC+weR2SXrheb5o2z3fxFwttvjxzkEqmBhrSsKO21pU0P6LQW
uzZWTR0THdh7aZM935Ho+pVn35JusIWh5q+ZpM175zSUD8RlCKWW7OQK7suxOiQR5p7nRnsbqSM2
JYrVvCRYURzFaUewaP0j5mKm+ajQKq4PxxCYQrxJQqa1aVOhNeH4skkQQOQPQmtD/nYz8oshFbUS
pkzH8FcqEt0ix5tWZYVaR1mxhiALvVm9B9/pj30dW85OxdluS6JvuMvY83zCEhCJeta3H56AHwUF
HtuO7c/3rfmBO/qStl317q8ji3gSjiedxw3hRq7ksXRTd2DenXyEC1Sx0e6r5jd3jsE+iLe/z31H
RgvKMkZVSG+JzPuGU8z9xBq0cA88/StpURkaAfGjYbG44OnG2Xi2m0zUA8NGD3yXTsJo02LqPKyv
o5hd+tSIXLYsX0Oq15GRp2Y/IuRFCRESwWJ4h0pVQo111/rk4r1StdXf6tmiSfwHNteaVO20QVxH
wpfejiyvrcPSRRVotZ3QqT80pm/IDW6ZphlTH/EJ7vVEqJiHEQMlYvXR+dUybkBaCJK3kLOF+4ou
S88ZW0FiHckg5GMvHeYmh/xxK6Oo7SUZ56Iikr9F4iujx+LJ8TFtOvPcDSU/vbv6A3JsLXti2y4M
rzvbg/h1ay8mErmjm6bu8hmxUwzfCx2y8n8cL1iQExzmpTPR9n8UAlXO+GGTUDUy/Hy0p31oABKT
KHAg0ZJ64WnuZersb5jZ3F73jVs8aAzzKp0e7guu9o28jT+pfyhCAbIbfJw3WoJ1QLH8d2ks0bm5
79uehsujX/wNI8fPAUZb0nRjuY8C2DmvA2lrPmcMIqItQluELfg3ELGi8pFY1MjIpJFliwuYgGFD
bo4ggLTOfYE0T017XtyclNTyq1p89ZgQf11aRWMxUG8DYHmoBSSMbXOznzMvharDczguL/uR319l
CEDwrsHpC5nBAC3AmfjVCjaPFchNyqpaM6FlgI2abCrP0Oni8adMI4DSTY96cTh6ksAE09xgDDr+
ti0kYZFyHUPK2W0a6C9fq9vjPrU378AzUmyKulV0Ohcoq8XJEJyINf4Q27e9kVie0EHALRK/Rp/I
tNrQb2Jr+UWezN12tAZLGp2ORzdRxWhkHLHxFUtcZ5fGn9MxeIp/uE6P5U5axap+ADetePJu5L1p
ABvCLjM4e0vfR61c/zs6WgvonqE93goURq488gZbQC/2mZW+Gea/qaSPntD5U1t1bn4cf+WUUpvP
A1vTNGEdQ1OBPNi82fQ77MIq0WAlgDLO3Ntqf7Dzr+A4lQouktnoaO7Xhc1pEhdthZUA1jx7ilhd
VFoDpVvfFDWo9CvHBPduHTGkpdkI0kzgro24+J7l4iMWa+6TK50dC26pG8LxcYLPc4SUKOQMnOIw
eIm5TyXz3oWSYXAjkRezRMVXjGkNykUrIff1AuSVI+UcCYok7+wrgTOP/mTJC47067XkqV6iocJs
cjrqhpPOhoDZHumv64IPt6zUnFROcfNTUoAdOgQPG1zCThnFhHVcFmYTlTYuW9eZmLOpL+GlhDV2
gUFyb6B1UBlYmpDjnfxk35iIkn+Zub1PtQYDstUgptWN5ZDF0uUhjnBroVFpjmUWwDB5uci/zWan
w6YjlOemGRXofne9BcYBru+1JrHgS9SMuO8HV0en2HoRFLE0WrKDjUyX6i/RKjyuB6zjdXFpI6Mp
mCKN17dcWUALfm+8fk98+WvdYQI8Qc489px2LJIhzf5N9t0gryssypwuaIwgrut36I1uuT4S3uxu
XMhcA7mng7kNnJ/wzj6W6axfnJXZfXFuXPpQw4WDUcDPxbzRg/Y5syr3o7wHeVRRvNFBqygmKj1O
28K8wUP1K+bQtwtjcFl+wli2fntCu38xp1kNOmRVNN9E5Z9ePkMjz3Gmd/ZKeMPUaLGVZFB29IQW
2gs34He6k7YfH2sVMyyGdaSmd+M4UNtDKG3x0qN0xrqSYaPqKaHzo5WVn2H2xOAsfov/SJcvMjbx
QC2XBgEE5iDluNBUQjXuSk6H/Kvt2uS5hSL8hKd/SvQKPu0qlvKaQPA10PwZPRh5Zmr3Z8Gnd6eD
YApg5GRQdawAoNoZciBu/H4XspV7Odz98UeAbuJ08CaWgZqDtUiLRNMOtKHy8JOUockEpITCO5T+
3ubcE+Eirbhg66UCeqDuOv6m79CqaQvlj4+I2j3RdM+ErxBbUdqiC83MhI0Dxn/PUFmhn0lhm3yn
3sDlshoQX8vg4qcCPAw3NAHVZDU/bHA/9dgSSV2jwwEWe2RQXDiEimnad3/i86mCvOwppY2QZxBC
dIYGEg2yP18ADPg/suJqxfAAr24UzeGsUUhBkbWQJ+6wkKMOacJiLRHpKVzsiuREBu6SAZMWFN3I
dlinvjkyaCAXKaX2v/GWQ7tuUwrHEI5H1amj5UnpNoFjQO/90sGNjX2EhFqkvqqfo58DIYEgjAQs
ias0gXVjNhSt6fAau6bVjm6vWRQGIIkhvR+hqaqu+ADhJ+uAw5lhHM0J00RxcDchA5PswsBcVGEb
/mqsj1vA609Q4lxk1/1128J8WfW7ws1Wwkoj9WC/qqnjx9T7S8Ml2sHcKxRUx4/VMxJhPSOrnwnO
LgVYuXVPvtR+wGJ37N8JU1lylYI8WVQqR87ayPPrQSHvb5XKJ6Ma1NXnier2A5vGimVQGsrDETdJ
hH6uG00sZYWv+GDynDDuYwh+wiNqkhltg9rZEM3TUyaj4dx0VJ21tXD++40khKO12nlx4rt02pce
Bn9pD/Vhk4/4tWAkADF2kt45a4Mt4peVh1dTpmAb+mk0zzzsAnU9gm+r8DHq+p3S7dWd1m/rBgCi
qmYYR7xMOoFIQhFxbaiDCqvFi8yBKsijgjnh9nZ426XoKDg2A+jV1cGEc3OuPHITHC0R4N2QgWcB
trq4H5x+jqZsYa3aBf3lX4WKlTjl6ieZOQcPrCoATmnXsWtPCIyD1L0vYCyt3Ht41Ahm8UvccM2T
dNjxE58klMaiUXQfeHo/X2fwjPpDHttRxyauL6OteadeKCkklz6Yi4u6100n/g4x8bXYYRK5J8G+
jBi5g7jz7YuTMA8E5ykUXBESR68X+LLEV3WKO6+WNxlVPzLUxUveInD3LYikzq7LL1QIxuGkIsnL
70JMjU6PflSQ0gOum7/ZkXdHdV3SDn/pLww+LM3x0O13uydk28JZso/78CbI0GbNJfgXBLTpgyyT
khvyHCwMuPv3w0wgl+sORsU04UD+SLxPw/nqDnG/zznIjUtoBxTm5n+Dszs+/sXVhwvRdzQTBd57
5XQA8f3sadDgupCFvTbCbQevNW14iPlqEHKOO721EkJwbfmgn3Y6HXb+wRzraVaK50mkAPVaBNaL
gqUax0YKCKP4Y2+Q0qP7tOZQtDQgrfMkThnh1vUNGYlXSASaCrngqD/dZPtghQFiz07hrjAdB1ut
uS5EdoEIoV2IiPdSs+fNRaRAkemS2hhfm5213shQ6AuUG8hLIO2Y6y2dk0LO6o1VkDeV6GxFuxn9
kJjIp9dURM/miyVud3YMIOZMueMHA/s2X++2lEcyBKPkIbWKIrZzmynkjVP5Yfsj2QyZZAaI+khd
k+7N7n+ZG93nD6qnREO/78Z6hCjaheIP0gqqGWjazIw6LvFQ3xzFM3KDLM9+X0Bevaooy+J84D4Q
8lHFQblU9ZAMunNfw2eVB2tvj6dLYx28PlnaIJT/509mSo05m2VN3s4+l0JupnalMZ5fRyp7nJ0g
PsYxvVQLBUK3NEfSHN5sEFeHBL9UuIum47D5JbIZNp6Mu7AaooyApegoxgDYR4/913y4QYI0UpKF
OhdxpC57/2r2BOpTmTvCcDAWY4zykkFGgOgiVe+fboo7x3lAEyAvRolVPSotitbn+F2n84jNSngw
qJ0CajvArRsTZ5PDrGOoT3BExwlDYwesj+H5/Vli9Se8x6Npm8e7AgpXVzBKAdZYje2X12nxdZWS
qx8fSltrsYjqqounJuiiNvCols5FgQTeW6iNgF8lpToYSEO3mfUKs3aXRMRsOsUVMDbqhOEYZ754
F4SWejjHt1wP808no/R071c/1FRYvFpBRQRdWUO5ypNGjGKtE+Z4uHTsdQUm3YRvO1mOMB4peG8m
eXW9W4FI2zGqEwXIio3I+WuC+uiFaAvovb5S/55BqIgHZmLk6nOSCK2TUKk6UmAtFXfBFpfmFPV6
Y6JCyg930kdjdF9bUk/G9cnHGWaF27mGABtmWCqHlDa2RIUvA7uLvSVlkqzmYVRHZIiOIpSs1MAh
123YyzEHq7gomovwH4CO2zCg14LzePxBl7H6SstAByBPRzx3igeyuLZg7+ff7pIjeTiD2uj6WGS/
rRN6+SQXqcLN2oTG1tspApFhO+kCGHJHZZHT5ExovicuqULpErqV98N6pw83AVwyGWoBs30rt88L
lLRlJ2odnoNSjy4VG3idG65ZxyUeyO2D4Bz+kiRHa0gobi7ejPJ6mCYb/tuNtEqKusxV4tz+ahRj
YD4JEdF27yyJecxdB05dtBlEpekAa0YwD5ocxNeoEK+YkfvTkfceNtog01AQkQCvIGAqTqr1SxrQ
CNodmvRy/YIJde+XyWRNSNfwY4RinCMbs/cvq5ZJHE/UYdU6qH43z0ujrsy8+Ac727opNPTmlTGM
l6tNUqh5YJIpeaVu1QNCDnWb0XbLU3S6r4BDJwqVFSZVSadyj4MD106PebfCG4OO7XvM1vNpprml
X4SZVfbEwoe//XObhF36yL5b9Q2YK47jst7OTts656RLIWYMjFmNGb+1FmBd5dPqELoxkQ9OD0WI
7ePbLMmZkW400S5w9vDE1N5BjdRq9GjXyiimD+dBEwa6rtCoaNTQ9uNyxZ2O90l4c15QenDhvsEi
xx8QLlORMGnHqkS5PrJkvaJrgWgvvAWNI/Y6xhsh8sF0OwmkHThbdSduxxkgpauiFUcEMoarPSLL
t2+UN+8WxWsG/7IYqv+CbCWlDUPqTZM8Kxj8c/1M0VbXXI3Nw1ncc+0UxgTLEESx3fthk8+G5Grp
mu+Un1vyoiSXbECK7RPZCvQGZeLwVZf76blG1tIAUPuvUPyRRtY6pNhgkMiiUUiGq3VCtyXjYOiG
l6OItsFaDRfe6p+kZSMVc16fKxRG0Xa9rcC+y9tX4dUPG405rYsLt3Lyh9SfYVUHGHUsXX0yGl9B
qM1hiIPPfNKgaCLkc9oB/54JqGKjf9eFdCBkRbEHjjsnMyi/pUF9FxViDo2bwpq3CdUH/nAU84zg
Mv6IBN7jAbI3yWQT6L2pXaMHojB7zx4onHf0yl0pHnmxqfplbXVK1HlhdF/Q0I+S5KJtZYbpfDsT
HNztpZGj/SH+vcgf0xn2AtIAD5c9T8mhp30AwaO8u13E0inxWnBjsEWnEOE8C3HfKcWYNymRRMUm
JnalvQTyJT3x42BV2CBFQyu+xUoTZ/Ma/WmpNiCL1nu3IX4x/bWCqMe3jrH8ZmadhJEhGYyozvzF
KSF1rk2sy9+hJbDtr4/pYy/G26E6gOO9rrNvgmirH5h0BVoK+Mf7BnkE3EhX79F5X79h4xufjdYe
YjdjfdWOyp50/khSmaAwbfmSIyoypUwqDFXTS4l7keM2bk1pLCslki3pLYZJm2bUjxKaxiynqjR1
tX8kMT4w8x+6YFLLAQhyazwzbKCXOu3OzT5FrN+RYqugyXjPgBSgtLIPEe/r6zgRyuljWj4QxqWr
2vRNawHLX2ykqnRnMKeCf+e4rs9XcF+6EmpQ5rUvwy292Ho/7W+jdaCJym4eEGi9VdJjdzsFe8zb
wF2hRqq4L/ZYovuyFyTlm3CVeFbq75fyIsb8xPlGwj1h4wSB9S+hO5qnidRGunXrKBTZ/6ErVI3z
DBgXW4+e8V9aIBmD96w8fjzBHbmNecMAkfVqUiBOb6fpBsjVFy267wZEwipG5nYdmEHVCmkRvhpw
R3eTPSEfeq6gkdyL4Gl7uETgrJaIfispC5c1kgvbOxL82gUgsM7Lgs7RO12mrtx4hu3t8oj9hIHp
pyJd30NistKybCCG7kHY6mxbiK07WuTPHvLD0vBDG+kR9/euRYkPq5OgbXXxxf6rwp82kyzeHakx
60sIXQIyfdtKHzJ2zyR1s4erAdmwS3SmxrON+8N/yp3Z0xJRCTFeyIltx55BEw+Y/9ZbeOfb+Q5C
bWX0fs8G2lXyzdzmZbUpcYVEzg6pO5LR0a1Ory2MQKZ3ZxTHhOU+iOCm57HPJVMuana5iKxp5ESe
zwY2aUqv5HMtqyJCbOcwXs+BCfzr0mvlS++qDo3X/669BRx5tgwI3pebqS9V7XUd+opqZ3wg5ea9
pZPIMyDXnmfBQbR3dHKLZIFIWNCyxBLT8u4IBR7utQC/hrOYlSyBxV8/HWnh7CaptKWCf3oRaOs0
oc3i5GrEcwDB2HDHb5I2bT9/G7KOd2whHD4vgv9IX7yQqEnaHh6qAwJfnXZB82zlRBARtIYDgS9K
1/hmH7ahJw7Sp9bIvqUbpHkZGEmqc9KakI+vOaejCT7g7QvbIaCO2cwTmdXN0AXsa4fcb54O87/Y
+S7Zfvfsr9AwcQ0Ftk6qeWRph84sae93V8HQgVNwMN8VxVYrPamMpoyCCDFuTcaxEFvIt6us3AHq
IhvIeZk3rgjYF2ICFv2Wlhe4dThFlHnMi+wUFo1UrBiuDbx/M0wRAU8M/2Haydy0c2RdBrj1oKCM
YiN3gltJ9dvJjYDINLIWPesbxi3hE7EvyupP7yO0Iaw6nWbafjYJAAr1fwepRklX/yH00fFw1gmE
vMc9MOXIK/QitNetNy5dBk9RHzac5rK1dvqmW7Qq6/xAcHQ9lnJLgXe58bQZSkq3fw3EwiC/PAzA
4pYEd1ph4jPUzYOpTr2kpP5ba0tyrCM8IDc3NtNUgKUCzWaAI8WoKS0VXE6OWLXkLu2/R/JEfha5
m27OJ6SC7SGUZANJykrXLWcJxCRH2vFjv6fc+qV8fANxFBJoap8OmTKqD7Nff80IM5j282qIdm7W
aZUo5u/ro3t/2femDg/3o3UVJghAyxeeWCKSx1mgAZIpfEwCkNKQcaguxjayapp7UvIMg3eP3ZPn
E+OSNJ+eENWRj0wvFXyphSt8gIM9HCTPBHx0T6wc0H40QGMp14xYD3w+RH9Z7mnphNBRw8z89ISp
maP4xEf+SbNtxtMRiD9DM7LK9Urdvn3fmePgbPBnAVbeBUPayhC0kogSDSLwQRpsDMRqpgR3l1s0
Ry7toUygNznsmliilrZ9NtxAQ+N/UxFtaWyJGNoFP2oGQzHNYi41Yj0BfdNMjErBULTOmXXiB+n8
QPn9FVHrFcH1huI1O4d9X5DvKflSsVKzOMPm+UHU6jhXFzCGNvye0LzNFtvtQrz7EGEWiZn+l0qP
Wni6Zy4yNCwNSgubeMFCdWuayS6tDOnZUcDyY8aUhcEiShRd6WFuu8tnNLpRJF8MiY6M3IYYVbwp
PIlAtaMwLFs3ub5HKw8F3qeyXH7UE59uQh7+4lX3hhJwaXa2DCwJ6DmABTU/9AhjfdG8PHItlEPR
wO1TMyVnuuJMndf5GBNOCAMA+mITFspRl+mrU0RL5xTjwzm19Ca99mNxOlfO404EHbyq4l21W6NS
yNdfEykP/EW3bLOdpkp25tfvuB1l/9QQzX/68ktd9ChW0LviD/1JmDebXp5w488cMfkWnjvs/bKm
uB+1mgCBtnnUA0nEJqpsVwndXXRPRxycRjX4SCqQ2ZbHaMZh+p2FRha0xGCI1xkLHgaM+8Uc9iVs
RzYHhmgLIqC8JjhJGwKdeNEmBb/bOQ5BwaUnhl60sh3VP5hCeh60zdQ94/8gd8n//ELmZCxsyy3B
2NQvPxVdhLWqjtKChOodS4IniqVZiA/Cpl3MqTaSCDJjSEcSzOsS8PS7XsdTFqjtx3JP9ZvaJ0i0
88HReeH5Sa+KVRypnIZ1fGblVy1J1UcrQL3Xq7blC8/aYkb4gm9XUVOeBIfeOZrFq1lHp9fSh1iv
SWVnXJwZMXNzvhcmgW5owI5l5sG4EpVpQzISJXwCzTRLqn6aaTrjnD/ZiPbBgAcHIhfw1YZEf+qN
aO/5nSuwg2PhD7ST5ooJoCsnPknIfc9oyFVQBvSu2gsGhFyAnD/5iEgpN9j6ToFCPc+CHXK5WXMF
IzEaqO84w0emSTInMteTsuTP3+BvL4PAgWKW8x47Huz5z3ZYquoBW3b83IdJMSyRuB+zRIPaHvl5
F0bnWy0bH5019Q03ktGMS+3MPolAYUv89muC3JD+kd8HW8idbioKYOJHjqDw30TJ7PFcJ5OnPLcw
S54TCNIPyQd3PZFzSYDl5RkRoFUIsnPUKu1XvwpgGwtloN1XuZ133K+seF/Zw4uoRmOie191uXeW
ARcuBZxqOjYv9kSCFBCG2eUNogC2E8DkaPzYD9m9TwtSosopr8wOHCmM/K1d14f6iJok1823ruaP
UDIpNO7n3zm4Z9qUXiJHsYdTcYM2iZHxaiDOUgCYqU89pEMeJ9Y8glrMFvaB3qLFx0E4zhLlL4pk
zKcq7tbhFqpux1gq67HobuEu3cNfp+8jnPDc6kTo4z+V722NVnQiQaZWNCKeMLpYOBzHMHniztPc
oo4S6q63VSNhAtCmiEEF1Z9pEiNOtEUfnT9NCiylTSrvAYaCkaJEGLJnru3Er1wWoDn9A4ZvgFfx
Ht5hzFMYdDkNXUVyFTsZq+tlARgKloiMuNLRnxicIRYjHiZc5zg58qHBCyDP/G3B95Z8HnhpP5Ma
h7q7OqTNtgnIDlXx2zAjJ16HOZSU+SkEJ5rAnrvaADP7s1pPVNZymIARP7QlGbAcvDEXeATuGALH
MlR7XNOgzknZ7AbgsjP8ouBwtmgeRbj6hj7fCtHoBiSgy5N0ROVer1QZ0AnR/Ps0sLHXX9h7ExAs
aOI6Qb2IsmrLHiicrCaXGPSRsxVpizzgAGBAhisXL1HZ1P55wrL7SIoWPdVRE294qpN/qHJKuErV
j8GQjK/krzy/AfdCYKEvCta9R5h5OS881ekx8sCu+5H2yVMNCr+3wcwkLdILOzPzDS54YnFA97hs
fzqWI/9w30qkLMOkvLv3SWSgJ+TY7ADzNsUd1dE+SnAUKN06DcSROvEwXBrDUYGXReADtO6W9h0r
qNgH78VIgaOqzCqMC2WnKQw0kNDVtEKSN6qu/BikhHQk79Gp1Ch63teIS67hEu+XBnIYzeTe+RTI
Oii5UN/KFEw60tqgSok1GT2vtQdypJLSaYm+JkjTZ70g4r+w8jPWk3gE6ilDOh81q7RwtDGomunz
r3K/7dSF1LkShUmO0rwETs5P0zH1YpYA4Pfuayg64X6vxAq2krCjqKUzZPGMkqUa5wvwJzmHDESf
ILAOTyt/hLXNsTya26tZps82N4jl7wTDPLz/nOArKsoA9HLZxWuVhgpjPMiAhbfAwZ1m6fAmBNoH
KLX3/cx7jyXRK47vjftdMgvmEUUqV0Bo+rPB5LWnZEd82TfSe250VwPjbmtP/ef9D2fkrmIxp9vu
u/ghTRCDUdANwxxlhrHnWYioUbBrOphBP5oZhCKICQqfFI1oXACd/k+wX2Ze4zAiErUkvKSm3E4I
K44fhpxpFvSkmUj41XvOha5tA6FyF0immYtZGQHH0qekudM/b1xgDkeVle8L28FRcM5LrjGAnumB
Ok69l2XrMY9yQ1rTYERUsCm7BMn5YJjYyPAg6RXQ3oFESEeTomXXOgLoZhiY9fQxVnRE5RrynsvY
mdujlnBf6kRImiPhpzcRqwH/pf0UcbKo8K0EKSyXqkcDci+mPmU286872KkE/525XBeKn+Vh1qMe
Sd7GIKPCHFwVOnqzyZOdoSZhCjFWV1QkZ6/7FW72y+fWXIIsETEl5cEdHzkD7/GSLfV8fpBZMKAt
mpAmijd1b6MdA4WW16VX30z37CJpifspJ5tsxcYtqK7rTwQRp9z8XFmrsrWSrVyiGjU0WMiQQsiT
DDZ+DeqIz1Ww+tUQy7Jzyh+Kp/8viXLibbs8DUAM73nPICsmdjEa7qeaf1mF5Dy2eAIyfjfpTz6H
VEQfxjk+pVGp7Qy/CC5hOyxKrBvCsR5WWvfqKcc1RhSMaGhTbcYIeGNI2pg8wrcKk0mn+GgHVtZl
+gNXTmcQ4KcB2/wJmjoQTlowsNe+7B4J9nSDrC2OyAYsBcT16pctm6gBvZD8H04AKCCxeqF9OuZR
IjpJRn9syTKGzzAIx+40EkssTlQroeRc9IEM1Q1WjweVh2eNDZWqpljQUcG2BauG2aB5p5lpbiWS
4Z1Xh2CeDZel9zd3ygFLfoLTGJghFWEVAaiOLWS2y+LQxJcOjHyngi+a8hOzY+BiIXTOiFkNr/hd
tL23Y1n6oZpa6WlB7yuzy079o740KgF6dRT7KSca6c+kTfqNzmvvWQszEOnWp5+1anwB9tQlrG3O
zkpTNCeY3uvH8PmsxLs2fn2U9WY7m0f5vm/dH3SIg2EVW0jz47MsWFtYsX649yHjAGvzX/5GhYGa
7N5S4t/7sIepQRlFNg+u5E3MDGYjfbghfEhTNSD+r8rf6LLdz24VoVqB1atDXlAMfmvgceFwTKgx
ZGAvgUc0+rqLPMCCIWSjIQH+oPQ+IfwPwhDrbuVIwH4d00XRIjOIj24zCDfUNmfqPP75j6iBGAPT
lMCvGkKRZcTFA7vudNvBEOiK2VKyAahNmZ7PUj0gry/IvowHKoY6UlM0yK5LyfSqDPCjiBPd/1aH
XM9UMr+HJu7VZjZoUFNBr4rAujP6fy6sjiDLzKJ+9cE05aPNt4iS2Xwxsn61pOYthwfDNNcjwnwg
YcRdvIQ6nAf3V69GTWYYuTYDxreKQ6lr1cequfLOA6R7hrB0Cg1ekmmEAHfo1Z0Rl/l7hKiVPCwQ
pr2zfbLRVU9zTqWPwwEyrxC40b9T92guh3WNUVeu7dQ9KU3kLwSelC/O3+kol6wOphl7lkFYJggQ
BUb80U1HjpOpr2dwQkH8QRJm9K2MLeUeGOjuSS5x73dSVVMeb8jTW6vl3EhTOYtQDan/ZCsLcJ4V
gLyo7yl+aqtBe1r5SVJ+ilFbSVQhzmgtY6sofKLgg3IrFu5CwFz+uVysEf7zWKf2oc3muderZ+N0
O4ar5nPDQcyQicNDGZ5jY9cXtZGDGM22qmpYeLZhyHb5l+nRGGFBgq7hmpjwgRP5KzCmUpHtxwQO
vmMuMOAirVqWx+ofcbOb96wgLAZjJxyJMeZtoyah0ajtdgxHEcyXF40cTAU3g2m85TCGn8sTukGy
YW0PzNGdBVbi3Fpxty2SB+iAiDrGFoQ62hSv6c8kMUhTkNZVGLOh9ppvLW7bYS0t0Ei0mmkd7dNu
tDEFX2zppKfwQKg1xKWnl1yKeVrAECaXfN9QMkYCBdJQSNwjYKhcukSPhl1sacz0Te2y3Yy/BU3w
QMbyPozie0OD9hMHRIR47cd6r4UAKpVDe2r8xvYukC/Jd5pbCmWFpZ7qZdB7dzXiF00n8W+veqFx
1VcHPJS93tU+WFz0OrVDw7AbEyvp4IzmGEkobQekshpY5+d1L1y5oXrbYKSAgTXHj5pv/ye6T2sn
B8191vQSRZS/DpcZUEOR0YjFkZwWHOEbVgu7+SF6EW5HoUIk1AAVljeDZGWjzigOrAD8wcdAzMpg
jIhHifqiU3U9iVmPYIOxfpK3/bOea7FjaSTS7MMxs2yy4R3qEh5521BIviXhdw19uh9xlyJ4IlN9
p3UD6DtdMAx3DxiTaIw3tmgz7UIM865k40UKA5cigqkrEUYUPR3yLhi5NNDfO2hu8I6lKI+a/ffq
ZFjFG286ZkbSlq1d/iwVYxajc4wzvWoolooC/NiRzE6RXNMK4bYmpERN9mW0AOJKtQs+8qMI4gvD
G/KRhd9M/Ght2Jjmyy86HwK8bxVUWmaJPgahjssoF1z6BnaDRkUXmwBRGjRhnOtLJzakKet3Yg6H
fwsll2UjZh01IBUpTUIIQJa9ZOPAZOZKvgeEcFS4C/c+GGT6/QBMD09vRDoIXmAAsTziWaU8En03
3cqMBL6B3E3D5eukGubvHXDY/rp7KffPUAGtgHV3LdJ5UpZPn38dUtxHqH2bCcaHxbk6LnQ8YZsn
MnF2s5RgDh/yjIiKVyqMjdwbMhnIPxGU208pLQgOLRsjg0sreIgCImZtaC6fYY1G20seBwJsKwuZ
igROCB7Ocq850seXQ5PNceUWoV2+h4IwvKYVKw7mxfpHa28M2kWag9IDIoruD//4hnygjg8vyoK5
ySn2BOsGWy2FRaqMIuV5cozgaZ4P8HpksSZSZtRNDmbh4dvDSykq1eiWM2GQu9z/vzU0lvYH0w6I
ZrwcJlnSI9zBC/LcgEQ0fhInugv5K/NtkSiVhFpePDJQrKwHRsxdUcT8CanqFNdvu6bN1FF5kPSK
jYi6wCVAsd94YjPzpaG9AMX912iqXzPNVXbGWClqqQrM9+sAuPyfATDDgh2js9lNdzzeFI+/cshe
DsjK3HXH6/fUgKvg1yBNoQI2iC5+TdeJ3nwy4CMUV5oGC+xneNOdaBD/fKDMfdR6kkHYUmrs15LP
BP9K98u8sfE7Dqbvk6nhnZiXUgTMS/PeO4vQQ9uuMnLSOyAYnwBIx5B1v2bdvh7kOThXhOSR1fqd
iMhg1Zo4H1RO4ka1r30YmqtEpJRyyMgM2Mv88mSDcxHkp1dHcFYEWUjd8nxWJRKQhfVcaRE8IRiF
3H7WSWdIhjAN0w4muBi2PKmRSDC2AQ/w9YbeXkdDoSXOQh6XjzfrWvhI8oZ5WpzsMpcyTi3JgVOH
K+35Ro3gIXwd6iRpO5RfTIjrnXTAqeF8yIkRbCoPLTb1unYPWdRykourCL7SvEUkawLyY1c08N99
wvQKPoFcKpGDQOJ88JZi07OsAdue5FkfXbOtgeLF/EWzyYASi29PxAFwpSKzZXRi+UMKV6P5pam0
P/gVBTpaUbiedT1UTLgd/M0Zo2SMLzhShXXOxSbaxzilKtr6r3l5DgiZrtcfg0RYX6O/FR+a/P4s
Gm28hlMkTjRCuoLPQpZqPj3AGeJ6X9oGIwxUr2lq900a+9VR1XtC5uQz/Py7oooSG/FsgoKBGmhg
6d4dmt3isIxoGRqjE8O2aQzIgCtZ+Sk1OBlRfWUXm6vDUgw3LHr2d5mgtkBNxeEjlbQdCxy/zrpO
DcPNWy9wI+XEDFLj6ObvtCVjCvaZ1ddwZfy0PjzmiX4y2hguiAU7oQtSKgde7ZmC9IReNmiXDHB8
cWgMS01qvJAK8oxeiYLOHi0j0IKKKTCdgX2CGIUeI9Frt0BSfa7ThJgJ10xGoU8wPS7331/v0K7g
rfh5fxfLaWvzaFwamIc518c/otCXFBIxefTAz3NLM914ScAwjA+uV3c7rb1OAlj28p+mdmourrJQ
jrlvdc8zcc2oFYWS0jkOv1UJjOWkOrROZamIBp2+o5DVBUl4KPdpWzkuEfQSoMDYmlxW6dPcYuav
QcKF0DDwcEuuCFg+LBuwMFzh4M9X7eFUsBTOwqHl8GINv2FYFIOTVgKDcM96zjdJTZ+2M78Ky+xJ
ZJGEMldc4g+yB647Vu8VmHr2XFpyXfHjH2ZHNoKYkGxe+0D1P4LTVYmfBy+qMCL9SKExg8M7L1b7
EAkamFmPRrv5VPBFNWkS2opyWgKK4eiftbehMx0/WmA3u438QLSM/tHwOBhaMymLg1FiKaUZq9NF
xgBBoLCYziVJLCm2pNBbL0TjLZJC78D5RPe3QIGri2Hvo9LnNjNkfsc2w2Q1V3mnxZQWSNeUQJTc
++EX583HaHLKFtCDmQ763N5Con9QbbZm5h1Zu9FjQ/byTSz43jPLRklQ8wfZ/+Tfghjcox5w03Nd
dLTl6cSA7QpZMr8wu/mFNPYblkVWBW4deeA2+N7Ck1eXM+i2itO+5kl0u1wamNpA0HC4CdpiuOlc
jWOeWaFsKONrBXcRd9L7GlTzKilHgQ1Mrh0OH4oUt1eMmfnR40Gcg+dhfAiWrlx+syJk6ts4lHsW
kAPS9ij6C2ayQoZDmL7oyRIm3giO44St8RzpEyi1LospsM1WcZW5xOu1qXz9+30MnbtrMwYinGAJ
GPqLbQ1lgCLsaHMILpDjKfFZwz5aO4gO7LPTZSm8VlSQ68OcolwynC5fc/YE9O4xkG6m1CL93Hto
MUBzSLPVN6kcISeDAJDu0mPEsRf674E5f2bYKhpZOZZ0pmpdPWVeJYLyiIybp2NCD0W1Br2jvlR3
1j+r1Dx1jJFIa59KaplTKgeOmlgnJQlc2RdIRejU81wTKHAPwi76JKBAp8l+XJ3jA8uhcYcereTa
LUjKDwmlnugpC1qeHTUgzhXtssBNY/tlOBvHCZbi4cE8XndhsStHcMg6tL434dKfybPzsdzeSDhI
f2Co4HglgWOZl0H91ECjfc9N4R0i7lJ3QvhrcTKwT4gna+ctSCq3tnd6y4z3sZZigYe3vowisMPl
u5eIMpsmt4tMjqxpARISmeIbFcVnkYKHnkFy9Q6pUEql4LZ6mGABBOPAJ0zrQYOTAyEonvnxTEHl
0knDioEkNZS7WYlcZ4wJx3PZ1JtZJY+WnNNQAiV0ygMJimLcY6x2YU8jYgZqhMU/jcWh5D7Gs+NS
hGIadhhVbJD+FUl8iUZmyAhGPhX2QtMpfvlBDu3WOjNa2SWWGi8Rv94ZBQF7OfBlTYGAkDVHWcp9
ndq39cv6NTyZLsNjvg2Mal0pGNJU+77vJ/lgIDN72m5o1wNK2UHRhyCZTK6eFRz0ej7uescvD/kU
6NFrwdOQEucgMLn39hoeuVk557Nyo8r5DEDJacWN3MEazCwUrddtUHgfri2vMQluAaZMxrWJkEoM
DqAqNxMxa2WflMKpd5CrC4Xpvgt+CgW7SqUW/nK+G6EHc1rn4Shhl/4Bjt0ML9PvahkaTmHYWheV
+Q1tXG+qF9GcxpBynZ4WtYqBxBIDzZd2PvpCl0+C+XCQsE7ZbfZDvvgV9KLHJHjD8PnkRH1SA0Ot
Ylcf9GJVZEoQYZ1fg890CRJLGOEAfDgavkpAjTibkpnVjMvhbm8c5c0r8PsfeXjCieCZ+KfS82cJ
QbeeyVjzA3x5rMtKaMYLvguyC08Js3fv9W6u/30VnbHlozeAdimwoeZlut1gHEBoL7lhDg/hs5UT
md18ceGit2m9jiuvFKTdpxPEA5LFjgbMubeCYjLkGYo9ymCcx3p9llKif4/LSr96ejPPvPfT0Nmc
HbwQBc08vyoKhcZPpD+SumdL3yDnYeXwFt90dxSlNlplfMonTPq56BX7S8Lv6Ffg5MtjQ1dDpYyc
6QMj+mjy/QC5zvpqBoMq8nK3LzkMGgTlEnqW1JILyNWcbSUkZJbSyFIHbc6ojzAm7yJo0FKduuLr
h59GqvnN2uJddC/YUdDUx5CA4cJHgpdwwfQrQM+x+Y9/mQ5fknCahMPT1N+yabgmNwzOHtGaqSh4
ajxqNsM5DIPfWoZKWtOoX5d9kkPMIGUu0+E1XoFtxF5aQt6RX7U1ERiDP6f8aYlVHEMWuYsgbOtL
Yk91VbH44DFKoJkNa/zveT6ZgTlpiMZ7fngk/5K20dfPMRaacgnm6oVQp70jxP4m2EGY+L2LTw/1
bnPw7pQ9BNq86Pfep2Fdz2T799rHVUm9EXOVNLcVdUPNgU8Let/UZTAkdg+V3i61++vqx+VkAug3
1BHgmU2bSOTJ0aucUbf1ZxdCus5S49bu1vjZioMI8pSwVaw1UdAfjzfABCP/lj3D13NOWWZk9VY8
vGqOeOE64ELUhosHGC+ySCztIJkF0KSo9ZL3zUqzNri1VtQe+J3e18VqRgj8M6vaOpS1B8SR32uM
aqx1YWU3xQ5b/+AFVIShwnEI19sD1LoK0PUHW6lpe5ENS5S/M0r3UQQbCvwtyczN00KizKY4d6Tz
tjVds4/2RWjg9quAjgco03CrKDJIfmljUrREiyLh3S0mxny2marN6NqUAUVVe3luY/b6RHnM57yy
Rp1Tkm9fZaFD0OgakVWGdGwuEfh445yx9j21MjyvKutoFqB1b0BiROSZkof0LXdJzESDXzTIFzRQ
VE+i0L0ruy4V6YG6IZ+FrcEkDpMUaQ5muL14nsUXNBtZGRSJm8OMSkf7GJ9WS+lXtHDgw0lkZPiH
XL1yZIakh5hzoK3K1DZZ9CvIkk32ARTWekpWqj3kX+AUUr+MY/0wHfiamYkyfFgkY3hDg4X1qJbl
TFN4ePFoLdrh5orWt1jB9pyc+jGWIiuhFRT+w779cKOXLOlQKsuJT9T+JmPeXZBNy6wcAobXwWti
e7JZIZCe2Beq9VQxaGPXRXWbQt8wSg9dXKvwMKSoqesC6M/q8T7USXbqibdfZPgnKjXxyZusFoI5
E3fMUqGwPF3fbH0brRwRYT3DVg+2gOnkhbcgWlNXsYb7XvVcK9W7nZ+vNviBKsLxoxyh5ybGMsDf
XWcnphuT0E53/7rAg03BIfDCrfKoAEV9eh0oeYNMaRtJMkhyd7EJgZXDvrhoeHkibAuL8vihZ4fJ
GFtGE07du7zmqTjvIKg4xqR+3hTpvXAmn3z3H3VB5r8yR44QA0B1jpTLzcot6RFOfGoI1ngSEq6o
BH6FklCx9/qo1CvN8lB/A/SKnE8VS6r/wPAO49ZRxjx1ImUzeHyMvsMBV8dVY5WvLTgx0g/5FSwa
ogTPY5S0eLfc5S1LQT7F9f2ZwSPa6cziYRS5/JxKVJyeZnZL2zt+j5+9tNpD1PydSeylSmjvI9a6
oBsSY++5ykjHtlIgfZvYtG33bNKyVFJuTTW95lgcXaiGJK8Ffre49vPgT/vOVzh4W3KbbT9I543L
c01G8aO+8+B4RmffXR+wkNaGe3q5+aoK6EFD+TuPXb9JGGsZsU2u4Zl1XJdYCqU7kfjcx5phVShk
OT36qkeZmsKfHQJiApiMeA/lmAF5RTHsvFfpvS83ODJhGCEkt4MESQGzWpbsNhVrRGbD1GFe1Wkg
KmL3Uiv/htn2S4JaQuuQN5dxKxKaV88HBw8tP/DvqD+Kg7buf9XFEtbXM9eRtZfQOUAoo/jbMZV6
DLeNd7H7QrRfxbyon7C7t/xG0+ciednaZRVudrdKWxDGPMsqUJRriG1+l6COPe7dZdPWCJM4j+VF
gfm0xwE2vcZQ3++T8f9cpYDWwrEN97SkRpY6MZXJOeSbjm/AVkg2iDVTxDnV3ba+SjPpBer8JEHy
ZdyCoC1UBbupn4QuqzB5DzvGVjAbJFsV34xeKCbNCNFD5zb+aBXzcib0MnqCS5aZzGnOBx6BKADT
KvoF2tjdLMDC21CB01/RuqcF+iaNvjAHRJNGcdzURsIoUfqwMLzlO+FqQk85Tn/nz1QPK33OuSx7
1159R/ayaQrZwaMIJwVjVEedP0XWnkClKpxH
`pragma protect end_protected
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
