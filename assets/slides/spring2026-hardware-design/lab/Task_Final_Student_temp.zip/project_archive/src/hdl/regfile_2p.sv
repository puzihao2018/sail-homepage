// Module: regfile_2p
// Description: 2-port register file for RISKing Processor
// Supports simultaneous read and write operations
// Two read ports and one write port
// Eight 16-bit registers (addressed by 3-bit addresses)
// Don't change this file
// --------------------------------------------------------------

module regfile_2p (
    input logic clk,                     // Clock signal
    input logic rst,
    // write port
    input logic wen,
    input logic [2:0] waddr,             // Write address
    input logic [15:0] wdata,            // Write data
    // read port 1
    input logic [2:0] raddr1,            // Read address 1
    output logic [15:0] rdata1,          // Read data 1
    // read port 2
    input logic [2:0] raddr2,            // Read address 2
    output logic [15:0] rdata2           // Read data 2
);

// Register array
logic [15:0] registers [7:0];

// Write operation
always_ff @(posedge clk or posedge rst) begin
    if (rst) begin
        // Reset all registers to 0
        integer i;
        for (i = 0; i < 8; i = i + 1) begin
            registers[i] <= 16'b0;
        end
    end else if (wen) begin
        registers[waddr] <= wdata;
    end
end

// Read operations (combinational)
assign rdata1 = registers[raddr1];
assign rdata2 = registers[raddr2];

endmodule