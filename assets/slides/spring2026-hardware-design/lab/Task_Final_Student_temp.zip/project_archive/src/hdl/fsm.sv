// Module: fsm
// Description: Finite State Machine for RISKing Processor

module fsm (
    input clk,
    input rst,
    /*********** Fill your code below *****************/


    /*********** End of your code *******************/
    output halt
);

// Parameters
parameter Rtype = 2'b00;
parameter Itype = 2'b01;
parameter LDI   = 5'b10000;
parameter LUI   = 5'b10001;
parameter LDR   = 5'b10010;
parameter STR   = 5'b10011;
parameter JMP   = 5'b11000;
parameter JAL   = 5'b11001;
parameter JR    = 5'b11010;
parameter BEQ   = 5'b11011;
parameter BNE   = 5'b11100;
parameter BLT   = 5'b11101;
parameter BGE   = 5'b11110;
parameter HLT   = 5'b11111;

parameter ADD  = 3'b000;
parameter SUB  = 3'b001;
parameter ADDC = 3'b010;
parameter SUBC = 3'b011;
parameter AND  = 3'b100;
parameter ANDBB= 3'b101;
parameter OR   = 3'b110;
parameter ORBB = 3'b111;

parameter VSEL_DP = 2'b00;
parameter VSEL_PCPLUS1 = 2'b01;
parameter VSEL_SXIMM8 = 2'b10;
parameter VSEL_TXIMM8 = 2'b11;

parameter ARITH_SEL_IR = 1'b0;
parameter ARITH_SEL_PASS = 1'b1;

parameter RB_SEL_RB = 1'b0;
parameter RB_SEL_RD = 1'b1;

parameter ADDR_SEL_PC = 1'b0;
parameter ADDR_SEL_ADDRREG = 1'b1;

parameter PC_SEL_PCPLUS1 = 2'b00;
parameter PC_SEL_JUMPADDR = 2'b01;
parameter PC_SEL_ADDRREG = 2'b10;
parameter PC_SEL_ZERO = 2'b11;


// State encoding
(* DONT_TOUCH = "true"*) typedef enum logic [7:0] {
    INIT = 8'd0,
    FETCH = 8'd1,
    DECODE = 8'd2,
    /*********** Fill your code below *****************/


    /*********** End of your code *******************/
    HALT = 8'hff
} state_t;

// State register
(* DONT_TOUCH = "true"*) state_t current_state, next_state;


// Sequential logic for state transition
always_ff @(posedge clk or posedge rst) begin
/*********** Fill your code below *****************/


/*********** End of your code *******************/
end

// Combinational logic for next state and outputs
always_comb begin: next_state_logic
    // Next state logic
    /*********** Fill your code below *****************/


    /*********** End of your code *******************/
end

// Output logic based on current state
always_comb begin: fsm_output_logic
    // Default values for outputs
   /*********** Fill your code below *****************/


    /*********** End of your code *******************/
end

endmodule
