// Top module that interfaces the ALU and BASYS3 board components
// BTN mapping
//          BTNT
//  BTNL    BTNC    BTNR
//          BTND
/////////////////////////////////////////////////////////////////



`timescale 1ns / 1ps

module top(
  input       clk,                          // Clock input
  input [15:0] SW,                          // Input switches
  input       BTNL, BTNR, BTNU, BTND, BTNC, // Input buttons

  output CA, CB, CC, CD, CE, CF, CG, DP, // 7-segment display segments
  output [3:0]  AN,          // 7-segment display anodes
  output [15:0] LED       // LED outputs to show the result
);

// Internal Signals
logic       rst;            // Reset signal
logic [15:0] cpu_out;      // Output from CPU to display on 7-segment

debounce rst_debounce (
  .clk(clk),
  .btn_in(BTNC), // Use the center button for reset
  .btn_out(rst)
);


// CPU instance
cpu cpu_inst (
  .clk(clk),
  .rst(rst),
  .io_in(SW),
  .out_led(LED),
  .out_seg7(cpu_out)
);

// Output to 7segment display
seg7display #(
  .MODULES(1)
) U_DISPLAY (
  .x_l(cpu_out),
  .x_h(16'b0),
  .clk(clk),
  .reset(rst),
  .a_to_g ({CG, CF, CE, CD, CC, CB, CA}),
  .an_l(AN),
  .an_h(),
  .dp_l(DP),
  .dp_h()
);

endmodule