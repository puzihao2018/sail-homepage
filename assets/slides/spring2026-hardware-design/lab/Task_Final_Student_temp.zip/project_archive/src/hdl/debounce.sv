module debounce #(
  parameter int DEBOUNCE_COUNT = 2_000_000
) (
  input logic clk,
  input logic btn_in,
  output logic btn_out
);

  // 100MHz clock = 10ns period
  // For 20ms debounce delay: 20ms / 10ns = 2,000,000 cycles
  localparam int COUNT_WIDTH = $clog2(DEBOUNCE_COUNT);
  
  logic [COUNT_WIDTH-1:0] count;
  logic btn_sync;
  logic btn_r;
  
  // Synchronize input to clock domain
  always_ff @(posedge clk) begin
    btn_r <= btn_in;
    btn_sync <= btn_r;
  end
  
  // Debounce counter
  always_ff @(posedge clk) begin
    if (btn_sync != btn_out) begin
      if (count == DEBOUNCE_COUNT - 1) begin
        btn_out <= btn_sync;
        count <= '0;
      end else begin
        count <= count + 1'b1;
      end
    end else begin
      count <= '0;
    end
  end

endmodule
