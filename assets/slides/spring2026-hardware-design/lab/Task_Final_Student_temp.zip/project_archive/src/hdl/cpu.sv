// Module: cpu
// Description: Top-level CPU module for RISKing Processor

module cpu (
  input logic clk,                 // Clock signal
  input logic rst,                  // Reset signal

  // IO Interfaces (not fully defined in this design)
  input logic [15:0] io_in,         // Input from IO devices
  output logic [15:0] out_led,
  output logic [15:0] out_seg7,

  // Debugging
  output logic halt
);


/*********** Fill your code below *****************/
// Datapath
datapath DP_Inst (
  .clk(),
  .rst(),
  // Instruction fields
  .rd_addr(),
  .ra_addr(),
  .rb_addr(),
  .alu_op(),
  .shift_op(),
  // Control signals
  .vsel(),
  .rf_wen(),
  .asel(),
  .bsel(),
  .loady(),
  .loads(),
  .loada(),
  // Input Data
  .datapath_in(),
  .sximm8(),
  .tximm8(),
  .sximm5(),
  .pc_plus1(),

  // Output Data
  .datapath_out(),
  .address_out(),
  .status_out()
);


// Memory (Instruction and Data)
mem_wrapper MEM_Inst (
  .clk(),
  .ena(),
  .wen(),
  .addr(),
  .data_in(),
  .data_out()
);

//---------------------------------------------
// Peripherals: Special Function Registers
// Base Address: 0x0400 - 0x07FF
// Register 0 (0x0400): Input Register (Read-only) from SW
// Register 1 (0x0401): Output Register (Read/Write) to LED
// Register 2 (0x0402): Output Register (Read/Write) to 7-segment Display
//---------------------------------------------






/*********** End of your code *******************/




endmodule