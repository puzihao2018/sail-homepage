// Module: tailext
// Description: Tail extension module for RISKing Processor

module tailext #(
  parameter IN_WIDTH = 8,        // Input width
  parameter OUT_WIDTH = 16       // Output width
)
(
  input  logic [IN_WIDTH-1:0] in,         // 8-bit input
  output logic [OUT_WIDTH-1:0] out        // 16-bit output with sign extension
);

  // Combinational logic for tail extension
  // e.g input 1111_1111 -> output 1111_1111_0000_0000
  always_comb begin
    out = {in, {(OUT_WIDTH-IN_WIDTH){1'b0}}};
  end
  
endmodule