// Module: datapath
// Description: Datapath for RISKing Processor
// Integrates Register File and ALU modules
// --------------------------------------------------------------

module datapath(
    input logic clk,//
    input logic rst,//
    // Instrction fields
    input logic [2:0] rd_addr,//
    input logic [2:0] ra_addr,//
    input logic [2:0] rb_addr,//
    input logic [2:0] alu_op,//
    input logic [1:0] shift_op,//
    // Control signals
    input logic [1:0] vsel,//
    input logic rf_wen,//
    input logic asel,//
    input logic bsel,//
    input logic loady,//
    input logic loads,//
    input logic loada,//
    // Input Data
    input logic [15:0] datapath_in,//
    input logic [15:0] sximm8,//
    input logic [15:0] tximm8,//
    input logic [15:0] sximm5,//
    input logic [15:0] pc_plus1,//
    // Output Data
    output logic [15:0] datapath_out,//
    output logic [15:0] address_out,//
    output logic [3:0] status_out//
);

/*********** Fill your code below *****************/


// Register File instance
regfile_2p RF_Inst (
    .clk(),
    .rst(),
    .ra_addr(),
    .rb_addr(),
    .rw_addr(),
    .rw_data(),
    .wen(),
    .ra_data(),
    .rb_data()
); 


/*********** End of your code *******************/


endmodule
