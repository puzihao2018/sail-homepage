module arith_ctrl(
  input logic arith_sel,
  input logic [2:0] ir_alu_op,
  input logic [1:0] ir_shift_op,
  output logic [2:0] alu_op,
  output logic [1:0] shift_op
);

parameter ARITH_SEL_IR = 1'b0;
parameter ARITH_SEL_PASS = 1'b1;

// Note: No clock needed. ALU is fully combinational
/*********** Fill your code below *****************/


/*********** End of your code *******************/

endmodule