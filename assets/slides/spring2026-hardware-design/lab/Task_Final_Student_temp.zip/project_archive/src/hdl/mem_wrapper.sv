//mem_wrapper
//use simulation memory module for simulation
//use xilinx block memory for synthesis
//don't change this file

module mem_wrapper (
  input logic clk,
  input logic ena,
  input logic wen,
  input logic [9:0] addr,
  input logic [15:0] data_in,
  output logic [15:0] data_out
);

`ifdef SIMULATION
  // Use simulation memory module
  mem_sim MEM (
    .clk(clk),
    .ena(ena),
    .wen(wen),
    .addr(addr),
    .data_in(data_in),
    .data_out(data_out)
  );
`else
  // Use Xilinx block memory for synthesis
  blk_mem_gen_0 MEM (
    .clka(clk),
    .ena(ena),
    .wea(wen),
    .addra(addr),
    .dina(data_in),
    .douta(data_out)
  );
`endif

endmodule