/////////////////////////////////////////////////////////////////
// Module Name: alu
// Description: alu for RISKing Processor
// ALU Op Design
// 000 - ADD: Y = A + B, update Z, N, V, C
// 001 - SUB: Y = A - B, update Z, N, V, C
// 010 - ADDC: Y = A + B + C_in, update Z, N, V, C
// 011 - SUBC: Y = A - B - C_in, update Z, N, V, C
// 100 - AND: Y = A & B, update Z, N
// 101 - ANDBB: Y = A & ~B, update Z, N
// 110 - OR: Y = A | B, update Z, N
// 111 - ORBB: Y = A | ~B, update Z, N
// --------------------------------------------------------------
// This is a block level description of the ALU module.
/////////////////////////////////////////////////////////////////

module ALU (
  input logic [15:0] A,         // First operand
  input logic [15:0] B,         // Second operand
  input logic C_in,             // Carry input for ADDC and SUBC
  input logic [2:0] op,         // Operation code
  output logic [15:0] Y,        // ALU Y
  output logic [3:0] status     // Status flags: {Z, N, V, C}
);


// Note: No clock needed. ALU is fully combinational
/*********** Fill your code below *****************/


/*********** End of your code *******************/

endmodule