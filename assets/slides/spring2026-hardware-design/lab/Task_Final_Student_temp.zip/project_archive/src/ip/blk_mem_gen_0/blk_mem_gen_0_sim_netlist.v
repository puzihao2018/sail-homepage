// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2025.2 (win64) Build 6299465 Fri Nov 14 19:35:11 GMT 2025
// Date        : Wed Mar  4 16:31:54 2026
// Host        : TX14Air-ZIHAOPU running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode funcsim d:/Code/HAD26Lab/RISKing16/ip/blk_mem_gen_0/blk_mem_gen_0_sim_netlist.v
// Design      : blk_mem_gen_0
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7a35tcpg236-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "blk_mem_gen_0,blk_mem_gen_v8_4_12,{}" *) (* downgradeipidentifiedwarnings = "yes" *) (* x_core_info = "blk_mem_gen_v8_4_12,Vivado 2025.2" *) 
(* NotValidForBitStream *)
module blk_mem_gen_0
   (clka,
    ena,
    wea,
    addra,
    dina,
    douta);
  (* x_interface_info = "xilinx.com:interface:bram:1.0 BRAM_PORTA CLK" *) (* x_interface_mode = "slave BRAM_PORTA" *) (* x_interface_parameter = "XIL_INTERFACENAME BRAM_PORTA, MEM_ADDRESS_MODE BYTE_ADDRESS, MEM_SIZE 8192, MEM_WIDTH 32, MEM_ECC NONE, MASTER_TYPE OTHER, READ_LATENCY 1" *) input clka;
  (* x_interface_info = "xilinx.com:interface:bram:1.0 BRAM_PORTA EN" *) input ena;
  (* x_interface_info = "xilinx.com:interface:bram:1.0 BRAM_PORTA WE" *) input [0:0]wea;
  (* x_interface_info = "xilinx.com:interface:bram:1.0 BRAM_PORTA ADDR" *) input [9:0]addra;
  (* x_interface_info = "xilinx.com:interface:bram:1.0 BRAM_PORTA DIN" *) input [15:0]dina;
  (* x_interface_info = "xilinx.com:interface:bram:1.0 BRAM_PORTA DOUT" *) output [15:0]douta;

  wire [9:0]addra;
  wire clka;
  wire [15:0]dina;
  wire [15:0]douta;
  wire ena;
  wire [0:0]wea;
  wire NLW_U0_dbiterr_UNCONNECTED;
  wire NLW_U0_rsta_busy_UNCONNECTED;
  wire NLW_U0_rstb_busy_UNCONNECTED;
  wire NLW_U0_s_axi_arready_UNCONNECTED;
  wire NLW_U0_s_axi_awready_UNCONNECTED;
  wire NLW_U0_s_axi_bvalid_UNCONNECTED;
  wire NLW_U0_s_axi_dbiterr_UNCONNECTED;
  wire NLW_U0_s_axi_rlast_UNCONNECTED;
  wire NLW_U0_s_axi_rvalid_UNCONNECTED;
  wire NLW_U0_s_axi_sbiterr_UNCONNECTED;
  wire NLW_U0_s_axi_wready_UNCONNECTED;
  wire NLW_U0_sbiterr_UNCONNECTED;
  wire [15:0]NLW_U0_doutb_UNCONNECTED;
  wire [9:0]NLW_U0_rdaddrecc_UNCONNECTED;
  wire [3:0]NLW_U0_s_axi_bid_UNCONNECTED;
  wire [1:0]NLW_U0_s_axi_bresp_UNCONNECTED;
  wire [9:0]NLW_U0_s_axi_rdaddrecc_UNCONNECTED;
  wire [15:0]NLW_U0_s_axi_rdata_UNCONNECTED;
  wire [3:0]NLW_U0_s_axi_rid_UNCONNECTED;
  wire [1:0]NLW_U0_s_axi_rresp_UNCONNECTED;

  (* C_ADDRA_WIDTH = "10" *) 
  (* C_ADDRB_WIDTH = "10" *) 
  (* C_ALGORITHM = "1" *) 
  (* C_AXI_ID_WIDTH = "4" *) 
  (* C_AXI_SLAVE_TYPE = "0" *) 
  (* C_AXI_TYPE = "1" *) 
  (* C_BYTE_SIZE = "9" *) 
  (* C_COMMON_CLK = "0" *) 
  (* C_COUNT_18K_BRAM = "1" *) 
  (* C_COUNT_36K_BRAM = "0" *) 
  (* C_CTRL_ECC_ALGO = "NONE" *) 
  (* C_DEFAULT_DATA = "FFFF" *) 
  (* C_DISABLE_WARN_BHV_COLL = "0" *) 
  (* C_DISABLE_WARN_BHV_RANGE = "0" *) 
  (* C_ELABORATION_DIR = "./" *) 
  (* C_ENABLE_32BIT_ADDRESS = "0" *) 
  (* C_EN_DEEPSLEEP_PIN = "0" *) 
  (* C_EN_ECC_PIPE = "0" *) 
  (* C_EN_RDADDRA_CHG = "0" *) 
  (* C_EN_RDADDRB_CHG = "0" *) 
  (* C_EN_SAFETY_CKT = "0" *) 
  (* C_EN_SHUTDOWN_PIN = "0" *) 
  (* C_EN_SLEEP_PIN = "0" *) 
  (* C_EST_POWER_SUMMARY = "Estimated Power for IP     :     1.51805 mW" *) 
  (* C_FAMILY = "artix7" *) 
  (* C_HAS_AXI_ID = "0" *) 
  (* C_HAS_ENA = "1" *) 
  (* C_HAS_ENB = "0" *) 
  (* C_HAS_INJECTERR = "0" *) 
  (* C_HAS_MEM_OUTPUT_REGS_A = "0" *) 
  (* C_HAS_MEM_OUTPUT_REGS_B = "0" *) 
  (* C_HAS_MUX_OUTPUT_REGS_A = "0" *) 
  (* C_HAS_MUX_OUTPUT_REGS_B = "0" *) 
  (* C_HAS_REGCEA = "0" *) 
  (* C_HAS_REGCEB = "0" *) 
  (* C_HAS_RSTA = "0" *) 
  (* C_HAS_RSTB = "0" *) 
  (* C_HAS_SOFTECC_INPUT_REGS_A = "0" *) 
  (* C_HAS_SOFTECC_OUTPUT_REGS_B = "0" *) 
  (* C_INITA_VAL = "0" *) 
  (* C_INITB_VAL = "0" *) 
  (* C_INIT_FILE = "blk_mem_gen_0.mem" *) 
  (* C_INIT_FILE_NAME = "blk_mem_gen_0.mif" *) 
  (* C_INTERFACE_TYPE = "0" *) 
  (* C_LOAD_INIT_FILE = "1" *) 
  (* C_MEM_TYPE = "0" *) 
  (* C_MUX_PIPELINE_STAGES = "0" *) 
  (* C_PRIM_TYPE = "1" *) 
  (* C_READ_DEPTH_A = "1024" *) 
  (* C_READ_DEPTH_B = "1024" *) 
  (* C_READ_LATENCY_A = "1" *) 
  (* C_READ_LATENCY_B = "1" *) 
  (* C_READ_WIDTH_A = "16" *) 
  (* C_READ_WIDTH_B = "16" *) 
  (* C_RSTRAM_A = "0" *) 
  (* C_RSTRAM_B = "0" *) 
  (* C_RST_PRIORITY_A = "CE" *) 
  (* C_RST_PRIORITY_B = "CE" *) 
  (* C_SIM_COLLISION_CHECK = "ALL" *) 
  (* C_USE_BRAM_BLOCK = "0" *) 
  (* C_USE_BYTE_WEA = "0" *) 
  (* C_USE_BYTE_WEB = "0" *) 
  (* C_USE_DEFAULT_DATA = "1" *) 
  (* C_USE_ECC = "0" *) 
  (* C_USE_SOFTECC = "0" *) 
  (* C_USE_URAM = "0" *) 
  (* C_WEA_WIDTH = "1" *) 
  (* C_WEB_WIDTH = "1" *) 
  (* C_WRITE_DEPTH_A = "1024" *) 
  (* C_WRITE_DEPTH_B = "1024" *) 
  (* C_WRITE_MODE_A = "WRITE_FIRST" *) 
  (* C_WRITE_MODE_B = "WRITE_FIRST" *) 
  (* C_WRITE_WIDTH_A = "16" *) 
  (* C_WRITE_WIDTH_B = "16" *) 
  (* C_XDEVICEFAMILY = "artix7" *) 
  (* downgradeipidentifiedwarnings = "yes" *) 
  (* is_du_within_envelope = "true" *) 
  blk_mem_gen_0_blk_mem_gen_v8_4_12 U0
       (.addra(addra),
        .addrb({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .clka(clka),
        .clkb(1'b0),
        .dbiterr(NLW_U0_dbiterr_UNCONNECTED),
        .deepsleep(1'b0),
        .dina(dina),
        .dinb({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .douta(douta),
        .doutb(NLW_U0_doutb_UNCONNECTED[15:0]),
        .eccpipece(1'b0),
        .ena(ena),
        .enb(1'b0),
        .injectdbiterr(1'b0),
        .injectsbiterr(1'b0),
        .rdaddrecc(NLW_U0_rdaddrecc_UNCONNECTED[9:0]),
        .regcea(1'b1),
        .regceb(1'b1),
        .rsta(1'b0),
        .rsta_busy(NLW_U0_rsta_busy_UNCONNECTED),
        .rstb(1'b0),
        .rstb_busy(NLW_U0_rstb_busy_UNCONNECTED),
        .s_aclk(1'b0),
        .s_aresetn(1'b0),
        .s_axi_araddr({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .s_axi_arburst({1'b0,1'b0}),
        .s_axi_arid({1'b0,1'b0,1'b0,1'b0}),
        .s_axi_arlen({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .s_axi_arready(NLW_U0_s_axi_arready_UNCONNECTED),
        .s_axi_arsize({1'b0,1'b0,1'b0}),
        .s_axi_arvalid(1'b0),
        .s_axi_awaddr({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .s_axi_awburst({1'b0,1'b0}),
        .s_axi_awid({1'b0,1'b0,1'b0,1'b0}),
        .s_axi_awlen({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .s_axi_awready(NLW_U0_s_axi_awready_UNCONNECTED),
        .s_axi_awsize({1'b0,1'b0,1'b0}),
        .s_axi_awvalid(1'b0),
        .s_axi_bid(NLW_U0_s_axi_bid_UNCONNECTED[3:0]),
        .s_axi_bready(1'b0),
        .s_axi_bresp(NLW_U0_s_axi_bresp_UNCONNECTED[1:0]),
        .s_axi_bvalid(NLW_U0_s_axi_bvalid_UNCONNECTED),
        .s_axi_dbiterr(NLW_U0_s_axi_dbiterr_UNCONNECTED),
        .s_axi_injectdbiterr(1'b0),
        .s_axi_injectsbiterr(1'b0),
        .s_axi_rdaddrecc(NLW_U0_s_axi_rdaddrecc_UNCONNECTED[9:0]),
        .s_axi_rdata(NLW_U0_s_axi_rdata_UNCONNECTED[15:0]),
        .s_axi_rid(NLW_U0_s_axi_rid_UNCONNECTED[3:0]),
        .s_axi_rlast(NLW_U0_s_axi_rlast_UNCONNECTED),
        .s_axi_rready(1'b0),
        .s_axi_rresp(NLW_U0_s_axi_rresp_UNCONNECTED[1:0]),
        .s_axi_rvalid(NLW_U0_s_axi_rvalid_UNCONNECTED),
        .s_axi_sbiterr(NLW_U0_s_axi_sbiterr_UNCONNECTED),
        .s_axi_wdata({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .s_axi_wlast(1'b0),
        .s_axi_wready(NLW_U0_s_axi_wready_UNCONNECTED),
        .s_axi_wstrb(1'b0),
        .s_axi_wvalid(1'b0),
        .sbiterr(NLW_U0_sbiterr_UNCONNECTED),
        .shutdown(1'b0),
        .sleep(1'b0),
        .wea(wea),
        .web(1'b0));
endmodule
`pragma protect begin_protected
`pragma protect version = 1
`pragma protect encrypt_agent = "XILINX"
`pragma protect encrypt_agent_info = "Xilinx Encryption Tool 2025.2"
`pragma protect key_keyowner="Synopsys", key_keyname="SNPS-VCS-RSA-2", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=128)
`pragma protect key_block
YqH9kwIC39+qbZg4PSfFsXuB9k9wnuxNryS/CfnEri6Ci9fSC6fsrQ/T/hnt3u/yolbJ8DJa1Qu6
Qnm24A9jLbA+fu3Nsmm6/rM6a4vU6OfVl/gTFd/CiWDutv6Dhn6Lim4uUNPahoOR/A2Yc4Zo2tdI
kMLO9gn9WlH2l3O2oXs=

`pragma protect key_keyowner="Aldec", key_keyname="ALDEC15_001", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
XJYO2VHd/cnMxQd3i7/2qRhl57dl+doEKuhAunQyv3vpGRG/jlNxj8PqrgLoF0HMdqE3qJUVE/oq
kBSapqjVjLDMOrNGQ+Tc6VGsKMZH8FE/TXHQJ/IM5Iuiu2eozEwwVUomF+7cfqn+9OsVsqCONQ1M
g0oRlangiqasJDhhMfnlGGqwAwmgWRGQA6dmhTuua1s8zdvIv540zY6p5au8cAKVhqyyKK7wbxEE
SGuFqX+NYoyRV+rfWCcWM+hJEmnWS8LNAKkd13YE2+17sPYzUdZ23DmTxXK6KlAxKFW27CBySUfg
qdNXp2DSs2KAQYih27pBNMuHfGbM/ATFPWFvxg==

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-VELOCE-RSA", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=128)
`pragma protect key_block
lYoEi/e8HsDTz6N11EDe/B/iitERmeYndlCklmCluwgb0N4W80JUGVlkd7NlRZHRNhxaNBJPkcjC
n61nO0tb17NwsMwjbY5TF8JWRYTNw1JXCFacvQYrdKv4/7QNQEtwVGiCLxFhOA8aHlWMZIrc2fri
VRMVWaEBcPwCGorlVIM=

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-VERIF-SIM-RSA-2", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
QEw9fEsWFbdX0OQLvYs/gl+zyEOW3ak9TdQVaq+0AXXOT3LIqF7wDxJ6ZBnlf9mNbdsUVH5tAz1o
H8u7ihJl1L3THEvugW+TS8hkvVbEA9rKO2vV15KAj4Lla7UdFT/xDfe79RFarlLI7yGrubjgdoRi
QWy//UKsffG7IWNwmoSuppWiWB4ZHJtkunNyIkm70JPGyZF62VxJg1MTT+5LUbZG5vZjjuHZud9w
xJaKv1tFP/x8RVqLU5gPOqGqTW7/nKO2S+450Vo4D9vAmBVVcXpaL1EbSmCvQ+qJmcQKtf9qYFRV
Zko08hbpHjPxstqvTDro01jRzB8592m4xU2TWA==

`pragma protect key_keyowner="Real Intent", key_keyname="RI-RSA-KEY-1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
TC7q853CWBPPJgbRfgDV1lmjUwSAtliljShAyNFg8sfRfwDzchthzoSPH1UCHV++E2JXacEKq1lB
UWsNP92U4Xh0/Gu+6esOI0pJb8I+TRTxyBN1I4cRQEfQHcwfhbSdeH3yX9OV3opLEqYmT37hWU+J
zCawYnxVESI0FtRzEXve9gdEWlrKKckrT/hp4mvxxOjvOkOSQBvy0elgUOqh6mEOZl+JnUbsR+Wm
CoZLE1eefMZy3FnVmyDNPv3JPXi88aLXMyimal0MYFkTiS4XJiGT3eAIMIbksehXY+eYi/KFpZWQ
GHpX+lG3UmiWWLwyPakFwKEHbrBc70AlJ2eV9g==

`pragma protect key_keyowner="Xilinx", key_keyname="xilinxt_2025.1-2029.x", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
j9nmCKgjPWNChPbpSW6EWLrMA6oCG2JGPoum8px09v0PEAh0DRXZi0J8HPzXUsZgOEMcKpA7X54u
YFcDDCLAQ+urha/eSPbQYHQh4yGCursxAQ1C6LEyNQ2wJ0eLlO2bJeAl/gof06zqsYVM2lLJVNv5
wao1k2bmgPdfpfY3c9vPD0fSMuZPS41EoRS0cQhO5GTZnKdjxm6tEUL3GnTjB8ynSCIbCJUsMtAX
4FRHNa52gudx5B5fagR+lXgFhE7e++rWTJELr7SYB+r5Es8qZLTpCH8TrQxEkV0rY/+e4sAjNE2D
gHw8GD7VcUtc15B8y1BbVmh29qc8Nd3V2i/miA==

`pragma protect key_keyowner="Metrics Technologies Inc.", key_keyname="DSim", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
UkCD6I/Vye4qNoNoa3hIexBXG3xyKUJPAHAjIo7UcNVCDXpMQiYEtPDqExZMfiPlJn2nswCYIfIJ
FYWqMCloKSQyyI/7yZ2EtbyWEklb/P5IyZyvGi6hhFUo/JFTb12b4bK0gZPr+bCDdlVQKTx5GVHz
wptdUJO2omSj8axVMPbLRRtVzlJIZ29dTJ2ATXVXAcBxPnFfHRAMnYYKLeeLExX61vQvpqrkLQHm
XG7hpVzJi56gYKAzxa2BLq072OCVpVS70bfWlhlSTVcSlCrUf+EcarEk4FD8+Ih2NCvrqremG6yn
TtcBn8Xr8M/6zhOYvLi6AD6eArDMKA8n+Ccv8A==

`pragma protect key_keyowner="Atrenta", key_keyname="ATR-SG-RSA-1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=384)
`pragma protect key_block
A5y5QVZU8yjPexRVPioSiAGohCHD5DX5FVobuMyhcgQRExLUhPvnnS8HOtxTj/2IapEcz68gFMGG
Hpi+m725u85/om/Vze9pGIW9Mn328Kz2FIg3W5EvGstfGwY+48LiAGAmTR269JS4lJGVYWYOz7Xk
S8cEsFd2m7j8iyKtARJzD90+UdXq/cIIh725jC9i8nbgxB364zddvm1Z/DF3JRw1qFp6GGcuRai1
KNcJ1j8c9wtIgktpsteU3e5+bxHEw8NT3gWXUFYjm00NDq97Jals8Jjktmum2nQxoF7ivPacfEey
gnSF6jRMkTsZObzc30hAhs0CEtc33hZLhPLHSn8pQ0WyvKJLHdd5s2yckgTZtqxC1Sbwe7WEgNXe
ZMX3pIkz+aoXsAL7GBLyVBMVQcyMoF0w8QGAaTe8sqatABwPqXidYRqNROTf62IYcMpV89XYgaTv
EwIn/oni9KOFd2BFVxRZbFGGC4IjvigsTBUijI+Dk6kVnDh240clGcc4

`pragma protect key_keyowner="Cadence Design Systems.", key_keyname="CDS_RSA_KEY_VER_1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
Omtp+lCaqUx7Z4qdFj2zrN8LpCkit2eX4hlMtig+ielGm/x4FSZkpjoFmiqdKFPi2eg0pg09MSai
XyGH68UzAR7Xrj8f1jlIoUmMKp4GcxfdqfTeuu7kWGOJEP6cvgTjSJFj2gawDv7f4yZcltnK2x0L
e4GW/rBTmGvZtKWb2ahjINLxPuh3dDaSaWdb+zVgbtyrI5FrjxBkq+aOxSjyNsqnCx1L0uWbxnkl
88NbXN3dTaECXHNm/fsleayM5hKis7kTv9BFajJMGy+BhQlmIYpE+F5zchnTTFUFJZCz1sX9Fc8e
HcY7irB8mR3ajdzjUZLBQEMktp096Nheq3U75A==

`pragma protect key_keyowner="Synplicity", key_keyname="SYNP15_1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
hpeBLwN9x2ZFDwroYLlUe5GjjDepHik2l0c2s3/6S7JPCRkzQSyt2V1Ad/JewAs/QNp5SXSbYYB4
rQl0My1LDMF3xw43r0g2IbcyHVpPhGp0W5msuQdF67afnsRv90iJYWLMI3QkYGCTWAzl4HrLxFSg
3z8XZRK670IcxznOrlvgHmIKsvubZrBkuc1EynrVb9Nw16QnIx2rc4WgcEXeFf+4i1RoYLDd3gXK
NFCNMdtaRYUThunFP6Z4ViZ5UnDmKq+IMhd31jTaqIlWOBDxPI1+v5RJYxIyTbn4rxlKR2fNbl5/
z4OUjBTd+1GH3I2OXlqmAOvIhpe2Z2HH7nZu/A==

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-PREC-RSA", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
Mt2RhTSUwEIEWeNARbyL+EdfS1UF6nPaL/fKl/7oO2gina93egwCWDLl1fbBtkfaPco0cu4MJ9K3
OraAsyHRlY+MNShmJ1LzAIA1LjZx4y55lu9dlQqSUXR7AW7wVbkg1864mK+hM/1XygU0jvebKNW9
B7xSER+asLO6pxi0mt7uC2PHxLPAYEszFhmnap82TtbDGdQ2qtyekY+ngs+N2fAdsblxVwJruiMl
e6XJ127M8N1mYwhWU2HtRpBOSnnKoHgD9fG51XK/rhk8DxT66QnX9uLPB+H25eDupBJGi1Y5o6x8
hOwZiSUVlBLh7brfzevh7+eRn+7es6wBas0+3w==

`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 76, bytes = 18992)
`pragma protect data_block
eNWAN3p2VPGpQnmEfeNsD5JHQvqe50zgh19ufFM2nvGnjdsCrESRgvTLxgmZ6SjPerKc6FSxWu6D
jMW7QVXwhOiRzUR1YGGp9YKyXK8YghpEV38wKtEjzfclZ5n3SiVwJD3OCmmZlT7wgPrfzxWi9oIF
uXbZbHy8QpatCv2LH+Rry9TTJCkWY1hcT4GOrWVIAQ5APXwqBlomXBxR00xgRg378izzpfTmsnNz
ZlTHj09dVHY/DQPeSMAg4GAyqnQKrUcnTTlz2Adiq6DgDlUmN+uLftE28MxjRujYx1N7dz6wipOR
ygCa+gOJn9EVSqqRn5LVPRjdefFVqH3CouwNsy69oVxUFyjijYBYN/4irnMCt2Fh+MPjaZsICjto
X8kZpSQC6O4eVm6Wc/SwM5QVYu4C4QT5w20j2sPfT9wTqaqPgjiAnd01HJxtjPzw3CFx3ZKyOilN
Hn9Ofpxw1Oea8oVUkqc8GJqXMHLO/QO5lFmbDthQV4wR7XI+7kZ+KYYyIbcumMPtRti5O5h5nZo4
yKmzoqfKqBh/mtujD6He9zaQiMMo+q5d3sUigUYRnakuaZy8HVVhBHCBFT6pfpRjN8XyBn2V5ovW
82E/u2dGKwpjSUIEalLI2Oc85qNewxFtbp8rFyZ6cI1FkmX1ADtd3hJJULP0MXZE7l84idQUnI15
UE9uZIXkv8CSlmEy9tj4jfI5A2PbF0mL9LmfTk288hS5yLO3DWEImS3VwYSSEJ0AfKr/7uvs2aSH
ccwKxeotMuoShLnAE4UZcdXE+o1Ut4r4yiO3N6teR+BUJ6dTDTsDb1FqX1cjQfFDF7MSxCWWK+Cr
9lRY+cqobuF/EEZ/kwh22SmdBKaq6X0z1fbtmk6QIEa/rHD3JDWqTurVsy4Mkx2Ckt0wtxPr5S5U
L0xKQ4cVOCKVWUNWkFFOQSrsflErQDJUWJt/u3CQ+8TP/2TtRbvZmdT8mmqICk5AF1KlcU3Cr8Ko
NYYlMQSYSevnU5CXL7VmqfKeAceiIBQVwfu6jqxpn0iQCGiVbpHmZ6AHY8l9PUD2vgtfzmOzYD5S
0jhOdCfjprMmGdenRh3ItapyeDNsyvtkwMO0SFrdKnT9eKrkwb8F/SuOJD9Ov6wbCpYm6pQDi7j5
Si2tstmUI18UeRYxavY7TxQs/O54mjROxGRapxJd4KnNlfkclcjHmBzkmgdGkeojE47/u7xXuRfX
u4nLA38priZq6P1mgjdX8/E/RFPptSqVyuPqYL9Poc99Ji/5wZjhI5kbEEKKtvcUzsWIWhQx1kZd
pU4SbqqJ2yJNKXWoB6fhZgu3PjSIYVSO2XCB2Me2A97A0CndkxlRF8j9SzYFdDgReI89PpfymKmQ
5RV42K8XUl52MFqrkMnRq+lDIENZSqvr+T6OuZRMJd4HyWQXbTCDbOcR+GP95TGeWn6qQ5gqYerm
GQTQusyUKmG7fJQ0A5N544MVF/demW0BJpnA19O2kaQizozZsM0GB/gVxbmpf4f9eae6FO7nx7Xs
yawIOxXEppn7JbTAySVCZ14PP8ikUtj+x7ObdE1WSLTaWjkZADcxh/nsRypOScamcl/Ylh/B2thq
YYjhm1jWCzb68AW7hw0hyDeAZ/NNv7wzFfHO78+YemeO7MQ+v2kXw64A8ChOJ416OK3YDICPo8HY
CB/xNRUTBSrQ/g3nEK1EJe+rsXWgi7Hm+tqQbfKRArVET8KvY+wLFWIoxA1nvqQqTqvOLtiwQzxF
vwK9K0oLq0NyPIXGK6Yc16Wimg59KWr7lAE0A3SvrBIBSqn38XLuuIlAFw7lpyP9RVy0Kmv5LLfX
uQ+BCbzMqME4xGj64rn29zKrL9h+176/FPzOC/9YV9hUc47UOI1rkjCYSeNm23c4A7Pw8DXfzAMo
YXoLlK7s2ZVi3zF/qvofozfzmGl+ql97BawfGHGPAd7G/yAa4cZS7NQagsfgkRWihmY+hh1WeG/z
NcVrw+fQhDggcP12YCzqqEvrF4OvcihBWWYDUQYS7QI1L3dnPpxt+2lhzA/b39plFZ3iUClQm57/
DYUvsKA2t8sjHz3kw4QyUr8iycHUQV5c0dmo/ShgTQLeHt8SGOJ9t45qKnyHLssYIh3XJjCA0Yfw
lKLkmwxImsbum6PqqS8CF5uQTEJwVlZyz9b743liTfuH3Hs2KCyatAJX3K/iYIflYGEepvI1GFYE
CM5R6hiHvUeXVRwbVpGyTQUT6V3nUvbs0VOCqHRVzRWv/3AeHRNkCQhSj4nHkgPhftgdP9/1UAVS
9MQVWYi47E0dhIpopwLiY2MQo+Ya6bnO6e1z/0nF292RGThkqx1CJ+bBnGQt3MgEk0gGNjiYIUg6
SrbjgQNeRB+8ErqXk5pAMKcTZYSEtVt627K2RBdtzIlnAyvNplFQgJtZxAlaNJyEECwgofD8UIC1
RDozCqFJ66O0K3m9qyj0quMygKwNwLDkr0nYoBXoyLLwmCONPNqnzWA00HykKIGF6aWiIe8mNB2H
+AfQ8n/5gYz6+aihuEOb4jLCQrvLcjGScQ7NwHyx4WJvueQ5QOUz4amFE47Dvnv+CD676xMEvJkH
6OrgEHHlgnkf0DdhoTGPWs1BqGzFBPvu5igl0olXoW3F/ndt4DLpSr/kkaKiBtxmTNP3z0faXk8h
9CfVbk9qhRN5niaIY9bcx662mK7swIXY7zjZyguNXnh/iI+hVbsRDrH3TFSBnKPBuHb4opouVnaC
xu8hkHBKD5Or7NJxLkq2LXAI9XrNCdccsMFipMzB1RItM9o7X/gDycD1t7EAG8tUQxwmqxBXfFnu
+8eoRAwk89rCMbmsB8RR0o3pjeg0p2sdGTnQsVINYS1Q0VkfOXTAEiZCkj59fOMAABoIBuutc65r
Ops5MlzAiEuSPSf3Gj0p+LvImpndn0hfmN0Hj4JQppW0XoJeyVGJp6qDkkedL3NFBO9agcYYk8wM
n+JIlbou7Xr7TKf4y8W6+yKoGqx18eA0SS6EMdBe6U4V7UAwGqoOAG8Z21t8fX++FCIeSML5QfP9
tToMYH4P7NASf8uD62OLA78bSdFsn2YGvXze0fmD90ocsa69VRPKdkoBTTW/BrI3c7JqNTTO2Eif
Qg62J9W+q5JG8FLmUy24MPCDhFZ1C1VzvsRzKHwmk2CY1mbfvf2JwVHBrImDWoU3ZiPqBNWxhP0e
hMQuRQfkzODo/LuaFgpYwSvlfwH7T4scIUZcNcGOlXUqLciEQHEv8tq2J2yVUw5tc857MuYwu0qa
FdEFwtFsdv/i0H77WopDxMQflw35EDqBVtsWKaPrZW3jZtJaz9AHwIxDSsvoRPTYw7L5pW2yLtrf
kPhnN1AtnqCcuWlCelJ9+jy5SETHMl+qAEcUfxqLwryVc0pxQh4etPC2lbnh3lGnjQr7eyjo8tj/
VtUV2EpMcSdS0Loew9yujqq2xrmJ9hPZIjgtntApHcPpfECZTq2erNDAexWpFkFXxemvOvF/Cfbh
4BFMofEMpnbsSMN/3sUWAlbjt+BsC3YRxzgXMiJIPFooB36bYhJUd6NG9+KXNOvmrVh21/a57pFl
eKaEQfLd1kaFkR/1lbYnFq+JJv9FnuYPvvSYi50Mf1qk/JLRa7fH02C9VclmesiAGEEo0UXZi9QK
82blA195A1J1MCIfndRKgmhU34oPzZpLSHKruo9kw3zfDj9ux+/f5pXsK8dMaBuYBDGs/PCl0Wno
qvSYtHBAfKR0s5eXQle2fD4cbnFvmeHAZ2ULMNIc5fc+wut/v5VrDJ4SSqyX4tANDlos8p1JhEPZ
tHoUIDMaW5oFUwyhSSE6kNMv7oPnlfo6bg8PgsJgMpWhQp9LIg5BFIxoOGiho1zl9qOT1vrLzkGw
xvjbDshyV+uViQGw7xIwn8GyhYSMqIssk+WBXDgCtIFfegQU8e4GoQximZrQpmAh4Albz94FNqYE
Uw3YX16bSmx+/IozeQUGT8l7y/p9QuP+R9oXY/1MSt5P5K6JNjWDRrvEGpOal8zKq+1K9MojPnGg
7rQTjOc1Uj51QVQHu8iBEzUujOd+nW6D1nt+T5KpBVsGkURy6cQA7YoayFXq39o6FHCNwrSCmzPV
l+k65oygMfhUZHFS68alhi2i3+h8I4gahon24sEnqFQ3kt9hUO1rCb3SgMhjifFU2F96C6U/vRsP
hgL5ORPlQqS6rEb3VBLaZfmfPwFPzc+Vct1M4wet+I+qWH4UPh6LL0oB3VKPfssbrAk3PZRFPgVD
aUHa8e9irWLLWUosVzLcNgYbt09UTNnGAs/gG3AZPi/veEl+el2OA2OXsNEIaffhr8h8GpW5/vnM
obw0mupzfpZzcHGhL+T2JVyYz7mthhBjWsyBqtapL63yW2DLmvuZgWwPaDFiUtqzW2XgeUbQ4nJv
AmLGwgx4A84yBFEsGcQAKL9QtF0ypa0/dB9qBqGDB1ICvOMGJR0/a2GBH+Cc8ANY/sRjq/vpm9gh
3lwlUdBi3YkeDBAPGxu2klOsvGH9PsvAleecM23yGo5bcW7XkkWZILSn/NbvYWmouxv7NjIzVLs0
zpOgWEjOVnNC4lU67Ix7AjlnxrgIJBNLJ7Mcx0Lid8VelHE5w809qVZbKxgNXh0CxR6Br/RkKOOe
RWhlYS0ltChoJNGiebCExhM9+KEUvYmMe50RIYvj6KxTG21uQ5ZiYOxsR9rZYjl98yDEmAQ+bLEY
Zp/E3fyuUqctkJ3Xqph1PxIFsJ+jtFKF+KY+/CMu782gb8J16j+MYjN5BuUGEUW2zOY7dhIgAwEg
zu+v56iJPTRiZxD7GbcEZtoRW/X4PFntHLW4zJ44WN7KzA/rT32yPMqUUWKPhrFxG9Bm1uS7efBx
ToFltiBHOW6POmx51a9rK+SvzTvBIzJ+1YLNy7rl+2+DSbpUURRjOs/lz1VWra74b7INm2GJySDK
K0UTDoJDWPFGOwIouptEwF/EO03i5lseA/cTKG0EV6CMT69tx/f0tRdYEYaLPS58IXO3Z1n74We7
bh6MVeLucmXbL2kLXJoiYrW4aZh0FfsMwKmDx/B7vZ508pvG+8Nm+7RnG1SCPwoGLaKCqc8Xyva2
2sbaEKgoqMr6GFheMbLCzPsLWnx5efc8SN3qQDYbN8qHkjex7QwnHgN2oM9wS6re6fkB5wy8UiDr
2M4K5TM5hhH7E2gmhIIoz9mZ+9NaItTw2NFyQSKRb8CtNWf6mX4sIDOvf65x2Up73Yp8Qhuma1f5
MCo0IZFraLcBSXrauE8JimlzsnT4mxOF2eaamKXaBM0MXV30wvIq5EC8qAXZ5qLlVgeZE0Qzlu3P
z0h+jhJnwtph4TlrvkNDWh3j9Oq5I1mWAkKIuOMsCHNf71rudys8ESGOxb4p1ujOI9SNoLXIONTn
nHAwha7bBmGoc+nfWBplQH1WYm3nOvodRMDyodZwjcsQXPJNmss7feRj7Effw/1OK8anuEyxfKyS
IrLizBqvT0P4Zn9bSVocCPb6NsYF2rei0MsulupGWS1FtfPd7QvFQV9yJoJLGFqupnpZ3ttZxcCd
ADRLaZQ8oTSqk+/lzJ0C3eNkqxCEqZIHMpIzkITs6kxluTlnCk+XlBa6fEBVQ7x2OmsWKMCSL1rS
oCUJ00H7PegUiaFSPqaq55UZDTmIEjUYN5xNhUTPo8u3/oCTOIPM/EfIFE6zFI+yPNcIiTbzowHE
SU3VIVoxgJZmPzKvh2LfLQMIuX2CQ8XKOnxL+dJeovbpOx9EBJt2Aj6ikIYilpkm9idpEULDNTZq
xEf2K6Ccq6I2dyIdzkTlu7xQa41KPvCpJNbQ5LCDfbb+IqiuCGWEFvYHGK0R2iRDnr/s8FTtwB33
KoGexvpoJW1OM/hwy+7ygLH5xcn1MMLif6M/ZLx3KnepdjZ44MEocrd1Zdako7sYwOC36nsWYvjg
1Qk90UAUwpruQREzj6h7c+qwgGxl6eoyCeVg/KlbPYRVBM3MJ5CErFnjiygoaKFkhLZhSYLrMY0c
MV87v3KJ78CjuY1gJD7ACZLoiA0F2ptqOFLWuOP2cQotOZ+RRa0UMLv9r4m6Vw08PUgEU44ctGfg
2Jidq51j3ZklrR1sSEK7cirC9oVAypiD4Zx9Vix0J08cdyRZVTEzkC+rP+dPZ2RbkE3BX6euSv1l
iPfVCe/SlYlqSH3QgJtAT3UU/kxTn28nAJhxrK0if6KXFl4LM9fiCsSY0jD+iEiNs34H77/47AZP
ncLI+R4kRi1M0EGG347IBScUUum+F4evspa4raKiv2GDROsqzYgqHPMHslcNIj6ZyakeZVGkrh0b
XW/QT/VIM/Op6o7C6HpPu7q7+GhkBAG25C19DX2RBrZDaO1eVXRfAWNra2bafvfzudGh8Z+HGEY9
i4OWS2/xCLauITUzmjz8CnatZHwr7ylYiETaeIpuZTh3jSAr2eihs3Rz8ZLbre8dsCA64RVNIK9q
2Vz91BGfLg4CwCWx61T+ooKpHbKR8ehO3HMAzmu3XFtj8L6V7sucgJXjAnlveKZn3zH01qRZ6+UE
HC0Gp2xdqK+L64Lpbeytoodjw6UP7KlhQGY22d9ijoEIuKxPeKMFV5ho1AH5Nf/FloocZpyjjj+T
iZju52zQMd/92g0LfmfjMB6D5oaF8OGUSxNcwTq+vn6jsB5080hjyHUu0ozyGEb18e7Cm35Jp6fa
B+J5Jr/NBIJpowa+banToON/VviF8Di0JS/GJylveNMP4X9Ij1/Eyw+ek1UWQHw4t/cGTRVZi79t
5V2LH25fTsNgzEX9QjSWlvB9wdHMKf5SsXIqVG0At6wWZsuQCJN+if+aZ3a6AAOsFlq+iljz/Pps
RlR3XZJ4XRUgPHgUdHoy/r1/C38ajvuOvo9Hq+oSKiknmrjq4DqSp0e0U8ULW0SOSKqtX+u/6dfm
Hgdv+QNco2QrYGKwfIxuPkE8U7a4bpz9OPuOkP81aX5mjZqdjD7HvnAe9ThWPKX6nBhLSL/QU/zB
U2zp5Tk8kQ2Kh2ykyW7fjUM+jXPEoueTKbvUcm1OEhJmsnANj8jIQrYJH3Vjcau/cI9Uleqz6U4I
0m51U3ZpkAIL8R84Vbd+qUiWnKHAHIXuIBVw2HnGoJxRthGdgZ4Lirx66mwjiRXuQNkcRYdE05mh
yBm1TzJ9TjeiT33/PGpBmBtrxWeUOakWX/6zWNwR5rt74WWJ3xAsJASsjuD9TuSkg6KiMSd3L0K/
/mQX1flFbwnNlMfN9VZH3oBUST65SKDHuulNsqckD1skuahCEuNgmhvOttNF6DUiehCTOHIE7VhM
iSklx/WcN+eR5QEZSfZfZatVTG+T5BXOBMPI4+ib77ngulmWP5VBUikENq1NyMzFS0dnRg7ryaLv
2QxVMFLKXmRop9cRrYIOsEtooQKHKVFptJUhJtkVFTbCiprYcihHJeSHDyPjah2/f7SMyaWUTHLK
ZbZUER62Ap/rVStdO8DEdp4m3hJvoSIZSojclg1mFLDPtaKKgdbx7PQ8qaCG7a1KyoX95GIYhS5u
+AvjDmOY4wcfXfG3SQqH3nO9JouHQF+aDNlzUYH6q2XfDgLMLIPQw4BKFFsgRt+g09vhhiep/SNP
DIzNEJvn1a9/ZFKGVzAt6RKUks8tL7fD5C8SMpzkgTOvcpW6nztqXX6JHsype8hYHLgHOJ0Y19U3
JWzohSfolWc0v/l9DbolpLHe4gpmGGvXGap/QQa8NchEHGpWnKBBlVmFsBw+2tSMG2+3+UsDw2Em
SxeBcw2yEmbcIhRbEbDC6UkR1JwKUb5cxg/cgsDcNQwYE4gAowGlc5lgfH81ZCuKgfa0FI1mr0Yi
jUQeMrEKA3dLpooVM5hUiFJyI596MMCxPOUd3PgYZ3GkE0wfXJnw2otzGHY8Pr5ZbJTVqs0ZiKHS
bUfcVtcElrlg0rAJiTTPCiUm5U14I3JkqSfP4fPg6lyObRb6NX/y2NJYs3l1GbSOcKfLhZ0y3G8h
Hx4jbA6w48TX/IOo3E8pCgsDNziK6hpzulq2KDjc44AK8x+dQRgX9LkFHtGc8CC3zBvtqQJZN2+w
tP6ISyFfsnxqBK8vFO8CL+ZMOK0RO7VB+0/NnzN2NWRHW1d7e+sR1MMxEKY2XYQxR4a2BbSTkwzd
SxXrj0OfKIxb4mhEjTLk07dVzaK1dWeH2KDIKVVF+N7o7HGU6z+ReQ7jSt5/Gd9kjjv8vxOMGzt1
xE9sDtSP9fLvgna58Yv875f6FH7s/Q6nzJgpF3xc8R59Q6tsBcfPH34Fry7iy6wD9wg1pcwMtapU
RN97PInP5nMPvQnnUNYLMyk99qVpiaHK0fr/3oVCC9kjz+sfCdWSqvfPjN0r3urkHbokqCirsh2r
2a9ZPwxStY4fvWtR9aVtvHnszAzTnr8W7w1dDuuUZJKUmkeHno/bvlrbPujYkj5XgpW2duV5v8tR
PFZXseJHfsI9I/k9fXXvGNlYYByNTFE4Y/TCNFgvo6SLYcLnMZCc0A6TsmBnfMvK4PAu9bSwrBZE
8yF/rcmA/VCbACT4KDIj9nlA66959yxPLRYS1Zm3YUhO3KFTnOUfJe8AlpwIUyMch6swAUoHizKs
nDCNk4qKNmNQeSQg7K6bT17XfoJS/5yg8Q1l3QdPnFfPa06+zwbkYOT3BwWonp5Jq6mI19iMMdyn
kySWb80ao7RZXZVAeYfDCZiHehcbpSEJcp1/EBhzPF03fJEkg7/bHTIrMwkhD4B/DlJJkuxw9pQ3
grefD5bkxw8Drb+QQXXjr+oER+l5aaQzmhgH3g2DfcCl2fobF/f4g2VCw0a92qo4D+VZztk3LEqK
fU/itJkYuVSnWN213aLhHk6FjIy/AjjzoSzM+JmfcLeOD16D5YfrRlRX6fnb2GwI2xZZxTh5MgNt
NtlWLisFHQLPcZ5/6867EOoLemXgBp5izfqPRaAx4iaWkaVfYQAyWl/1H/I0dBU5ftWNRX+wV+3K
Pd4zwdKwaG4cuOcvbz++jXe6zNTpejvxOK2wpESmT60XGnZMJaEGE9RnAoe+lFHb4pUA1ukD8GBs
tzYWP9bfBnkz/+KKdKojWZ2TYdfu70N9z4xlDOR1yeWSEecNlcgKyQuHqPkrcTnlqL/pqnCA+bi8
MHq+HaiEkTTKHR2Ll+BmVr0hHGj7EKiTL+E5LDqA9Vmr5zbeA4NTSt8YqO2a2ucAWCkdlkjVOVuX
XwselyZIgbK8iZ/ZZF1vlksGe0VMjPbvgvDWtCozWGmt+rJDzU6k4lRppkGRYXAntrmBTVSa41qr
QDf+kR2UZaEhYDt6Hsbtpfwv7JpC7iNPz9MYpnLRXDTlwdKcwmzNrcqwvZDgC7vm/AXTIxqoIwUw
PxAcFb8xVluJhvNddAmX4VeUSlJDpuBnAFOopohSBzNDSg2UbExf58Mzb/B03F8blLBNzZ/K2/Kk
QNwGiWz3W4FDBwRGqY5xSV6GvE5lk00fSi1RDAAgkqhiSV+yqiGNaLkURkujN6r9jDW51PyJ0z4l
X+npCYj7qKTDUmw9ZPCNCRf5sJa6yiuSgr0gZU72ujmk1SKfSFW8+Qw/WQ8nHFfMh9oG5b39RyRO
NbaYalZA32IDwBTA+j7vexfg1egexWHxDQ/3izMaO3a4UcDr35FErY8+QzKNEdLT54nXKz+zAT3k
aQ9SniivhRKfdGfSs0/qLGe2oHhBvKbi9rK31Mg48XFHGDSTTbShVjrdbrYvbnqeDOp4cdu2g9U9
YCUIC1yYDxVRYCEKQCI1/sueYpSZzve6Ymzw0WtjD2Pu/V7Vq9qna/V7cGz22A0SakDrz4Gev1/p
s6JncUE/hDavsbPbQYqnsvsydvJDGi2N/qOEMu00W65nLuu+q/L+DpcUoGLVGquI4znyjiANpA13
UXc8RgTFDlcWC/KOc7x3wpbmAfAjBmRddbW58rwKozip4xUF9KYITu4vacz1dMaDxkAijmYUbu14
zSzSv0pePTvMW8xLCGha7yv0E9sM9u0Y/yOZ4x5jQb8wJ1DwXNdcW8OFkpWVfnRkQG5xllKzS3Bv
NgwSFaDSGF1jhE3VCTzLvjT9Om0ud7HjQl3Y7g330k01DSdBGwAA4VIp1etqoifBNCzhL/d7Wgre
42flkghefFwJxOZgnD9kfPxTcqDmbURD2SZzxb7ljvBL2e15pg1X8ADGY04EJQnMrOItp16r3M3o
WFiWQMyy0sZA4affiQSwD1k4aU+jO00KVvoUVWcnNPC98k8O01/0EwKEqNKdO2kFm9M7cAoRRm/V
wBwGenjEv1bE59X5M8P+6Mq81+VRVXTI+o4tbjqm4bTFu6Orq1i9kn2DAzGzh7AJ6ucAPXgwxEca
im7u19CTrFrlmJDXwvn20r8iwiN3jrCbtMfVV2wRClF78yV3e1FtlY4YIX66nnYZQXOHk3w6PTpR
Yts0Rr1CndF472iN3yFg13xh/7r74miE6ZMe+SEsQi3l0cgagY2+swlK6XV7V56rZyFIag1ZVuZP
j9RoKf2IyvS6iL2nbdoVbrya8l8V+1dRpKcEijgfc5IOpHTyFZbOov4V1hTDJL+IoAR7ILJGh7/w
lCFJNk7SKYa+KXZdp/NiyJTcqHxonwaMmjzKUUdRYv5LIGAZlgPKZZ/vnrjcJrNXqGSqouCe9SgG
D3MH/wTFk/mRFSZvtj6PLodfAvprO1XPlWJHCh7ERRa+8c4Gkg4jM+gCW4jI2O+N5rUpE4nSwsnH
fBOpBfc2KCLuT6G9N7hR7sjzl1o+mAEfMC0fqCfHqSXH4FXQb/u8r8igqnh08OXvbpieJaiZrzg0
gxjkoCULAkBYHhq48Lr0bwfVqxmCaH3HGlExjhnS7GYeszgigRv5fQAU63744HArRWwIvdy7B/g+
L9A5nmGyEpEvoANH56ZUdPmOf9sWOS4X3oSREeottlvHEHcGMCbp1qY/m2qHftG4DGzGWS+ZXua9
gaJ7q/FfWjqIx3f1MFIQpmkRKOXxiCC8ttdB6/ldl+lXaCpXnfdvcm1jW/jUaC1FCXgF0Bg0SQYq
dgDdc0tSCG5FP+eZj4grXMLjEP6i6lhc/1lJ7+o0/FAvdrbbYml+2cvK5MfQd/GsKjZOuAn5DeM9
N5ssi97DXzDLTJccZh6pdG9WqqWEV8AHUpbrtKBBlorARSsRrkSo5+y3WLkuiAasWJ+RS3qTZOkY
cqygcESsO1q4AZmBU/51fUiUkgqCBUPN2PwtPzuoSLtDvjvXaYNN26zUotZGmvR8YywBIeApPmGA
rzQ3apkmWimBeJkqvN43+jaHWjiVfmJAMxOg9N8PSfUxLMExIS7IZgC2Z00S/T5Cbrk3jU5GNXjU
eCanc72/1meGbawqxBgCEfxiwbH6UvUmzx/4U6pvagaKxStriyWTFxccgF3dPYZM7LksOEZ/x0Bp
prD4f3WVVtpAWMCX20r8LOhlIAx83pNJovU9wMK9HHejxszZw1HsSzRTfpwmGe1LDwwRCKkcQolG
6ICmgrRTz0c1BLsbs++kW2juDcKQray28Zr2kRN8o0M4/qpFvg1O4sx3YLyWfc6t1mt3udAKEJq+
F5Kod89bI7wYiOZlRfviBrdZnseCiqjMKRWgAmNktklvlnUKRbcsLH+l/KXng/HreNpjUYswOqYi
JCAARpx6T+26kpFa9ycHCBBM16uQ6+7LSzSKrHgdQA3rUyLhX/BV2nvR3X/edVe8i+OaXNeU+tpo
hLtg3/bVEgiiL9e0dQe0w49miGFt5+zG8xoJvFzQiX/53GC83mgcB44LO2f68UdvPpxPqVj2NhVb
hOwnfDJ5QGl+I5UPo5HXaAE0h8lGMLL5nDnH7J5Q2oDkjJkznQf/jbJ6FQokVyWj+nlXxTHJ7hGh
gmOnJzUxWlllfEOUpJOzaNsFOnevcpmiGAoiC1XWynd/DkhMf2uU/N5TUnk9ZaQ4xFVWdruofoMZ
HNK0xBveI+WIxNCwm80XJ2Gfy6cG2QVTGhzvB+tIRq9DhM/G/C2FsA0LHtpEhEY7Akk9vNHjc5va
Ps6z17XR6LvnhMkBDbg5E3L1k7/rcElJfu2bY1JNGczkGnUApDyiLTrE4KxTf+EI7Xa5WIxb9KtM
wNGlg3pGQ/zjNXhfbqCznZI8/hysncBSlnLr8K6LuqMJco8C6SdIk0cLJXKVgD7t5emL+Mog/JHE
CLT4eKUqFsw+19eWsc1djYwAegx1b1gkfTDe4ug05icH+qCBLxITagoiQA8+aMOBColaMAEBA/DW
2UoHp3saVPhLJ1IpdEi8ucWbIchzMbr90xtSzgS1XG3ns05Qmeu46FgqTswIL+tXEAGxXcrczcuW
LYeEDqLhycmgn3BJp8pLF1n8Bvv9yHrzNpYpinAAk9G+/P9+zgXpH23Ko2K/Z9M45rPAm+ELutN2
7WLZ9ciMp7SkqrzuPeDdXr1xRpjBqP9dcwL+uuLr2YiWLCsY4guimJv8md+aSdARFlE28nH5e76h
z1d+cMeC0/8NhvPExYwRawlFuuoA8WDoLerbo/hyjkzr4gFga2JD8YHOLz+/kgbC/oo2/mt5lhcq
heeunF3ajfHYXp/HbUUkrnlJsnkcj6O9s+yj1ckO7dSSm8StR2ONXHWhrnd5Q751A+RO+MODmrun
0e6lSpoNTjmKAwVpkn/qOkU54sHt4j/u3ihYfeU2+IOarXjf6XOWm3zUTGihAMyRAZ0lM+8n1uN1
ITdAD5lySdxn5ySJT1QRlDV0bUpOcJj4xnOrESaiy6sLR6kp3u7fUf+7b4Rlf5ggdjAZCVDsytrS
hVUbmoBBHHG1fE/KEmll124jVHm0XvXBNxoQAoFOhHmBPmDhVdgVwp2Kjmr3Bu9jyIG+yraXsOh5
ZnBLDD0UxIVsAcgn5VM4ymjBFg9dkEiXlw6tNwBmHnc0aVu7mksrPL4pmRwY1uY/gU0qOyPoecUj
u5kHmXBqkIKPNa8tt/dtsK1kRwqeJ8Fue1BemjEUGxs3Np3g0rGhdUjH8x84JM/T4qzoL9ge0xdM
bkj1RFEZcDP9eqPExrjxC+3zKqVAbjS8wJ+lZGFVqmD28lD+kUcYAzRFIgxfoQjM/xhQ1JnohJww
uQzUyYKNzPBUs6ydpHp2G2UDAQevc4VoP8QJ1Y9I9Dr7CUq1CRMKe2CEPZLwyFrh5kJzQEPNqnuW
89PnEtGKv9Vw62k8Gyl2X3KHSw9iXZILdNGACrlWeLr/psE7EAbjKAppzjB/IGdvcZlntXB104N/
K22ilctO+diAdWFRAfSkDjvMhWM7jmdiQuaZQjSZ+uD/F8xEoffp6jnzYwHZ6ZKNETq4wrlQ2+7K
LMB1lpHv/kxH+rFOfpxttQh+smUKRm6Bg1jTIe9sJyqsXJySzOnaizDwJzU/A2Re5dXguV+NSRpM
6gcKTvJ2lVAVpYOyPQzua5ZTjl0ApCU/kG/LMQQvgtsh8DYLBDLS/hMm+NxpSU29tmCzm+PKkBkr
Jib4U1rAD3fAflZUB2k7zxYnHIUSnaBcTRfs1ts3c+g6Xz5PKsIJVNDFZ2NsV97ByfwiTnR2ouWx
BooeKdvcm5YK0MjqDdSy9DU9Bp1l3odFTCMTpiNgJm0ORRmleI814jcAnrlb+VhoioxHz4tCmifo
yMgC2M7jSsJ5zMYNnN4imnsQ5vIRB56zMLiSwj5plHn9xHPG4JICvOOoeVWc/d9PjsN/17h3hO8b
Vl71EmR8zYoDqeGD5ic3TdfAHJ5nrLM8MkPkOCTi9SC9PV3E/f1QJpQrK4tEcjt+a1wEbVH1woU4
RqiN6J75JWI5O6VbOdVJO3W+MkMTeH6FVikv79Ie3IhZzFN5Jvuxaznz44Q2Nkh8VVZaUke8KfkK
V8PdX2o6ArwrDLXqqG9ze/ZwU6ARxWPltIK3+vo5heW4VakCLXDPkIE7Z6mU06WZ7YYny6T6Ih62
Xc3bJodb9dZnEo9BOubfnCCVxqgCxDiid4+nWagq0PnqX722388ks0YSUBFWReaw3VJ7knuWzhPe
48RhfKEPxZaEZw8LtLx4S9sQtYiwKOGgtU/0XO9mTyhTo/87DG/5CcfkLjgMRBe2wqaRUH19kYw6
u/FyZ4LOK/mTeyjC/DwQWwJel0z3oueVcUq/g+H7kL26YVLRr3/vpxw1a6Ehl2ebRxDY5GORJwuN
Wc31Um7hBRpjsHy/TxcR/RTuF6g4hnTFe6Rx2M3BURS0qU0fBNY/Owwi9aWPxcHU9QQbt+6Z1+cP
bf3XYZxm6lR7GPsk1XRg/YdCMw3xZLZvYRaOS0djEP1bnsAbaBBAvjVRY+RJZPtuNCaAaFeEhnj4
lN8bxdz9b8JZ0MrUmewtxkHnCzx02DhTIY6eDqTr9fFdxweMxfs0n3LKL+2e5feTOzxFlcT94MJm
wf+1mO/P+RzC34KPAb09NVfWG7sKKEB68QE6Qd2WkPFo9gRtcLCxJ8LWYk+cw0lT/LZpKaBB4XXR
k919zwvCn62pjPwyyUjj8XON4PTeWpiVXAvr+Xby9GxyB4RPUBqB16LLCTOPhIAaR1SxqmBOI87n
ggXJQuah8dXvLvLNBFEvic8Zv5ULDXVX99+C+SQjzfuLR2VrhwfDWuwj9ee+5C3krc7eeaKmLqV2
IQIgZ41rq1ew4lkUuSWxk+K4vADUOinnJjJK3BDEUB+45wshxfgBJkPRhobYaV/vTT04JQE3VnYY
j4A+SMk+55485MrLbE/aTbU6DmNQvAwwCuY5x3TrFVbQgnuLCevY/xqfTmaJyNltkr0a3qHqpYpm
NiY26+3pWRs162OdcP33F4m0cwAeVtoez3avZUjGHz/US8ZF8SkRkS/6htiUQzBY7mYnevj5Gxgm
/l0RiONjHF+gum3i3/X8ptOIPxM/Jqs/JR3IpEOyMqn96uoELwDufoIid1w6WGvp3Wuik9EfoQPT
qo2w6Op+wkjOFOMTmhJroJuNI05uWA5XDqw5pqUsDSE8buxgX4E3rnNLzLJbT16Jtbaz0Vk0RlRu
7DmBaaPzzuoEEik8vU4bYF1zg4p71ybE25mxq1G2Xg4p5UEZfwUVF1xfz5zn5DIm8x/TTbOuvrs+
yP2NryvpnwiB93DzaHP2bMCsRvta7nV/UuaxoND6fn7yl3/2ijxct2eVQ3guZMKzBShNDgcfi0pB
b08iuFvpH4liOdaAzlxQv5tA2PVuOvXfZZJ6aDASCIxtZw5rL8n6UPAmgE60F5ktN6Nrm0Qdb2h+
C5jbYFWhKKxTUYrPSJdvrNmLybm6o/2nhBNy7bTozyBYlMjIZkx0CAY3jRevzEuyFBrQEnWrQfui
aLLVJ/Bp65ftn7DzfS7eu0lUFXxTp4bk7o2R9fyMpSAAEf8KBHfjPcjbMWE3gedS0XUb4tLiBYUj
pppEBMJAVqK4YBXKtPRwj8zRvHvMjD4uocErp9fGDGUq16ycrqr2x+C8UNPkSi2DjvRRULUnCVpx
9bTyiT1XGsYlIXn9ANRCDjZoWXTh8llB6/fZXyI34K3YDkp0poeQM2kUSXcQH//oJhXauTjcQNke
00P1N1YYPnBBqJMbc4GuCNQW8/sCCGo/pYt7msI7zDcfc38lhiZlpPaRfJ6sdUzbvLMcwEph28V2
vzLL2FKACW2xCb8CvHrr9fh7JajbhR80u4szbz/0LMDCJAnKtiNfU2xEeFSs0eavdHiR1KY763XV
OZlBTlAiL5/yMXHh1rRc7LfUzE9l3ba5bm925N9aHuaBxhe6PkPIVWDEPWf8EvWEHUeK08HWLztg
ICQv0WWWciE3v0WjZ3NoI3p17U/PD/wHMZG53swdVbItlJ2lqWE+7wUAg8naPNVc4q1Phe5g1gzw
hPhOrH5y/9sWL8QiXZ/n7n17K31whwtyPYPbzIEknVhdCMnCJ4k9ucMOPHua2j+9Y/YErURzXIyX
EJ0iS3dVE+jGM1KqgBBdhNnyffUhcV2ebQlqbpIcHo6TIl5CpuNfZHUBS9HvYyQItGxCcaIvRLw4
3XlFGptSB/Q/e3u0Y1yS7fjEHyeHONiqscVYBAyQlmG2jTUvxZ2Ob42DKVK1b60y66Q9oI/gKLFR
eaUzNAWl8Mo8wbqJwROrALs11ca08A0ZKCkEMv1cI2biH38aiKQKgKHeUG6EFOfHvf/vqCjNveWv
Ob0koSDBSvra+TvAtGhdhX8WwmZU6sRZu+287ksJiDzKRuq0h+xXW3wkm9UkVoDCMQWCQ0D1rB1P
26hMI6iRpvUkZ4bCS9jH6jQ2tuXwjlWHFPk3hSyV00+2y2P+bBIkzDXcvaJnnqkrRqu8xvEmNZPm
/iI3+n0pGwsE7b7T1jci/rVXYApiNTvCvBaqzmkKBqzua32XFefXsT2mxlow8bG6YOc0Se1zVfTo
tekBgR/tZ07ICUIort8446rXrKBwopvxTwKSD8CuZCyCact2BcBVUUMNZNTozuyj0WABPp0nzYm9
48RHIucnAklBz3p3TXEZEYQVC6zrYb93h8ufcAvxQZOvjHaMl8EHmaIxUycD1pn6imyf2dUUaksW
vacp2eNYqZvRWohHhWgW/gTYAJb67SRrK9VENVw3GwIT9pP/m0cKWVkKyqhDtQSWPYzWEFELaUss
X9bnKO4a3/veBtyVPJ7oAjiNlqnm1uFWa92E1hQxYfwrycNcFqmwlHG1WbrN5zpJvUfQjQ4DXIsN
H0ipqU9QDfrS62RVKCVmHaf7EOEz5+dUJ/EVE5/XBy3QdoqNANlJPmVaFkmyoVU1z3XmCEegnO0l
ywBLNAzlf/Oclq12zgPfHpyJ6MBnBD7WvN2QsDVSXxIpvMqf9hzLnGeDesY1r4EFXSv47ZcREM94
S0ZuV3PbB47Ru4cUNIr4jEtvSPDldho5ktRVxRmLNvJ4ULC6rXMjN/620YNprJhfKlceW1KxfL6a
O+WQgUMms9iJ0TfXLmQSxEnqTmTzbgQB+ZRX60kng4p/H9sJRqyWdjONh5j0Y9Qo+i8Xi/k84mmX
+w/StQaEmHiDa+zEv5QgzUxtxbFDULkcsrn0UWhPhk7ZdVthDG8My9cZ0Scdwl2ECnUtYaNODxin
lzsWK9UKKsQM/ipVnncxGC9jLDZEMINdUbWvbIrmrEVea+q5y7xUViS5IkNGL0PdqI9XhD2GDlFL
cDmOxeNFz3Uqa0M/ffyMKBLxblMG7LlFp7uUxbrQMRAgndZ9ks0iNNYYZMolaSRcYlCtrTDHkHex
R1NeIn5ojHE0/7d7WsE8W7zKd4dtypUQ3cRiwV80qaXSQfzJWAuGnAgv43BVJUK0ReVAYuwzyVmN
+6eyWTr2AiJ/ng+uHeOYVmvR+Vcy4Rt4eqdGMH3nngA/F3qJ9EgKpVcJ2A3ZTSF3U7/mHt+oULfl
2gKokpwjoaiHWpiby8cFFB++4L1ipJ6ZibO4jaOlUo0/Ja72+fBSGsvNJXtw8JOQdScklr6/iMej
swDSqmjtzuINMANT+a0+/RyJCS12k38Q47C0e+/ICsB66nUmngoORtnGIeYSeiQrqqC2yfyeeKgD
NVpUTzhdMG2L8sPJfD4Hz+WQiawzx3uIjmP35oS3Me+g50VTCb7W77AEt6Xk5SA9XEkp6dL4r3Mq
rHFaPabsHzbLptcprcAQ+QSUnCHgsiPlM8TTefQYGKAvwltvKilLvxn6UqCCqcQSKSxRB8ze3V9Y
NuJGnY7YIsWXYDsXjPirE54IwGsjyd6lg21eJ2VoF0HlKfXBEc0EKCAv6fiJpyFYrOH72xNiY467
MiSKg1ao5hsvCBxqsHI+y3mG+UdX3EHDmE354WGjqZGIffS2Ut6dDGgodADMScIPBRchTHYURUpv
E8lB89aTARWOIGwP0fua+r99wAf8l04XpwzG9M4MVxWFjHjxrG7/spgT2urTxg8cu1fjU7AcY2DE
CSuzEAZdYHWv6hoD8mJ3REyJ5/uBN5XXy3NrdS0hYhoBbbr8wd/2BGnP6p4iS0JXu8/APRAg0Gjj
GJ9rS9dW/XHG1I+YXG/pO0EibYKvsTh9GpUE8h43TeCsFr0FFCc5Pu59emaI/M3n0+52Pb2rbzCi
zVfktBvQElasr9YKONv1zvAD9NjkDCM9WKd8ccAepyon/pCylFqlO2kPT4y9Uxmy8N8ynOm6zlO1
BX2va74hnjL1qiQEsQGIZPpzfPaoTTphph0p19bKBJHn0yGeO4UDnONKwo2/ImZyNp7Z70qUQSIg
KV+SNeu2q+N+iSLQUCY26u2yFAScuVLMnjvdyyOdkogIiybI88IKdm0t9GWCptwXug5h1l1Z0ijt
9jFf5qniLnMo1pcHD//odc1VB0jprD/y6j7HxyuJ2s9S5bNPLVBkvXIb6x8CFeI83H6upzldweDV
yRAcfwz98GOrbWpJ8us+PRMGZpiNGNYD5jQsGQU1OXE2YV0d9chX0njmbathpY+FcaCjS3I3GEV/
IY0Hl6RNcChaA8gq8ObwDbknL+Omp8EE21KjIb7QoOthznZSczcDxGzWbmpvvVO7IIVQzx0TL99d
FF+DXSr0wWLNnIhfWQp+m211v4yzVCr/x87E3IXxFoYn7ebWZpyO4xGN7gwVH3hTyBT0s2U6ZNry
mOY7dacrTMbGAFNSh9FZjvqH17a+K4E4XW2QOS3s9L3OqblTrRS52sEcvH9IRGsWImDYBcix7pN5
9k3KZN+sMmQMSMtRlKqtNexFd2j982tn2nCRLOqeD8jAh2wXmLN7h32nLsjvqb1fRlsM63Jxnxq0
UpwiDZubwu5V9drqoPNUXuiQypKwGigFVDaw/XV+6jRnXE4Nm7/B8K6dnZsRMyGpsvquwVDrGjmn
ZVkmZT79CQ4Zk3BzuzFULAgGooT1erR24Ma5ZPz5P6ubkH2erz8cH3hYQl/veIGTS3F13cFbf/Xp
DizXNsWV/bc6BWcKakifF9tmtiRDcs6r5OWF/NeiOjW13geKJuVUuQmVzkigcUgZNyPDYamQcGnh
2WQgpsOJcedShSd1vQHHbXAy368F/hEQn0jizuhSDEbZ1WvYfTdr3Ad3q8/+j9m9PnEcVHpGXbAr
tl8VTmgaPi8LLNh5+OTsUab+1LsqXmxu4q6cjz1VPUTG1ibA5QCOVw4u6BHSTxeIEdP+BoW6mjzu
6skx0nAoVysMwxxLp/74yzJ2YIzEfY/PaC+7dM68fMhcw27UWi4laThN5JXib1Qhlkt+pSD7Jtod
vfRAQMH7Pr4fkWYmGqJ18XCeoXTpq/gEgG4AimV68IOHtMzr1CLL6jDC9ucX4rZZEF/08RZXJ/BI
fSRzXlEskAWkLHPdDyMlTGcI2yy1EAiMjLa0uVf6aVeMopTrFW+qFPZX+dg1ddcvrCnTurPJwNfS
kTwCm0x+QZl74CJRjMp0F1AVRET2PmsQ+tTv3DkncBJqBz8dViScMqU3BLBNS/t5yJno/C/xLvqE
TTJZDBfQFVNCMiCMp/wze7DfV/qAYG+s9B920tJPnOlTRT9lpkI4LJQfIi1WbIHYXwgwxa9a8ZJN
15fuxoV6a6HO2B+oJeGz1imbjRet1W6HQgsTbKReZpKcHGtZkbeAyEosQpVnuGBe4IZ2RjcyuSKn
1PPpFvHbulOstVcw11LfNOf02gpIPjFEmyyC6Idvx5tU2DiyGHXYOj/6A28OGw9H8+VcfCkHPKKJ
xcwTUSK8kePNiuHU6bkoLb8XjL7biqGM7zGyQ6MqtcnspxXfalpoq+tlAudFCSaT2P3nssc/wp9k
jDuRZiqCZubLJtZV52k0ey/UR5w6j7EdeyY6JKx2Pwv1NLwhp79SxXPGFFlZxAAsUXkCd5VGkqx0
pZZ9chSJ6g/YwbZiAMrSbwQD2lrPSilgzCfrDvaO5FnuzxBqPCjm53Xtx8ufaWHMC1VbzwWB8z2I
NXpX7/YjWWw0gli5yn4rhfFYZiRAAOOQBySNrw6NuQLoc/EDQAknS92AWQwPZ8Mai0Ol+OSJ2OWE
BwCAo448bySs5yTUkadHKhP1fJe3yBY9aakFC19LsviPV7e5zA6O2zlugyO6vzUSwKt8Lns2qn8J
rPXrB1c49Szeg2zKf2psN67GpDkJfi/RwxFSKYBNsC/ohRRTjXHUDa3XkQZqjRfLwcdpLBJ6Rs01
YrUZZzLO2ct38+Ie+W4909I87If0/mC8Edn9qim/UtaFU8UJorw8WSELZ0v9DHmFy3iWMPCRHnB0
cNkGeaIMTt4esHZ5HYjVIqteiJZfELztAfwSAWqcGUS1qiXC6i5E89h9Su22aOpB0w7Bwuq5Zrpk
hyhqKyD6VfRcEQNlcpVQJNvmi/GRGsxsS/b0KbTRMcjipcgAKruQRbTUKjeBj8r+W3X+6RlEbJpK
F0SCkqeaVhKEe64XMyz/LSa4ZS/2KOyavJhpTC8qfRl6S6Or3MSQZhEvgnD/JN+d9GBmTrnx6B/L
GIot3vLPl6KAwSKYMMBFMRf1WtJsPEJ2g+1pW3MLoBRouuMZyN4/1/kQgNZW1yiqgjOWdSShIoQ2
MSZ7+dNCtizS4K4oNLkL/Y19eA4Cr1VBHMHassJTaBBxo2IRBDdlhFRAkM5odxMtkIHQFthDfGcL
Ikhry4XvxrKJKex87XyrJceJtkWl9FPuDsHk/TLo1TKIo7xmL0iPjH6BtFkjFNLuE1UAYTPHAl9w
4daKbLQZ7tdAlJ3i9rdiGf7M7l3z7O5MN7ATZkJfsIAqBa7pqi6U1C8JsvbUDp6h5YIWqlj7uoei
A/QW3kAeK86kZYRs/IGYeakqZEom22qB9lSQcFxQ5ya0E2qETIESLrbomSmI6I3odlAfP3+22tkv
Kx9eAhm3BUIjzt0SdkwUmnh7Baf2F6zzyq1yiMqw5fUxOWgFsmDc2Iv7V+Xzp8KdubGZJ4UJxS9D
QYW6wGT8DuTRRLYClwblJl97LeCX0zAoRpZ0U3zJM/4nKW6bZLZrSEOzgFsQmXWiALSiFw0cW8/Z
GXpqD8CzGYhJauNZelyJk20P50HFvYdExmKLS1SIWO4a020MDC3JFH7QJLsXTazAxbOdUgh1MaCj
k609HgdQXGcSNsbg6Fq65jD5HxgpZ8IeqAEK6O+uv5HIMODJLKzusnmR3XVgkjjYXFMVUx9mJYdV
khlcgd06TCssJ3J6O+ixho4vYUd9A5bgnURTfP44SSseKADx8/6bx/0Unr6YTepPq0q5xYfP8yBL
2P8NVHs/FXOkyZ2tUSVJVIVHjP/moujgye8oIBgnlRcCoprpZr7SLg7/xWvvGmoqE6olZNqqLnMA
VDbTyseSxdmmm0Eh/itnCRG7uDkq8aRfBA2JbTSvJ+79U7TMGcFGCtANPt/igzMNXiU752kZxEa7
v2CRM+8UVgxu+saRzbkXSWG5Ru2vdS9JGRxcODyDnShPvx0RqmM4wwrNTAQFYguJDhCsWg0mtFs+
gqNUq/fp/C/puKD/0N1UDcx8lfXvJayI72YTMjdyHg7sQi4RKJZIB8YUgwJLrPaikap6GXOps4un
FpCd+NQXSMhso6/u1rkoO7Glx+Dplneu34VSkSlZEL2lLTqQPXMQ09D6IuO0xmhS3/1lW1NcbetB
4yM2sn3KkzQ6i4mNGBe4QvO71vmU9CR/PfR3z6pVhrnVr6NTSAQWztMi6N8FQTDwskCpW2KPGTd5
6C61z88Na6iH6YHbJnQb6DbAc1BKEWZN3CMVczObd31Rgu+ub5rd+6Z0JR4m5MAm2uo8AV/JA+RG
9qfVCSKt0zIq6ETZ+NJpF6zV/xV5fK+2NDGfAZ32kslGqUraI0XeWNu3VHVvZifV/I5O2RO2hFM1
BHKxElsQdPfeYOfjMyqw3RQ+nV+O2jsjwmwGv0uyOQcLZ3QEB9fbDly5cpAdsMxaf8MvRhLdDVVf
nXhxBnXR1ph7kAodifARYt335+tgjGsjR9wQ9aMJd4VB0n5FifVgnxbSpAGmMMWmei0VCxkKmx5S
OzfFgOQh37e7MDbNnBw/V6Cov/mj16CwnF1+ph8ALI7rcfwC9gaFwwERjvR1QLm1j9F+9CC+qI0S
JPr0IKqZszkcng5oUA7HsME4lTuWyRyj4WI9dijhIxCCuHkNB9yOehU3KU1pclPAnlCF/Wn/tbZo
s6aC9qURLsgQKZ6wVBm42V8id68tBUoCHNIGtgacYbtzPQfyr1te10bwWzcYmAYEoMxRO9sKmrSV
lweQdLOdiyt9C7UM/SlsbQmCSFo5N1+s5Wz3eAlWK3V9VEMvLXc3124aO1aJP5XAq9dOdBZWQtjf
fpQ/0YEELAnG95MTUwXgcxVL+y14cBtH19Uh3Hu1kXfiPDySAcPHfBPuWKDOSRMOxvEssUsN6MOb
/6Xtpp784wjaohPZ4zC+Tsr/EJIN7FbpFCSocujp5yTscWS2HRaCR9PIDLrqERBg1M6xSt2Ll0gB
rkCipIrPGsvdN1l6GA/VX/2LsKs/3guV3Y3w+Y2k2+gFzy2tMkGPhh1jPYshWGwTjMkBQCYq7iEr
UJ+Wnw4ZPoFgLNgWiMKNSXDHqkv5Vt24mEiqtPC5Q/XM8ad2wOVdD5wQN6n9zzfrQM0bBUF6zUTw
aSWElHBvB/QjgtCbI8tC4/7Dk945eL7ggH//y4yShwFHb7P25cX8x38IhxyP/guX4hNcDIPnklj+
dNjzvHR/wA3j2CFih6HUaFha9PiUdVF2mQ2Tgdoci1M0DK+EOQI0kkSpjqYbLQGV3sL03NKMYpUf
Mzr30Yix1XO+F4zfDTpYFyDM+sgt1Fd5vf/PAgA5nCVmGMTfTRLvMDgHRZWf3UN86E66og32iRJT
k+kxN01MDZuIVLDld8VZ761KKMT8bU+vEsKyMNYdXlXUogQTbFF4/4ivG9RF9yQ91S/sJ0Ev/bJA
SwIJpV/pHpsqx44VhAVbZyULL/zl2wq9c5Up/3ZYUc6OPZSbqbwnR5LxuQwAQCKJr5MobVX1JDCw
exTkmSH7jidSTrkfi/Trri7iZZa+pQZVM8Rs6qacdMYfxvdVhNPQF+UJ24v/eTK7xwEJeu11Pw9i
EUyCu95u/oDvTgGPl8lpNY+Hbxo4SQgQPQB6xcfcE3Yfb+R7Q0nlOwzqhMF5Jl6xDnHU2tpfvxqH
m2Tpr8JEECXmS9PrkGyzzvTbyQt72fkaD8xHm0Qo5yTLKnxx2CU4v9dQdsxBdT8GyiT2rnRgHfa+
bLGR0vTwuo1kQH04dC+iSIbGR8y5HsILzptjjtvOaxb2EPiyLp/4DZjFGtCAFCiTJdF/0LgUZxgu
x7RmKi8Cqy21Oy6lq4JoDUuaq0NLElDfIu0Q1WlsDWEO8kUpBk1yg17jukR4xgdK93NaHRj5dpow
8qZNS58w3nDPFisqS40cvgMKpLkKtMsLPL3FqDcrofw5G6zpCT2fZnI4xN0SnanAsxWJsq2i6BHw
T+5250+OhnEvBtw/JO80EzsHN+ZTwgaL1eNN088PIMjH4kNhTz8WsUYfwHZOKmFgrlb0VvsC0VNl
H4OGPfb4twf7hTRJl0V1rf4pPMm73pOwDjxWGXcnl73P+2lByDt5Yh2QC5qCmHBRH4pU8CxGc5tQ
2ctb6JvllvMff+HGwsotFplcGQEV+NoGEeVY+Pae4HWBI9Wg3+Fggck3N5ppSZzUooREpdvoPNW2
zWcBtov0LF0f2HUGeRCk0AaSjgA6lGqODahOYgLO+RIBONFZ2+H1xgThkqWLVXuSB3Q7vIKup44p
Tae78B911avmU73YXD4wrTMVAh743uWKw6v9Eqp9ZEGWXtSa1TBIh4WgPoPhEpCKjtAv047W4Kzp
c2wZbQeJEtShM9JmndW1ml8xcP/j2Cl+ym4hGJiy4Aw3rKF4WbsFvN0J90cs2lpLKxar6WDT+T2n
8DDUOQxhM6e4ADnOL5L17unSlzs5K5vkNdic3xOXbJ+eA+JqNYOSg/djZfw79/mY62YxlqWYtcu5
IiR6DrUTPZTGNG9DaZbememCi5SQPh4IvExXM7bssoVDIwaPNoidlmRvWoi91K83IbqKRPAE6SLW
64f2JXvyqOAmigtUWmS+G0otSFxafBybl9uX9eFQMWTsSnjGqwYyIA9xJAFBRgjwLp8B5di53CK+
TQfqEto4QZDU2IBCOb1f2fwwuYIkjekmqcwVm49n7kGyjS85UnkCnF28ckSvvwn7a8xBN3RSKfCD
LQOqUwTZDQuxjdPaCwdLT/He77NpSb8fpq6roMms14+MSbtxDfpsaYT+pvczaKKsRS+IQPSCas74
JvdPQFKLP6W/ZfAZ3FBvCXnuS/6pRYDArOZrz5BXqLuIS+7tJTJ3uGmwkCZKTymOZ6rN34wz60S+
4eXQsymhowYkHCLaFvYJRIcHURR7EHGu1IY6pflxc6eEnP6URs8xahCt0UyAHiP9fbutcVGYeVLX
SmYMTUXzMWHOOvz56akYaaYy9+5hsCNphL4/QE3mPZlevfO/cCEW5FrEjSN7tyd3W2ZZfCGiBTw8
8wTwCQPIfL2Era/Qi4TdLYLsORA0gjO9NeBk50gNPJAreZOwqtMw0KmC9H8JjmgryP68uy2yDJcw
ehg8punPWXxccDW7Tet0fqLJlGT+T7om2f0V6cajvjsODf2+2Afi2yX0fG5IJCm5hwr7rdS4aSP3
mNTDt/LeyESaNb+5FaRuqfMzAw1FQsLEk6yCV8ax3KbSCVFAYsIesLBtPoJfNdTJqMzpjGXU2WYA
eJED/LthTgRlavMzsqhdgAYERcwBuqq2jHn8sEUrKNTQzNq+kDb7grxqEeCbmGJ7TnsnaCY/4LEe
ofXcJC4NKr54ACBMqGWu606LInOX3JYe0ii9x38x0Q0hkfNs7d+3RUed7E2XI/48zxpOg+MzjnCY
qX90muuojLyM6VSp4fITVgLRn66uai35QBCqMmFOTKCZbA+zSxrykz0QjexKG5lyDRMNAgNwmr+Z
8WI5zfBUZlfPk/TM/NU3j6FY3camnCplROxdtDB4SVRgmx1ue7GYwSJR3ryi/uhHQpRruEee1f//
PjjKuSsvyDpvVgR7/WynOgndr4H0JtBb2eyMCR7W+eftrP4eaGn8Ig/ceP9+CGiHpmJac6vuORR9
y3DA+xKgJKDgK0guZ1qyXKVBle3SptI7T4k192y0S6sfg/pSLirQd8Fn6YicqU4YnZPTgjo4ftYL
FvLq7aRn2NlG2D+f6Bg469+7T3dUL+PG6xL3XXZ05ffx2z4+BqMRHmCYXdMqMFnt+24LczNZXjC0
eLHZVay5pMTftA9Rxwr1YNoXSkmbi7xmSEEqMpeVoQ0iEDd6E+q+OJdad1BCPR+Sv07jd9Tx6I+v
yrcN6BeSa1GygzV0bDtv/xJuti63N/MzpRPECf5Eutbqta8bNLFlT5MvAn9fSABrSR3vPmk0lDts
8JGVroM1bD5i4mE=
`pragma protect end_protected
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
