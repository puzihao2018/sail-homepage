#!/usr/bin/env python3
"""
RISKing Assembler - Translates RISKing processor assembly code to binary code.
Generates mem_init.coe for Vivado Block Memory initialization and mem_init.txt for simulation.

Usage: python RISKing_assembler.py <input.asm> [-o output_prefix]
"""

import sys
import re
import argparse
from typing import Dict, List, Tuple, Optional

# ============================================================
# 1. ISA CONFIGURATION
# ============================================================

# Register mapping: R0-R7
REGISTERS: Dict[str, int] = {f"R{i}": i for i in range(8)}

# Shift operation codes
SHIFT_CODES: Dict[str, int] = {
    "NONE": 0,
    "LSL": 1,
    "LSR": 2,
    "ASR": 3
}

# Instruction set definition based on RISC_Processor_Instruction_Set_Reference.csv
# Format: "MNEMONIC": (op_top[15:14], op_alu[13:11], format_type)
# format_type: "R" (Register), "I" (Immediate), "M" (Memory-8bit), "D" (Data-Memory), "J" (Jump/Branch)
INSTRUCTION_SET: Dict[str, Tuple[int, int, str]] = {
    # R-Type: Op[15:14]=00
    "ADD":   (0b00, 0b000, "R"),
    "SUB":   (0b00, 0b001, "R"),
    "ADDC":  (0b00, 0b010, "R"),
    "SUBC":  (0b00, 0b011, "R"),
    "AND":   (0b00, 0b100, "R"),
    "ANDBB": (0b00, 0b101, "R"),
    "OR":    (0b00, 0b110, "R"),
    "ORBB":  (0b00, 0b111, "R"),
    
    # I-Type: Op[15:14]=01
    "ADDI":  (0b01, 0b000, "I"),
    "SUBI":  (0b01, 0b001, "I"),
    
    # LDI/LUI: Op[15:11]
    "LDI":   (0b10000, 0b000, "M"),  # 8-bit signed immediate with sign extension
    "LUI":   (0b10001, 0b000, "M"),  # 8-bit immediate with tail extension
    
    # Memory Access: Op[15:11]
    "LDR":   (0b10010, 0b000, "D"),  # Load with 5-bit offset
    "STR":   (0b10011, 0b000, "D"),  # Store with 5-bit offset
    
    # Jump/Branch: Op[15:11]
    "JMP":   (0b11000, 0b000, "J"),  # Unconditional jump
    "JAL":   (0b11001, 0b000, "J"),  # Jump and link (R7 = PC+1)
    "JR":    (0b11010, 0b000, "JR"), # Jump register (PC = R7)
    "BEQ":   (0b11011, 0b000, "J"),  # Branch if equal (Z=1)
    "BNE":   (0b11100, 0b000, "J"),  # Branch if not equal (Z=0)
    "BLT":   (0b11101, 0b000, "J"),  # Branch if less than (N!=V)
    "BGE":   (0b11110, 0b000, "J"),  # Branch if greater or equal (N==V)
    
    # HALT
    "HALT":  (0b11111, 0b111, "H"),  # HALT instruction
    
    # Pseudo-ops
    "NOP":   (0b01, 0b000, "NOP"),   # R0 = R0 + 0
    "MOV":   (0b01, 0b000, "MOV"),   # Rd = Ra + 0 (pseudo-op for ADDI Rd, Ra, 0)
}

# ============================================================
# 2. HELPER FUNCTIONS
# ============================================================

def sign_extend(value: int, bits: int) -> int:
    """Sign extend a value to the specified number of bits."""
    sign_bit = 1 << (bits - 1)
    return (value & (sign_bit - 1)) - (value & sign_bit)


def validate_imm(value: int, bits: int, line_info: str) -> int:
    """
    Validate that a signed integer fits within the specified bit width.
    Returns the masked value if valid, exits on error.
    """
    min_val = -(1 << (bits - 1))
    max_val = (1 << (bits - 1)) - 1
    
    if not (min_val <= value <= max_val):
        print(f"\n[ERROR] Immediate value out of range!")
        print(f"   Line: {line_info}")
        print(f"   Value: {value}")
        print(f"   Allowed {bits}-bit range: {min_val} to {max_val}")
        sys.exit(1)
    
    return value & ((1 << bits) - 1)


def parse_number(token: str) -> Optional[int]:
    """
    Parse a number token which can be:
    - Decimal: '10', '-5'
    - Hexadecimal: '0xFF', '0x10'
    Returns None if not a valid number.
    """
    token = token.strip()
    try:
        if '0x' in token.lower():
            return int(token, 16)
        return int(token)
    except ValueError:
        return None


def parse_register(token: str) -> Optional[int]:
    """Parse a register token (R0-R7). Returns register number or None."""
    token = token.strip().upper()
    if token in REGISTERS:
        return REGISTERS[token]
    return None


# ============================================================
# 3. FIRST PASS: ANALYZE CODE AND BUILD LABEL MAP
# ============================================================

class Instruction:
    """Represents a parsed instruction or data directive."""
    def __init__(self, address: int, source: str, mnemonic: str, operands: List[str]):
        self.address = address
        self.source = source
        self.mnemonic = mnemonic
        self.operands = operands


def first_pass(lines: List[str]) -> Tuple[List[Instruction], Dict[str, int], Dict[int, int]]:
    """
    First pass: Parse assembly code and build label map.
    
    Returns:
        - instructions: List of Instruction objects
        - label_map: Dictionary mapping label names to addresses
        - memory_map: Dictionary mapping addresses to instruction indices
    """
    instructions: List[Instruction] = []
    label_map: Dict[str, int] = {}
    current_address = 0
    
    for line_num, line in enumerate(lines, 1):
        # Remove comments (both ; and //)
        line = re.split(r';|//', line)[0].strip()
        if not line:
            continue
        
        # Check for label definition (either standalone or followed by instruction/directive)
        parts = re.split(r'[,\s]+', line)
        parts = [p.strip() for p in parts if p.strip()]
        
        if not parts:
            continue
            
        # Check if the first part ends with colon (label)
        if parts[0].endswith(':'):
            label_name = parts[0][:-1].strip()
            if label_name in label_map:
                print(f"[ERROR] Duplicate label '{label_name}' at line {line_num}")
                sys.exit(1)
            label_map[label_name] = current_address
            
            # Remove the label part and continue with the rest
            parts = parts[1:]
            if not parts:
                continue
        
        # Parse instruction or directive from remaining parts
        if not parts:
            continue
        
        if not parts:
            continue
        
        mnemonic = parts[0].upper()
        operands = parts[1:]
        
        # Handle .ORG directive
        if mnemonic == ".ORG":
            try:
                operand = operands[0].strip()
                if '0x' in operand.lower():
                    new_addr = int(operand, 16)
                else:
                    new_addr = int(operand)
                current_address = new_addr
                continue
            except (ValueError, IndexError):
                print(f"[ERROR] Invalid .ORG directive at line {line_num}")
                sys.exit(1)
        
        # Handle .WORD directive (data)
        if mnemonic == ".WORD":
            instructions.append(Instruction(current_address, line, ".WORD", operands))
            current_address += 1
            continue
        
        # Regular instruction
        instructions.append(Instruction(current_address, line, mnemonic, operands))
        current_address += 1
    
    return instructions, label_map, {}


# ============================================================
# 4. SECOND PASS: GENERATE BINARY CODE
# ============================================================

def resolve_operand(token: str, label_map: Dict[str, int], current_addr: Optional[int] = None) -> int:
    """
    Resolve an operand which can be:
    - A register (R0-R7)
    - A number (decimal or hex)
    - A label (for jumps/branches with relative offset)
    
    If current_addr is provided, calculates relative offset for branches.
    """
    token = token.strip()
    
    # Check if it's a register
    reg = parse_register(token)
    if reg is not None:
        return reg
    
    # Check if it's a number
    num = parse_number(token)
    if num is not None:
        return num
    
    # Check if it's a label
    if token in label_map:
        if current_addr is not None:
            # Relative offset for branches/jumps
            return label_map[token] - (current_addr + 1)
        return label_map[token]
    
    raise ValueError(f"Unknown operand: '{token}'")


def encode_r_type(instr: Instruction, label_map: Dict[str, int]) -> int:
    """
    Encode R-type instruction.
    Format: [Op:2][ALUop:3][Rd:3][Ra:3][Shift:2][Rb:3]
    """
    mnemonic = instr.mnemonic
    operands = instr.operands
    source = instr.source
    
    if mnemonic not in INSTRUCTION_SET:
        print(f"[ERROR] Unknown instruction '{mnemonic}' at line {instr.address}")
        sys.exit(1)
    
    op_top, op_alu, fmt = INSTRUCTION_SET[mnemonic]
    
    # Parse registers
    if len(operands) < 3:
        print(f"[ERROR] R-type instruction requires 3 registers: {source}")
        sys.exit(1)
    
    rd = parse_register(operands[0])
    ra = parse_register(operands[1])
    
    if rd is None or ra is None:
        print(f"[ERROR] Invalid register in instruction: {source}")
        sys.exit(1)
    
    # Third operand can be register with optional shift
    rb_token = operands[2]
    shift = 0  # Default: no shift
    
    # Check for shift syntax: LSL(Rb), LSR(Rb), ASR(Rb)
    shift_match = re.match(r'(NONE|LSL|LSR|ASR)\s*\(\s*(R[0-7])\s*\)', rb_token, re.IGNORECASE)
    if shift_match:
        shift = SHIFT_CODES[shift_match.group(1).upper()]
        rb = parse_register(shift_match.group(2))
    else:
        # Check if there's a separate shift operand
        rb = parse_register(rb_token)
        if rb is None:
            print(f"[ERROR] Invalid register Rb: {rb_token}")
            sys.exit(1)
        if len(operands) > 3:
            shift_token = operands[3].upper()
            shift = SHIFT_CODES.get(shift_token, 0)
    
    if rb is None:
        print(f"[ERROR] Invalid Rb register: {rb_token}")
        sys.exit(1)
    
    # Encode: [Op:2][ALUop:3][Rd:3][Ra:3][Shift:2][Rb:3]
    machine_code = (op_top << 14) | (op_alu << 11) | (rd << 8) | (ra << 5) | (shift << 3) | rb
    return machine_code


def encode_i_type(instr: Instruction, label_map: Dict[str, int]) -> int:
    """
    Encode I-type instruction (ADDI, SUBI).
    Format: [Op:2][ALUop:3][Rd:3][Ra:3][Imm5:5]
    """
    mnemonic = instr.mnemonic
    operands = instr.operands
    source = instr.source
    
    if mnemonic not in INSTRUCTION_SET:
        print(f"[ERROR] Unknown instruction '{mnemonic}'")
        sys.exit(1)
    
    op_top, op_alu, fmt = INSTRUCTION_SET[mnemonic]
    
    if len(operands) < 3:
        print(f"[ERROR] I-type instruction requires Rd, Ra, Imm: {source}")
        sys.exit(1)
    
    rd = parse_register(operands[0])
    ra = parse_register(operands[1])
    
    if rd is None or ra is None:
        print(f"[ERROR] Invalid register in instruction: {source}")
        sys.exit(1)
    
    # Parse immediate value
    imm_val = resolve_operand(operands[2], label_map)
    imm = validate_imm(imm_val, 5, source)
    
    # Encode: [Op:2][ALUop:3][Rd:3][Ra:3][Imm5:5]
    machine_code = (op_top << 14) | (op_alu << 11) | (rd << 8) | (ra << 5) | imm
    return machine_code


def encode_m_type(instr: Instruction, label_map: Dict[str, int]) -> int:
    """
    Encode M-type instruction (LDI, LUI).
    Format: [Op:5][Rd:3][Imm8:8]
    
    LDI: Uses sign extension - input can be any value that fits in 8 bits (0-255)
    LUI: Uses tail extension (zero-extend) - input can be any value that fits in 8 bits (0-255)
    
    For hex/binary inputs, we just check if it fits in 8 bits (0-255).
    For decimal inputs, we check signed range (-128 to 127) for LDI, unsigned (0-255) for LUI.
    """
    mnemonic = instr.mnemonic
    operands = instr.operands
    source = instr.source
    
    if mnemonic not in INSTRUCTION_SET:
        print(f"[ERROR] Unknown instruction '{mnemonic}'")
        sys.exit(1)
    
    op_top, op_alu, fmt = INSTRUCTION_SET[mnemonic]
    
    if len(operands) < 2:
        print(f"[ERROR] M-type instruction requires Rd, Imm: {source}")
        sys.exit(1)
    
    rd = parse_register(operands[0])
    if rd is None:
        print(f"[ERROR] Invalid Rd register: {source}")
        sys.exit(1)
    
    # Parse immediate value
    imm_token = operands[1].strip()
    imm_val = resolve_operand(operands[1], label_map)
    
    # For M-type, check if value fits in 8 bits (0-255)
    # This allows hex values like 0x80 (128) which would fail signed 8-bit check
    if not (0 <= imm_val <= 255):
        print(f"\n[ERROR] Immediate value out of range for M-type instruction!")
        print(f"   Line: {source}")
        print(f"   Value: {imm_val}")
        print(f"   Allowed 8-bit range: 0 to 255")
        sys.exit(1)
    imm = imm_val & 0xFF  # Mask to 8 bits
    
    # Encode: [Op:5][Rd:3][Imm8:8]
    machine_code = (op_top << 11) | (rd << 8) | imm
    return machine_code


def encode_d_type(instr: Instruction, label_map: Dict[str, int]) -> int:
    """
    Encode D-type instruction (LDR, STR).
    Format: [Op:5][Rd:3][Ra:3][Imm5:5]
    Syntax: LDR Rd, Ra, offset or LDR Rd, [Ra, offset] or STR Rd, [Ra, offset]
    
    Based on instr_ld_st.txt expected format:
    LDR R2, R1, #0 -> 10_010_010_001_00000 = [Op:5][Rd:3][Ra:3][Imm5:5]
    """
    mnemonic = instr.mnemonic
    operands = instr.operands
    source = instr.source
    
    if mnemonic not in INSTRUCTION_SET:
        print(f"[ERROR] Unknown instruction '{mnemonic}'")
        sys.exit(1)
    
    op_top, op_alu, fmt = INSTRUCTION_SET[mnemonic]
    
    if len(operands) < 2:
        print(f"[ERROR] D-type instruction requires at least Rd, Ra: {source}")
        sys.exit(1)
    
    # Parse destination register
    rd = parse_register(operands[0])
    if rd is None:
        print(f"[ERROR] Invalid Rd register: {source}")
        sys.exit(1)
    
    # Parse second operand - can be Ra (with optional offset) or [Ra, offset]
    ra = None
    offset_val = 0
    
    # Handle the case where operands might have brackets attached
    # For syntax like: LDR Rd, [Ra, offset] -> operands = ['Rd', '[Ra', 'offset]']
    rd_str = operands[0]
    rd = parse_register(rd_str)
    if rd is None:
        print(f"[ERROR] Invalid Rd register: {rd_str}")
        sys.exit(1)
    
    # Clean up the remaining operands
    if len(operands) >= 3:
        # We have 3 operands: ['Rd', '[Ra', 'offset]']
        ra_str = operands[1].replace('[', '').strip()
        ra = parse_register(ra_str)
        if ra is None:
            print(f"[ERROR] Invalid Ra register: {ra_str}")
            sys.exit(1)
        
        offset_str = operands[2].replace(']', '').strip()
        offset_val = resolve_operand(offset_str, label_map)
    elif len(operands) == 2:
        # We have 2 operands: could be 'LDR Rd, Ra' or 'LDR Rd, [Ra]'
        mem_str = operands[1]
        if '[' in mem_str:
            # Bracket syntax: [Ra] or [Ra+offset]
            clean_str = mem_str.replace('[', '').replace(']', '').strip()
            if '+' in clean_str:
                # [Ra+offset]
                ra_part, offset_part = clean_str.split('+', 1)
                ra = parse_register(ra_part.strip())
                if ra is None:
                    print(f"[ERROR] Invalid Ra register: {ra_part.strip()}")
                    sys.exit(1)
                offset_val = resolve_operand(offset_part.strip(), label_map)
            else:
                # [Ra]
                ra = parse_register(clean_str)
                if ra is None:
                    print(f"[ERROR] Invalid Ra register: {clean_str}")
                    sys.exit(1)
                offset_val = 0
        else:
            # Simple syntax: LDR Rd, Ra
            ra = parse_register(mem_str)
            if ra is None:
                print(f"[ERROR] Invalid Ra register: {mem_str}")
                sys.exit(1)
            offset_val = 0
    else:
        print(f"[ERROR] D-type instruction requires at least Rd, Ra: {source}")
        sys.exit(1)
    
    imm = validate_imm(offset_val, 5, source)
    
    # Encode: [Op:5][Rd:3][Ra:3][Imm5:5]
    machine_code = (op_top << 11) | (rd << 8) | (ra << 5) | imm
    return machine_code


def encode_j_type(instr: Instruction, label_map: Dict[str, int]) -> int:
    """
    Encode J-type instruction (JMP, JAL, BEQ, BNE, BLT, BGE).
    Format: [Op:5][Rd:3][Imm8:8]  (Rd = R7 for JAL, 000 for others)
    CPU decodes opcode from ir[15:11], rd_addr from ir[10:8].
    """
    mnemonic = instr.mnemonic
    operands = instr.operands
    source = instr.source
    current_addr = instr.address

    if mnemonic not in INSTRUCTION_SET:
        print(f"[ERROR] Unknown instruction '{mnemonic}'")
        sys.exit(1)

    op_top, op_alu, fmt = INSTRUCTION_SET[mnemonic]

    # Get the label/offset operand
    if len(operands) < 1:
        print(f"[ERROR] J-type instruction requires label/offset: {source}")
        sys.exit(1)

    label = operands[0]

    # Resolve label with relative offset calculation
    offset_val = resolve_operand(label, label_map, current_addr=current_addr)
    imm = validate_imm(offset_val, 8, source)

    # JAL writes return address to R7: bits[10:8] = 111
    # All other J-type instructions have no register operand: bits[10:8] = 000
    rd = 7 if mnemonic == "JAL" else 0

    # Encode: [Op:5][Rd:3][Imm8:8]  (opcode at bits[15:11] to match CPU decode)
    machine_code = (op_top << 11) | (rd << 8) | imm
    return machine_code


def encode_jr(instr: Instruction, label_map: Dict[str, int]) -> int:
    """
    Encode JR instruction (Jump Register).
    Format: [Op:5=11010][Rd:3=111][8'b0]
    CPU reads rd_addr from ir[10:8] = 111 = R7, then sets PC = RF[R7].
    """
    # JR: opcode at bits[15:11] = 11010, R7 at bits[10:8] = 111
    machine_code = (0b11010 << 11) | (7 << 8)  # = 0xD700
    return machine_code


def encode_halt(instr: Instruction, label_map: Dict[str, int]) -> int:
    """Encode HALT instruction: 0xFFFF"""
    return 0xFFFF


def encode_nop(instr: Instruction, label_map: Dict[str, int]) -> int:
    """
    Encode NOP instruction.
    NOP = ADDI R0, R0, 0
    """
    # ADDI R0, R0, 0: [01][000][000][000][00000]
    return 0b0100000000000000


def encode_mov(instr: Instruction, label_map: Dict[str, int]) -> int:
    """
    Encode MOV instruction (pseudo-op).
    MOV Rd, Ra = ADDI Rd, Ra, 0
    Format: [01][000][Rd:3][Ra:3][00000]
    """
    operands = instr.operands
    source = instr.source
    
    if len(operands) < 2:
        print(f"[ERROR] MOV instruction requires Rd, Ra: {source}")
        sys.exit(1)
    
    rd = parse_register(operands[0])
    ra = parse_register(operands[1])
    
    if rd is None or ra is None:
        print(f"[ERROR] Invalid register in MOV: {source}")
        sys.exit(1)
    
    # ADDI Rd, Ra, 0
    return (0b01 << 14) | (0b000 << 11) | (rd << 8) | (ra << 5) | 0


def encode_data(instr: Instruction, label_map: Dict[str, int]) -> int:
    """
    Encode .WORD directive data.
    """
    operands = instr.operands
    source = instr.source
    
    if len(operands) < 1:
        print(f"[ERROR] .WORD directive requires a value: {source}")
        sys.exit(1)
    
    try:
        val = resolve_operand(operands[0], label_map)
        # Validate 16-bit range
        if not (-32768 <= val <= 65535):
            print(f"[ERROR] .WORD value out of 16-bit range: {val}")
            sys.exit(1)
        return val & 0xFFFF
    except Exception as e:
        print(f"[ERROR] Failed to parse .WORD value: {e}")
        sys.exit(1)


def second_pass(instructions: List[Instruction], label_map: Dict[str, int]) -> List[int]:
    """
    Second pass: Generate binary machine code for each instruction.
    
    Returns:
        List of 16-bit machine code values
    """
    machine_codes: List[int] = []
    
    # Sort instructions by address
    sorted_instructions = sorted(instructions, key=lambda x: x.address)
    
    # Track the last address to fill gaps
    last_addr = -1
    
    for instr in sorted_instructions:
        # Fill gaps with zeros (NOP)
        while last_addr + 1 < instr.address:
            last_addr += 1
            machine_codes.append(0)
        
        mnemonic = instr.mnemonic
        source = instr.source
        
        try:
            if mnemonic in ["ADD", "SUB", "ADDC", "SUBC", "AND", "ANDBB", "OR", "ORBB"]:
                code = encode_r_type(instr, label_map)
            elif mnemonic in ["ADDI", "SUBI"]:
                code = encode_i_type(instr, label_map)
            elif mnemonic in ["LDI", "LUI"]:
                code = encode_m_type(instr, label_map)
            elif mnemonic in ["LDR", "STR"]:
                code = encode_d_type(instr, label_map)
            elif mnemonic in ["JMP", "JAL", "BEQ", "BNE", "BLT", "BGE"]:
                code = encode_j_type(instr, label_map)
            elif mnemonic == "JR":
                code = encode_jr(instr, label_map)
            elif mnemonic == "HALT":
                code = encode_halt(instr, label_map)
            elif mnemonic == "NOP":
                code = encode_nop(instr, label_map)
            elif mnemonic == "MOV":
                code = encode_mov(instr, label_map)
            elif mnemonic == ".WORD":
                code = encode_data(instr, label_map)
            else:
                print(f"[ERROR] Unknown instruction '{mnemonic}' at address {instr.address}")
                sys.exit(1)
            
            machine_codes.append(code)
            last_addr = instr.address
            
        except Exception as e:
            print(f"[ERROR] Failed to encode instruction: {source}")
            print(f"   Reason: {e}")
            sys.exit(1)
    
    return machine_codes


# ============================================================
# 5. OUTPUT GENERATION
# ============================================================

def generate_coe(machine_codes: List[int], output_path: str):
    """
    Generate Vivado COE file for Block Memory initialization.
    Format matches fill_line.py:
        memory_initialization_radix=16;
        memory_initialization_vector=
        0001,
        0002,
        ...
        FFFF,
        FFFF;
    """
    with open(output_path, 'w') as f:
        f.write("memory_initialization_radix=16;\n")
        f.write("memory_initialization_vector=\n")
        
        # Write all instructions with commas
        for code in machine_codes:
            hex_str = f"{code:04X}"
            f.write(f"{hex_str},\n")
        
        # Remove the last comma and newline, then add semicolon
        # This matches the behavior of fill_line.py
        f.seek(0, 2)  # Go to end of file
        f.seek(f.tell() - 2, 0)  # Go back 2 characters (comma and newline)
        f.write(";\n")
    
    print(f"[INFO] Generated COE file: {output_path}")


def generate_txt(machine_codes: List[int], output_path: str):
    """
    Generate binary text file for simulation.
    Format: One 16-bit binary string per line.
    """
    with open(output_path, 'w') as f:
        for code in machine_codes:
            binary_str = f"{code:016b}"
            f.write(f"{binary_str}\n")
    
    print(f"[INFO] Generated TXT file: {output_path}")


def generate_hex(machine_codes: List[int], output_path: str):
    """
    Generate hex text file (alternative output format).
    Format: One 4-digit hex value per line.
    """
    with open(output_path, 'w') as f:
        for code in machine_codes:
            hex_str = f"{code:04X}"
            f.write(f"{hex_str}\n")
    
    print(f"[INFO] Generated HEX file: {output_path}")


# ============================================================
# 6. MAIN FUNCTION
# ============================================================

def assemble(input_file: str, output_prefix: Optional[str] = None, memory_depth: int = 1024):
    """
    Main assembly function.
    
    Args:
        input_file: Path to input assembly file
        output_prefix: Optional prefix for output files
        memory_depth: Memory depth in words (default: 1024)
    """
    print(f"[INFO] Assembling: {input_file}")
    print(f"[INFO] Memory depth: {memory_depth} words")
    
    # Read input file
    try:
        with open(input_file, 'r') as f:
            lines = f.readlines()
    except FileNotFoundError:
        print(f"[ERROR] Input file not found: {input_file}")
        sys.exit(1)
    except Exception as e:
        print(f"[ERROR] Failed to read input file: {e}")
        sys.exit(1)
    
    # Determine output file names
    if output_prefix:
        coe_output = f"{output_prefix}.coe"
        txt_output = f"{output_prefix}.txt"
        hex_output = f"{output_prefix}.mem"
    else:
        # Use input filename without extension as prefix
        base_name = re.sub(r'\.asm$', '', input_file, flags=re.IGNORECASE)
        coe_output = f"{base_name}_mem_init.coe"
        txt_output = f"{base_name}_mem_init.txt"
        hex_output = f"{base_name}_mem_init.mem"
    
    # First pass: Parse and build label map
    print("[INFO] First pass: Parsing assembly code...")
    instructions, label_map, _ = first_pass(lines)
    
    if label_map:
        print(f"[INFO] Found {len(label_map)} label(s): {list(label_map.keys())}")
    
    # Second pass: Generate machine code
    print("[INFO] Second pass: Generating machine code...")
    machine_codes = second_pass(instructions, label_map)
    
    # Fill remaining memory with 0xFFFF (HALT instructions)
    if len(machine_codes) < memory_depth:
        print(f"[INFO] Filling remaining {memory_depth - len(machine_codes)} memory locations with 0xFFFF")
        machine_codes.extend([0xFFFF] * (memory_depth - len(machine_codes)))
    elif len(machine_codes) > memory_depth:
        print(f"[WARNING] Generated {len(machine_codes)} instructions, but memory depth is {memory_depth}")
        print(f"[WARNING] Truncating to {memory_depth} instructions")
        machine_codes = machine_codes[:memory_depth]
    
    print(f"[INFO] Final memory size: {len(machine_codes)} instructions")
    
    # Generate output files
    print("[INFO] Generating output files...")
    generate_coe(machine_codes, coe_output)
    generate_txt(machine_codes, txt_output)
    generate_hex(machine_codes, hex_output)
    
    # Print summary
    print("\n" + "=" * 50)
    print("ASSEMBLY COMPLETE")
    print("=" * 50)
    print(f"Input:  {input_file}")
    print(f"Output: {coe_output} (Vivado COE)")
    print(f"        {txt_output} (Binary)")
    print(f"        {hex_output} (Hex)")
    print(f"Memory depth: {len(machine_codes)}")
    print("=" * 50)


def main():
    """CLI entry point."""
    parser = argparse.ArgumentParser(
        description="RISKing Assembler - Translate RISKing assembly to binary code",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python RISKing_assembler.py program.asm
  python RISKing_assembler.py program.asm -o mem_init
  python RISKing_assembler.py test.asm -o output/test
  python RISKing_assembler.py program.asm -d 2048

Output Files:
  - <prefix>.coe : Vivado Block Memory initialization file
  - <prefix>.txt : Binary format for simulation
  - <prefix>.mem : Memory initialization file (Hexadecimal format)
        """
    )
    
    parser.add_argument(
        'input_file',
        help='Input assembly file (.asm)'
    )
    
    parser.add_argument(
        '-o', '--output',
        dest='output_prefix',
        help='Output file prefix (default: input filename without extension)'
    )
    
    parser.add_argument(
        '-d', '--depth',
        type=int,
        default=1024,
        help='Memory depth in words (default: 1024)'
    )
    
    args = parser.parse_args()
    
    assemble(args.input_file, args.output_prefix, args.depth)


if __name__ == "__main__":
    main()
