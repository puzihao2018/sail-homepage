// Memory for simulation

module mem_sim (
  input logic clk,
  input logic ena,
  input logic wen,
  input logic [9:0] addr,
  input logic [15:0] data_in,
  output logic [15:0] data_out
);

  // Simple memory array
  logic [15:0] mem_array [0:1023];

  // initial begin
  //   // Initialize memory from a file
  //   $readmemb("mem_init.txt", mem_array);
  // end


  // Synchronous read and write
  always_ff @(posedge clk) begin
    if (ena) begin
      if (wen) begin
        mem_array[addr] <= data_in; // Write operation
      end
      data_out <= mem_array[addr]; // Read operation
    end
  end

endmodule