;==============================================================================
; File: program.asm
; Case: 1 - Simple Sequential Arithmetic
; Description: Tests basic ALU operations (ADD, SUB, AND, OR)
; 
; Register Allocation:
;   R1 (Operand A)    - First operand (value: 10)
;   R2 (Operand B)    - Second operand (value: 5)
;   R3 (Result ADD)   - Stores addition result
;   R4 (Result SUB)   - Stores subtraction result
;   R5 (Result AND)   - Stores bitwise AND result
;   R6 (Result OR)    - Stores bitwise OR result
;
; Expected Results:
;   R3 = 15 (0x0F) - Addition: 10 + 5
;   R4 = 5  (0x05) - Subtraction: 10 - 5
;   R5 = 0  (0x00) - AND: 10 & 5 (binary: 1010 & 0101 = 0000)
;   R6 = 15 (0x0F) - OR: 10 | 5 (binary: 1010 | 0101 = 1111)
;==============================================================================

;------------------------------------------------------------------------------
; Section: Initialization
; Load operands into registers
;------------------------------------------------------------------------------
START:
    ; Load first operand (A = 10)
    LDI R1, 10          ; R1 <- 0x000A (decimal: 10)
    
    ; Load second operand (B = 5)
    LDI R2, 5           ; R2 <- 0x0005 (decimal: 5)

;------------------------------------------------------------------------------
; Section: ALU Operations
; Test all basic arithmetic and logic operations
;------------------------------------------------------------------------------

    ;--------------------------------------------------------------------------
    ; Operation: ADD (Addition)
    ; Formula: R3 = R1 + R2
    ; Expected: 10 + 5 = 15 (0x000F)
    ;--------------------------------------------------------------------------
    ADD R3, R1, R2      ; R3 <- R1 + R2 = 0x000A + 0x0005 = 0x000F

    ;--------------------------------------------------------------------------
    ; Operation: SUB (Subtraction)
    ; Formula: R4 = R1 - R2
    ; Expected: 10 - 5 = 5 (0x0005)
    ;--------------------------------------------------------------------------
    SUB R4, R1, R2      ; R4 <- R1 - R2 = 0x000A - 0x0005 = 0x0005

    ;--------------------------------------------------------------------------
    ; Operation: AND (Bitwise AND)
    ; Formula: R5 = R1 & R2
    ; Binary:   1010 (10) & 0101 (5) = 0000 (0)
    ; Expected: 0 (0x0000)
    ;--------------------------------------------------------------------------
    AND R5, R1, R2      ; R5 <- R1 & R2 = 0x000A & 0x0005 = 0x0000

    ;--------------------------------------------------------------------------
    ; Operation: OR (Bitwise OR)
    ; Formula: R6 = R1 | R2
    ; Binary:   1010 (10) | 0101 (5) = 1111 (15)
    ; Expected: 15 (0x000F)
    ;--------------------------------------------------------------------------
    OR  R6, R1, R2      ; R6 <- R1 | R2 = 0x000A | 0x0005 = 0x000F

;------------------------------------------------------------------------------
; Section: Program Termination
;------------------------------------------------------------------------------
    HALT                ; Stop CPU execution
