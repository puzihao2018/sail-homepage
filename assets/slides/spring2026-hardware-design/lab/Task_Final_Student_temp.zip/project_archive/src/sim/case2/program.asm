;==============================================================================
; File: program.asm
; Case: 2 - Immediate Operations (I-type Instructions)
; Description: Tests ADDI and SUBI instructions with various immediate values
;
; Register Allocation:
;   R1 (Base A)       - Base value for ADDI tests (initial: 20)
;   R2 (Base B)       - Base value for SUBI tests (initial: 15)
;   R3 (Result ADDI+) - ADDI with positive immediate
;   R4 (Result ADDI-) - ADDI with negative immediate
;   R5 (Result SUBI+) - SUBI with positive immediate
;   R6 (Result SUBI-) - SUBI with negative immediate (effectively addition)
;   R7 (Temp)         - Temporary register for chained operations
;
; Expected Results:
;   R3 = 25 (0x0019) - ADDI: 20 + 5
;   R4 = 12 (0x000C) - ADDI: 20 + (-8) = 12
;   R5 = 10 (0x000A) - SUBI: 15 - 5
;   R6 = 25 (0x0019) - SUBI: 15 - (-10) = 25
;   R7 = 30 (0x001E) - Chained: ((20 + 5) + 5)
;==============================================================================

;------------------------------------------------------------------------------
; Section: Initialization
; Load base values into registers
;------------------------------------------------------------------------------
START:
    ; Load base value A (20) for ADDI tests
    LDI R1, 20          ; R1 <- 0x0014 (decimal: 20)
    
    ; Load base value B (15) for SUBI tests
    LDI R2, 15          ; R2 <- 0x000F (decimal: 15)

;------------------------------------------------------------------------------
; Section: ADDI (Add Immediate) Tests
; Syntax: ADDI Rd, Ra, imm5
; imm5 is 5-bit signed: range -16 to +15
;------------------------------------------------------------------------------

    ;--------------------------------------------------------------------------
    ; Test 1: ADDI with positive immediate
    ; Formula: R3 = R1 + 5
    ; Expected: 20 + 5 = 25 (0x0019)
    ;--------------------------------------------------------------------------
    ADDI R3, R1, 5      ; R3 <- R1 + 5 = 20 + 5 = 25

    ;--------------------------------------------------------------------------
    ; Test 2: ADDI with negative immediate
    ; Formula: R4 = R1 + (-8)
    ; Binary: imm5 = 11000 (sign-extended to 0xFFF8 = -8)
    ; Expected: 20 - 8 = 12 (0x000C)
    ;--------------------------------------------------------------------------
    ADDI R4, R1, -8     ; R4 <- R1 + (-8) = 20 - 8 = 12

;------------------------------------------------------------------------------
; Section: SUBI (Subtract Immediate) Tests
; Syntax: SUBI Rd, Ra, imm5
; imm5 is 5-bit signed: range -16 to +15
;------------------------------------------------------------------------------

    ;--------------------------------------------------------------------------
    ; Test 3: SUBI with positive immediate
    ; Formula: R5 = R2 - 5
    ; Expected: 15 - 5 = 10 (0x000A)
    ;--------------------------------------------------------------------------
    SUBI R5, R2, 5      ; R5 <- R2 - 5 = 15 - 5 = 10

    ;--------------------------------------------------------------------------
    ; Test 4: SUBI with negative immediate (subtraction of negative = addition)
    ; Formula: R6 = R2 - (-10)
    ; Binary: imm5 = 10110 (sign-extended to 0xFFF6 = -10)
    ; Expected: 15 - (-10) = 15 + 10 = 25 (0x0019)
    ;--------------------------------------------------------------------------
    SUBI R6, R2, -10    ; R6 <- R2 - (-10) = 15 + 10 = 25

;------------------------------------------------------------------------------
; Section: Chained Immediate Operations
; Tests sequential I-type instructions for data dependency verification
;------------------------------------------------------------------------------

    ;--------------------------------------------------------------------------
    ; Test 5: Chained ADDI operations
    ; Step 1: R7 = R3 + 5 = 25 + 5 = 30
    ; Purpose: Verify result from previous ADDI can be used as source
    ; Expected: R7 = 30 (0x001E)
    ;--------------------------------------------------------------------------
    ADDI R7, R3, 5      ; R7 <- R3 + 5 = 25 + 5 = 30

;------------------------------------------------------------------------------
; Section: Program Termination
;------------------------------------------------------------------------------
    HALT                ; Stop CPU execution
