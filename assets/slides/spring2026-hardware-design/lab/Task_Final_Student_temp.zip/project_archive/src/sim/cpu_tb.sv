// cputb
`timescale 1ns/1ps

`ifdef SIMULATION
  `define MEMDST DUT.MEM_Inst.MEM.mem_array
`else //Vivado Simulator
  `define MEMDST DUT.MEM_Inst.MEM.inst.native_mem_module.blk_mem_gen_v8_4_12_inst.memory
`endif

module cpu_tb;



  // Clock and reset signals
  logic clk;
  logic rst;

  // IO Interfaces (not fully defined in this design)
  logic [15:0] io_in, out_led, out_seg7;

  // Debugging
  logic halt;

  // Instantiate the CPU
  cpu DUT (
    .clk(clk),
    .rst(rst),

    .io_in(io_in),
    .out_led(out_led),
    .out_seg7(out_seg7),

    .halt(halt)
  );

  integer fd;

  logic [15:0] mem_array_ref [0:1023];
  logic [15:0] reg_array_ref [0:7];

  logic error_flag;
  integer error_count;

  // Clock generation: 10ns period
  initial begin
    clk = 0;
    forever #5 clk = ~clk;
  end

  // Test sequence
  initial begin
    // open dump file for waveform viewing
    $dumpfile("./build/sim.vcd");
    $dumpvars(0, cpu_tb);
    fd = $fopen("./build/report.txt", "w");
    error_flag = 0;
    error_count = 0;
    io_in = 16'h0000; // Initialize IO input for SFR tests

    //--------------------------------------------
    // Test Case 1: Simple Sequential Arithmetic
    //--------------------------------------------
    // Initialize memory
    // Memory: `MEMDST
    $readmemb("case1_mem_init.txt", `MEMDST);
    $readmemb("case1_mem_ref.txt", mem_array_ref);
    $readmemh("case1_reg_ref.hex", reg_array_ref);

    // Initialize reset
    print("Applying reset...");
    reset_cpu();
    print("Reset released, starting simulation...");

    // Wait for CPU to halt
    wait (halt == 1);
    #10;

    // Check memory and registers
    check_memory();
    check_registers();
    // dump_registers();

    //--------------------------------------------
    // Test Case 2: Simple Sequential Arithmetic with immediate values
    //--------------------------------------------
    // Initialize memory
    $readmemb("case2_mem_init.txt", `MEMDST);
    $readmemb("case2_mem_ref.txt", mem_array_ref);
    $readmemh("case2_reg_ref.hex", reg_array_ref);
    // Reset CPU
    print("Applying reset for Test Case 2...");
    reset_cpu();
    print("Reset released, starting Test Case 2...");
    // Wait for CPU to halt
    wait (halt == 1);
    #10;
    // Check memory and registers
    check_memory();
    check_registers();
    // dump_registers();

    if(error_flag) begin
      error_count++;
      print($sformatf("Test Case 2 FAILED with %0d errors.", error_count));
    end else begin
      print("Test Case 2 PASSED.");
    end

    //--------------------------------------------
    // To student: You can add more test cases here to further validate your CPU design.
    //--------------------------------------------
    /*********** Fill your code below *****************/


    /*********** End of your code *******************/






    //---------------------------------------------
    // Finish simulation
    //---------------------------------------------
    print("Simulation completed.");
    if(error_count > 0) begin
      print($sformatf("Total errors: %0d", error_count));
    end else begin
      print("All tests passed with no errors.");
    end

    $fclose(fd);
    $finish;
  end

  // Force finish
  initial begin
    #10000; // Timeout after 1000ns
    $display("Simulation timed out.");
    $finish;
  end


task automatic print(input string msg);
  $fdisplay(fd, "%s | Time: %0t ", msg, $time);
  $display("%s | Time: %0t", msg, $time);
endtask

task automatic reset_cpu;
  rst = 1;
  #15;
  rst = 0;
endtask

task automatic check_memory;
  integer i;
  for (i = 0; i < 1024; i++) begin
    if (`MEMDST[i] !== mem_array_ref[i]) begin
      print($sformatf("Memory mismatch at address %0d: expected %0h, got %0h", i, mem_array_ref[i], `MEMDST[i]));
      error_flag = 1;
    end
  end
  if (!error_flag) begin
    print("Memory check PASSED.");
  end
endtask

task automatic check_registers;
  integer i;
  for (i = 0; i < 8; i++) begin
    if (DUT.DP_Inst.RF_Inst.registers[i] !== reg_array_ref[i]) begin
      print($sformatf("Register mismatch at address %0d: expected %0h, got %0h", i, reg_array_ref[i], DUT.DP_Inst.RF_Inst.registers[i]));
      error_flag = 1;
    end
  end
endtask

task automatic dump_registers;
  integer i;
  print("Register Dump:");
  for (i = 0; i < 8; i++) begin
    print($sformatf("R%0d: %0h", i, DUT.DP_Inst.RF_Inst.registers[i]));
  end
endtask


endmodule