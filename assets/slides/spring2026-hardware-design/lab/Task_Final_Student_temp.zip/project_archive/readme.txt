RISKing Processor Implementation

Name: John Doe
K-number: 12345678

---------------------------------